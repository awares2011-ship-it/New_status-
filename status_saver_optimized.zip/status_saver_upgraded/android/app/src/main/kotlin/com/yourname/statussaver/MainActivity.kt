package com.yourname.statussaver

import android.media.MediaScannerConnection
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * MainActivity — hosts the Flutter engine and registers native MethodChannels.
 *
 * MediaScanner channel:
 *   Flutter calls `com.yourname.statussaver/media#scanFile(path)` after every
 *   file save so that the new file appears in the system Gallery immediately
 *   without requiring a reboot.  The call is fire-and-forget; the Dart side
 *   does not await a result.
 *
 * CRASH FIX:
 *   • `scanFile` is invoked on the platform thread but the lambda runs on
 *     MediaScanner's internal thread.  We do NOT call back to Flutter from
 *     that lambda to avoid threading violations.
 *   • All path validation happens before passing to MediaScannerConnection.
 */
class MainActivity : FlutterActivity() {

    private val MEDIA_CHANNEL = "com.yourname.statussaver/media"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            MEDIA_CHANNEL,
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "scanFile" -> {
                    val path = call.argument<String>("path")
                    if (path.isNullOrBlank()) {
                        result.error("INVALID_PATH", "Path is null or blank", null)
                        return@setMethodCallHandler
                    }

                    try {
                        MediaScannerConnection.scanFile(
                            applicationContext,
                            arrayOf(path),
                            null,   // mimeType — null lets the scanner detect it
                        ) { _, _ ->
                            // Scan complete callback runs on scanner thread —
                            // do not call result.success() here to avoid
                            // "Reply already submitted" crashes.
                        }
                        // Respond immediately so Flutter is not blocked.
                        result.success(null)
                    } catch (e: Exception) {
                        // Non-fatal — the file was already saved; scan failure
                        // just means it won't appear in Gallery until next boot.
                        result.error("SCAN_FAILED", e.message, null)
                    }
                }

                else -> result.notImplemented()
            }
        }
    }
}
