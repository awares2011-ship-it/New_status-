enum StatusType { image, video }

/// Immutable value object representing a single status file.
///
/// [copyWith] is used throughout the app to produce a modified copy without
/// mutating shared state — prevents a class of subtle provider bugs where
/// two widgets hold different references to the same object.
class StatusModel {
  final String path;
  final StatusType type;
  final DateTime date;
  final bool isSaved;
  final bool isFromBusiness;

  const StatusModel({
    required this.path,
    required this.type,
    required this.date,
    this.isSaved = false,
    this.isFromBusiness = false,
  });

  StatusModel copyWith({
    String? path,
    StatusType? type,
    DateTime? date,
    bool? isSaved,
    bool? isFromBusiness,
  }) {
    return StatusModel(
      path: path ?? this.path,
      type: type ?? this.type,
      date: date ?? this.date,
      isSaved: isSaved ?? this.isSaved,
      isFromBusiness: isFromBusiness ?? this.isFromBusiness,
    );
  }

  /// File name without directory prefix — useful for display and deduplication.
  String get fileName => path.split('/').last;

  @override
  bool operator ==(Object other) =>
      identical(this, other) || (other is StatusModel && other.path == path);

  @override
  int get hashCode => path.hashCode;

  @override
  String toString() =>
      'StatusModel(type=$type, isSaved=$isSaved, path=$path)';
}
