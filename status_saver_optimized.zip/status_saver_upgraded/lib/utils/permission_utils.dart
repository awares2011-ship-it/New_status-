import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';

/// Abstracts all storage / media permission logic.
///
/// Android permission model changed significantly across API levels:
///
/// • API 21–29 (Android 5–9): READ_EXTERNAL_STORAGE covers .Statuses.
/// • API 30–32 (Android 10–12): Scoped storage; MANAGE_EXTERNAL_STORAGE
///   needed for arbitrary directories, OR use MediaStore (no WA .Statuses
///   access). Apps targeting SDK ≤ 29 still get READ via compatibility.
/// • API 33+ (Android 13+): READ_MEDIA_IMAGES + READ_MEDIA_VIDEO replace
///   READ_EXTERNAL_STORAGE. But WhatsApp's .Statuses folder is exempt from
///   MediaStore, so MANAGE_EXTERNAL_STORAGE is the safest fallback.
///
/// CRASH FIX: Removed bare `.request()` calls without try-catch.
/// Permission plugin callbacks can throw on some OEM ROMs.
class PermissionUtils {
  PermissionUtils._();

  // ── Permission selection ───────────────────────────────────────────────────

  /// Returns the correct [Permission] object for the running Android version.
  static Permission get _storagePermission {
    if (Platform.isAndroid) {
      // Android 13+: granular media permissions replace READ_EXTERNAL_STORAGE.
      if (_androidSdk >= 33) {
        // We need both image and video access.  Use manageExternalStorage as
        // the canonical gate so we can also read the .Statuses hidden folder.
        return Permission.manageExternalStorage;
      }
      // Android 10–12: keep targeting SDK 29 compat or use manage storage.
      if (_androidSdk >= 30) {
        return Permission.manageExternalStorage;
      }
    }
    // Android 8–9 and iOS: plain READ_EXTERNAL_STORAGE.
    return Permission.storage;
  }

  // ── Public helpers ─────────────────────────────────────────────────────────

  /// Returns `true` if storage permission is already granted.
  /// Never throws.
  static Future<bool> hasStoragePermission() async {
    try {
      final status = await _storagePermission.status;
      return status.isGranted || status.isLimited;
    } catch (e) {
      if (kDebugMode) print('PermissionUtils.hasStoragePermission error: $e');
      return false;
    }
  }

  /// Requests the required permission.
  ///
  /// Returns `true` if granted or already limited.
  /// Returns `false` on denial or any error.
  static Future<bool> requestStoragePermission() async {
    try {
      // Already granted — skip the dialog.
      if (await hasStoragePermission()) return true;

      final status = await _storagePermission.request();
      return status.isGranted || status.isLimited;
    } catch (e) {
      if (kDebugMode) print('PermissionUtils.requestStoragePermission error: $e');
      return false;
    }
  }

  /// Returns `true` if the user has permanently denied the permission
  /// (i.e. ticked "Don't ask again").
  static Future<bool> isPermanentlyDenied() async {
    try {
      final status = await _storagePermission.status;
      return status.isPermanentlyDenied;
    } catch (e) {
      if (kDebugMode) print('PermissionUtils.isPermanentlyDenied error: $e');
      return false;
    }
  }

  /// Opens the system App Settings screen so the user can manually grant
  /// the permission after selecting "Don't ask again".
  static Future<void> openSettings() async {
    try {
      await openAppSettings();
    } catch (e) {
      if (kDebugMode) print('PermissionUtils.openSettings error: $e');
    }
  }

  // ── Android SDK version helper ─────────────────────────────────────────────

  /// Reads the OS version from [Platform.operatingSystemVersion].
  ///
  /// Example value: "Android 13 (API level 33)"
  /// Falls back to 0 if parsing fails — safest behaviour (uses broadest perm).
  static int get _androidSdk {
    try {
      final version = Platform.operatingSystemVersion;
      // Try to extract the API level integer from the string.
      final match = RegExp(r'API level (\d+)').firstMatch(version);
      if (match != null) return int.parse(match.group(1)!);

      // Fallback: parse the Android N string (e.g. "Android 13").
      final vMatch = RegExp(r'Android (\d+)').firstMatch(version);
      if (vMatch != null) {
        final major = int.parse(vMatch.group(1)!);
        // Rough mapping: Android 13 → API 33, 12 → 31, 11 → 30, 10 → 29.
        const Map<int, int> versionToSdk = {
          14: 34, 13: 33, 12: 31, 11: 30, 10: 29, 9: 28, 8: 26,
        };
        return versionToSdk[major] ?? 26;
      }
    } catch (_) {}
    return 0;
  }
}
