import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'constants.dart';

/// File system helpers — all heavy I/O runs off the main thread.
///
/// CRASH FIX log:
/// • getSavedFiles()  — was using listSync() + lastModifiedSync() on main
///   thread. Replaced with async list() stream + lastModified() async call.
/// • getFileSize()    — was using lengthSync() synchronously. Wrapped in
///   try-catch with async fallback.
/// • Every public method is wrapped in try-catch so a single I/O failure
///   never propagates as an unhandled exception.
class FileUtils {
  FileUtils._();

  /// MethodChannel for Android MediaStore scanning.
  /// Registered in MainActivity.kt — no extra plugin needed.
  static const _mediaChannel =
      MethodChannel('com.yourname.statussaver/media');

  // ── Directory ─────────────────────────────────────────────────────────────

  /// Returns (and creates if needed) the app's save directory.
  static Future<Directory> getSaveDirectory() async {
    try {
      final dir = Directory(AppConstants.savePath);
      if (!await dir.exists()) {
        await dir.create(recursive: true);
      }
      return dir;
    } catch (e) {
      if (kDebugMode) print('FileUtils.getSaveDirectory error: $e');
      rethrow;
    }
  }

  // ── Save ──────────────────────────────────────────────────────────────────

  /// Copies [sourcePath] to Pictures/StatusSaver.
  ///
  /// Returns the destination path on success, `null` on any failure.
  /// Duplicate saves are a no-op — returns the existing path.
  static Future<String?> saveStatus(String sourcePath) async {
    try {
      final sourceFile = File(sourcePath);

      // Async existence check — never blocks UI.
      if (!await sourceFile.exists()) {
        if (kDebugMode) print('FileUtils: source not found: $sourcePath');
        return null;
      }

      final saveDir = await getSaveDirectory();
      final fileName = sourcePath.split('/').last;
      if (fileName.isEmpty) return null;

      final destPath = '${saveDir.path}/$fileName';

      // Already saved — idempotent.
      if (await File(destPath).exists()) return destPath;

      final savedFile = await sourceFile.copy(destPath);

      // Notify MediaStore so the file shows in Gallery immediately.
      await _scanFile(savedFile.path);

      return savedFile.path;
    } catch (e) {
      if (kDebugMode) print('FileUtils.saveStatus error: $e');
      return null;
    }
  }

  /// Asks Android to index the saved file in MediaStore.
  /// Best-effort — failure is non-fatal.
  static Future<void> _scanFile(String filePath) async {
    try {
      await _mediaChannel.invokeMethod<void>('scanFile', {'path': filePath});
    } on MissingPluginException {
      if (kDebugMode) print('FileUtils: MediaScanner channel not registered');
    } catch (e) {
      if (kDebugMode) print('FileUtils: media scan failed (non-fatal): $e');
    }
  }

  // ── Delete ────────────────────────────────────────────────────────────────

  static Future<bool> deleteFile(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        await file.delete();
        return true;
      }
      return false;
    } catch (e) {
      if (kDebugMode) print('FileUtils.deleteFile error: $e');
      return false;
    }
  }

  // ── List saved files ──────────────────────────────────────────────────────

  /// Returns all files in the StatusSaver folder, newest-first.
  ///
  /// CRASH FIX: replaced listSync() + lastModifiedSync() (main-thread blocking)
  /// with fully async alternatives.  A single bad file is skipped, not thrown.
  static Future<List<File>> getSavedFiles() async {
    try {
      final saveDir = await getSaveDirectory();
      if (!await saveDir.exists()) return [];

      final files = <_FileWithDate>[];

      // Async directory stream — never blocks the UI thread.
      await for (final entity in saveDir.list(followLinks: false)) {
        if (entity is! File) continue;

        final lower = entity.path.toLowerCase();
        final isMedia =
            AppConstants.imageExtensions.any(lower.endsWith) ||
            AppConstants.videoExtensions.any(lower.endsWith);
        if (!isMedia) continue;

        DateTime date;
        try {
          date = await entity.lastModified(); // async — safe on main thread
        } catch (_) {
          date = DateTime.now();
        }

        files.add(_FileWithDate(entity, date));
      }

      // Sort newest-first.
      files.sort((a, b) => b.date.compareTo(a.date));
      return files.map((f) => f.file).toList();
    } on FileSystemException catch (e) {
      if (kDebugMode) print('FileUtils.getSavedFiles permission error: $e');
      return [];
    } catch (e) {
      if (kDebugMode) print('FileUtils.getSavedFiles error: $e');
      return [];
    }
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  static Future<bool> isAlreadySaved(String sourcePath) async {
    try {
      final fileName = sourcePath.split('/').last;
      if (fileName.isEmpty) return false;
      final destPath = '${AppConstants.savePath}/$fileName';
      return await File(destPath).exists();
    } catch (_) {
      return false;
    }
  }

  /// Returns a human-readable file size string.
  ///
  /// CRASH FIX: wraps lengthSync() (which can throw on missing/locked files)
  /// in a try-catch so the card UI never crashes.
  static String getFileSize(String filePath) {
    try {
      final bytes = File(filePath).lengthSync();
      if (bytes < 1024) return '${bytes}B';
      if (bytes < 1048576) return '${(bytes / 1024).toStringAsFixed(1)}KB';
      return '${(bytes / 1048576).toStringAsFixed(1)}MB';
    } catch (_) {
      return '';
    }
  }

  static bool isVideo(String path) {
    final lower = path.toLowerCase();
    return AppConstants.videoExtensions.any((ext) => lower.endsWith(ext));
  }

  static bool isImage(String path) {
    final lower = path.toLowerCase();
    return AppConstants.imageExtensions.any((ext) => lower.endsWith(ext));
  }
}

/// Internal helper to carry the async-fetched date alongside its [File].
class _FileWithDate {
  final File file;
  final DateTime date;
  _FileWithDate(this.file, this.date);
}
