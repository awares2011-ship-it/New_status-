import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'constants.dart';

/// Singleton that manages all AdMob ad types.
///
/// Design goals:
/// • Preload ads so they are ready when needed.
/// • NEVER block the UI thread.
/// • Prevent ad spam with frequency caps.
/// • Handle ALL failures gracefully — the app MUST work without ads.
/// • App Open Ads only fire on genuine foreground resumes.
///
/// CRASH FIX log:
/// • All ad callbacks now check _disposed before touching state.
/// • showAppOpenAd() captures `prefs` before show(); the callback no longer
///   calls SharedPreferences.getInstance() asynchronously inside a callback.
/// • _retryTimers cleaned up on dispose() to avoid timer-after-dispose crashes.
/// • Every public method is a no-op when _disposed == true.
class AdManager with WidgetsBindingObserver {
  AdManager._internal();
  static final AdManager instance = AdManager._internal();

  // ── Ad objects ─────────────────────────────────────────────────────────────
  BannerAd? _homeBannerAd;
  BannerAd? _savedBannerAd;
  InterstitialAd? _interstitialAd;
  AppOpenAd? _appOpenAd;

  // ── Load state ─────────────────────────────────────────────────────────────
  bool _isHomeBannerLoaded = false;
  bool _isSavedBannerLoaded = false;
  bool _isInterstitialLoaded = false;
  bool _isAppOpenAdAvailable = false;

  // ── Guards ─────────────────────────────────────────────────────────────────
  bool _isShowingAppOpenAd = false;
  bool _isShowingFullScreenAd = false;
  bool _isLoadingInterstitial = false;   // prevents duplicate load calls
  bool _isLoadingAppOpen = false;        // prevents duplicate load calls
  int _downloadCounter = 0;
  bool _initialised = false;
  bool _disposed = false;                // guards post-dispose callbacks
  int _lastInterstitialMs = 0;

  // Active retry timers — cancelled on dispose().
  final List<Timer> _retryTimers = [];

  // ── Getters ────────────────────────────────────────────────────────────────
  BannerAd? get homeBannerAd => _homeBannerAd;
  BannerAd? get savedBannerAd => _savedBannerAd;
  bool get isHomeBannerLoaded => _isHomeBannerLoaded;
  bool get isSavedBannerLoaded => _isSavedBannerLoaded;

  // ── Initialization ─────────────────────────────────────────────────────────

  void initialize() {
    if (_initialised || _disposed) return;
    _initialised = true;
    WidgetsBinding.instance.addObserver(this);
    _loadLastInterstitialTime();
    loadInterstitial();
    loadAppOpenAd();
  }

  Future<void> _loadLastInterstitialTime() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (_disposed) return;
      _lastInterstitialMs =
          prefs.getInt(AppConstants.prefLastInterstitialMs) ?? 0;
    } catch (_) {}
  }

  // ── App Lifecycle ──────────────────────────────────────────────────────────

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_disposed) return;
    // Guard: only show on genuine background-to-foreground transition.
    if (state == AppLifecycleState.resumed && !_isShowingFullScreenAd) {
      showAppOpenAd();
    }
  }

  // ── Banner Ads ─────────────────────────────────────────────────────────────

  void loadHomeBanner({VoidCallback? onLoaded}) {
    if (_disposed) return;
    _homeBannerAd?.dispose();
    _isHomeBannerLoaded = false;
    _homeBannerAd = _buildBanner(
      onLoaded: () {
        if (_disposed) return;
        _isHomeBannerLoaded = true;
        onLoaded?.call();
      },
      onFailed: () {
        if (_disposed) return;
        _isHomeBannerLoaded = false;
        _homeBannerAd = null;
      },
    );
    _homeBannerAd!.load();
  }

  void loadSavedBanner({VoidCallback? onLoaded}) {
    if (_disposed) return;
    _savedBannerAd?.dispose();
    _isSavedBannerLoaded = false;
    _savedBannerAd = _buildBanner(
      onLoaded: () {
        if (_disposed) return;
        _isSavedBannerLoaded = true;
        onLoaded?.call();
      },
      onFailed: () {
        if (_disposed) return;
        _isSavedBannerLoaded = false;
        _savedBannerAd = null;
      },
    );
    _savedBannerAd!.load();
  }

  BannerAd _buildBanner({
    required VoidCallback onLoaded,
    required VoidCallback onFailed,
  }) {
    return BannerAd(
      adUnitId: AppConstants.bannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => onLoaded(),
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          onFailed();
          if (kDebugMode) print('AdManager: Banner failed – $error');
        },
      ),
    );
  }

  void disposeHomeBanner() {
    _homeBannerAd?.dispose();
    _homeBannerAd = null;
    _isHomeBannerLoaded = false;
  }

  void disposeSavedBanner() {
    _savedBannerAd?.dispose();
    _savedBannerAd = null;
    _isSavedBannerLoaded = false;
  }

  // ── Interstitial Ad ────────────────────────────────────────────────────────

  void loadInterstitial() {
    if (_disposed || _isLoadingInterstitial || _isInterstitialLoaded) return;
    _isLoadingInterstitial = true;

    InterstitialAd.load(
      adUnitId: AppConstants.interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          if (_disposed) {
            ad.dispose();
            return;
          }
          _interstitialAd = ad;
          _isInterstitialLoaded = true;
          _isLoadingInterstitial = false;
          _interstitialAd!.setImmersiveMode(true);
          if (kDebugMode) print('AdManager: Interstitial loaded');
        },
        onAdFailedToLoad: (error) {
          if (_disposed) return;
          _isInterstitialLoaded = false;
          _isLoadingInterstitial = false;
          _interstitialAd = null;
          if (kDebugMode) print('AdManager: Interstitial failed – $error');
          // Retry after cooldown — use tracked timer to cancel on dispose.
          _scheduleRetry(loadInterstitial);
        },
      ),
    );
  }

  /// Call after every user download/save action.
  /// Shows interstitial once every [AppConstants.interstitialShowAfter] actions,
  /// with an extra cooldown guard to prevent back-to-back shows.
  void onDownloadAction() {
    if (_disposed) return;
    _downloadCounter++;
    if (_downloadCounter >= AppConstants.interstitialShowAfter) {
      _downloadCounter = 0;
      final nowMs = DateTime.now().millisecondsSinceEpoch;
      final cooldownMs = AppConstants.interstitialCooldownSeconds * 1000;
      if (nowMs - _lastInterstitialMs >= cooldownMs) {
        showInterstitial();
      }
    }
  }

  void showInterstitial({VoidCallback? onDismissed}) {
    if (_disposed || !_isInterstitialLoaded || _interstitialAd == null) {
      onDismissed?.call();
      return;
    }

    _isShowingFullScreenAd = true;

    _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        if (_disposed) return;
        _isShowingFullScreenAd = false;
        ad.dispose();
        _interstitialAd = null;
        _isInterstitialLoaded = false;
        _recordInterstitialTime();
        loadInterstitial();
        onDismissed?.call();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        if (_disposed) return;
        _isShowingFullScreenAd = false;
        ad.dispose();
        _interstitialAd = null;
        _isInterstitialLoaded = false;
        loadInterstitial();
        onDismissed?.call();
        if (kDebugMode) print('AdManager: Interstitial show failed – $error');
      },
    );

    try {
      _interstitialAd!.show();
    } catch (e) {
      // show() can throw if the ad was invalidated between load and show.
      _isShowingFullScreenAd = false;
      _interstitialAd?.dispose();
      _interstitialAd = null;
      _isInterstitialLoaded = false;
      onDismissed?.call();
      if (kDebugMode) print('AdManager: Interstitial show exception – $e');
    }
  }

  Future<void> _recordInterstitialTime() async {
    _lastInterstitialMs = DateTime.now().millisecondsSinceEpoch;
    try {
      final prefs = await SharedPreferences.getInstance();
      if (_disposed) return;
      await prefs.setInt(
          AppConstants.prefLastInterstitialMs, _lastInterstitialMs);
    } catch (_) {}
  }

  // ── Native Ad ──────────────────────────────────────────────────────────────

  /// Creates a new [NativeAd] using the registered `listTile` factory.
  NativeAd createNativeAd({required NativeAdListener listener}) {
    return NativeAd(
      adUnitId: AppConstants.nativeAdUnitId,
      factoryId: 'listTile',
      request: const AdRequest(),
      listener: listener,
    );
  }

  // ── App Open Ad ────────────────────────────────────────────────────────────

  void loadAppOpenAd() {
    if (_disposed || _isLoadingAppOpen || _isAppOpenAdAvailable) return;
    _isLoadingAppOpen = true;

    AppOpenAd.load(
      adUnitId: AppConstants.appOpenAdUnitId,
      request: const AdRequest(),
      adLoadCallback: AppOpenAdLoadCallback(
        onAdLoaded: (ad) {
          if (_disposed) {
            ad.dispose();
            return;
          }
          _appOpenAd = ad;
          _isAppOpenAdAvailable = true;
          _isLoadingAppOpen = false;
          if (kDebugMode) print('AdManager: App Open Ad loaded');
        },
        onAdFailedToLoad: (error) {
          if (_disposed) return;
          _isAppOpenAdAvailable = false;
          _isLoadingAppOpen = false;
          _appOpenAd = null;
          if (kDebugMode) print('AdManager: App Open Ad failed – $error');
        },
      ),
    );
  }

  Future<void> showAppOpenAd() async {
    if (_disposed ||
        !_isAppOpenAdAvailable ||
        _appOpenAd == null ||
        _isShowingAppOpenAd ||
        _isShowingFullScreenAd) {
      return;
    }

    // CRASH FIX: Fetch prefs BEFORE calling show() so the callback
    // closure can safely call prefs.setInt() without a new async gap.
    SharedPreferences? prefs;
    try {
      prefs = await SharedPreferences.getInstance();
    } catch (_) {
      // SharedPreferences unavailable — skip ad, not a crash.
      return;
    }

    if (_disposed) return;

    // Cooldown check — avoid spamming on every alt-tab.
    final lastShown = prefs.getInt(AppConstants.prefLastAppOpenAd) ?? 0;
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    final cooldownMs = AppConstants.appOpenAdCooldownHours * 60 * 60 * 1000;
    if (nowMs - lastShown < cooldownMs) {
      if (kDebugMode) print('AdManager: App Open Ad on cooldown');
      return;
    }

    _isShowingAppOpenAd = true;
    _isShowingFullScreenAd = true;

    _appOpenAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        if (_disposed) return;
        _isShowingAppOpenAd = false;
        _isShowingFullScreenAd = false;
        ad.dispose();
        _appOpenAd = null;
        _isAppOpenAdAvailable = false;
        // prefs already captured — safe synchronous write.
        prefs?.setInt(
          AppConstants.prefLastAppOpenAd,
          DateTime.now().millisecondsSinceEpoch,
        );
        loadAppOpenAd();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        if (_disposed) return;
        _isShowingAppOpenAd = false;
        _isShowingFullScreenAd = false;
        ad.dispose();
        _appOpenAd = null;
        _isAppOpenAdAvailable = false;
        loadAppOpenAd();
        if (kDebugMode) print('AdManager: App Open Ad show failed – $error');
      },
    );

    try {
      _appOpenAd!.show();
    } catch (e) {
      // show() can throw if the ad was invalidated.
      _isShowingAppOpenAd = false;
      _isShowingFullScreenAd = false;
      _appOpenAd?.dispose();
      _appOpenAd = null;
      _isAppOpenAdAvailable = false;
      if (kDebugMode) print('AdManager: App Open Ad show exception – $e');
    }
  }

  // ── Internal helpers ───────────────────────────────────────────────────────

  /// Schedules [fn] after [AppConstants.adRetrySeconds] seconds.
  /// The timer is tracked so it can be cancelled on dispose().
  void _scheduleRetry(VoidCallback fn) {
    final timer = Timer(
      Duration(seconds: AppConstants.adRetrySeconds),
      () {
        if (!_disposed) fn();
      },
    );
    _retryTimers.add(timer);
    // Housekeeping — remove expired timers from the list.
    _retryTimers.removeWhere((t) => !t.isActive);
  }

  // ── Cleanup ────────────────────────────────────────────────────────────────

  void dispose() {
    _disposed = true;
    for (final timer in _retryTimers) {
      timer.cancel();
    }
    _retryTimers.clear();
    WidgetsBinding.instance.removeObserver(this);
    _homeBannerAd?.dispose();
    _savedBannerAd?.dispose();
    _interstitialAd?.dispose();
    _appOpenAd?.dispose();
    _homeBannerAd = null;
    _savedBannerAd = null;
    _interstitialAd = null;
    _appOpenAd = null;
  }
}
