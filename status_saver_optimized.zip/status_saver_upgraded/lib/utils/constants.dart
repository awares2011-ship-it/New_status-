/// Central constants file — no magic strings scattered across the codebase.
///
/// Swap the Ad Unit IDs for real ones before publishing to Play Store.
/// All other values are tunable without touching business logic.
abstract class AppConstants {

  // ── App meta ───────────────────────────────────────────────────────────────
  static const String appName        = 'Status Saver';
  static const String packageName    = 'com.yourname.statussaver';
  static const String privacyPolicyUrl =
      'https://yoursite.com/privacy-policy';

  // ── Save path ──────────────────────────────────────────────────────────────
  /// Folder inside Pictures where downloaded statuses are stored.
  /// Must match the path declared in the FileProvider XML.
  static const String savePath =
      '/storage/emulated/0/Pictures/StatusSaver';

  // ── WhatsApp status directories ────────────────────────────────────────────
  /// Paths vary by Android version and WA variant.
  /// All paths are tried on every scan; missing ones are skipped gracefully.
  static const List<String> whatsappStatusPaths = [
    // Android 9 and below (legacy external storage).
    '/storage/emulated/0/WhatsApp/Media/.Statuses',
    '/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/.Statuses',
    // Some OEM variants.
    '/sdcard/WhatsApp/Media/.Statuses',
  ];

  static const List<String> whatsappBusinessStatusPaths = [
    '/storage/emulated/0/WhatsApp Business/Media/.Statuses',
    '/storage/emulated/0/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses',
  ];

  // ── Supported media extensions ─────────────────────────────────────────────
  static const List<String> imageExtensions = ['.jpg', '.jpeg', '.png', '.webp', '.gif'];
  static const List<String> videoExtensions = ['.mp4', '.mkv', '.3gp', '.avi', '.mov'];

  // ── AdMob — TEST IDs (replace before release) ──────────────────────────────
  // Test IDs from Google; safe to commit; replaced by real IDs via --dart-define
  // or a build-flavor constants file.
  static const String bannerAdUnitId =
      String.fromEnvironment('BANNER_AD_UNIT_ID',
          defaultValue: 'ca-app-pub-3940256099942544/6300978111');

  static const String interstitialAdUnitId =
      String.fromEnvironment('INTERSTITIAL_AD_UNIT_ID',
          defaultValue: 'ca-app-pub-3940256099942544/1033173712');

  static const String nativeAdUnitId =
      String.fromEnvironment('NATIVE_AD_UNIT_ID',
          defaultValue: 'ca-app-pub-3940256099942544/2247696110');

  static const String appOpenAdUnitId =
      String.fromEnvironment('APP_OPEN_AD_UNIT_ID',
          defaultValue: 'ca-app-pub-3940256099942544/9257395921');

  // ── Ad frequency & cooldowns ───────────────────────────────────────────────
  /// Show an interstitial after this many download actions.
  static const int interstitialShowAfter = 3;

  /// Minimum seconds between two interstitial shows.
  static const int interstitialCooldownSeconds = 120; // 2 minutes

  /// Minimum hours between App Open Ad shows.
  static const int appOpenAdCooldownHours = 2;

  /// Show a native ad card every N items in the grid.
  static const int nativeAdEveryN = 9;

  /// Seconds to wait before retrying a failed ad load.
  static const int adRetrySeconds = 30;

  // ── SharedPreferences keys ─────────────────────────────────────────────────
  static const String prefThemeMode           = 'theme_mode';
  static const String prefLastInterstitialMs  = 'last_interstitial_ms';
  static const String prefLastAppOpenAd       = 'last_app_open_ad_ms';

  // ── UI constants ───────────────────────────────────────────────────────────
  static const double gridSpacing     = 4.0;
  static const int    gridCrossCount  = 3;
  static const double gridAspectRatio = 0.8;

  // ── Play Store listing ─────────────────────────────────────────────────────
  static const String playStoreShortDescription =
      'Save & share WhatsApp statuses — images & videos — in one tap!';

  static const String playStoreLongDescription = '''
📥 STATUS SAVER — Best WhatsApp Status Downloader

Save and download WhatsApp & WhatsApp Business photo and video statuses directly to your gallery — fast, free, and with zero hassle!

✅ KEY FEATURES
• Save WhatsApp images & videos in one tap
• Supports WhatsApp Business statuses
• View all statuses in a clean, fast grid
• Share any status to any app instantly
• Dark mode support
• Works fully offline

📲 HOW IT WORKS
1. Open WhatsApp and view the status you like
2. Open Status Saver — it appears automatically
3. Tap the download button — saved!

🔒 PRIVACY FIRST
• No account or login required
• No statuses are uploaded to any server
• All files stay on your device

💡 WHY CHOOSE US?
• Lightweight & battery-friendly
• Supports Android 8 – 14+
• Fast thumbnail loading
• No watermarks added

Download Status Saver now and never miss a status again!
''';
}
