import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import '../models/status_model.dart';
import '../providers/saved_provider.dart';
import '../utils/constants.dart';
import '../utils/ad_manager.dart';
import '../widgets/status_card.dart';
import '../widgets/banner_ad_widget.dart';
import '../widgets/empty_state_widget.dart';

class SavedScreen extends StatefulWidget {
  const SavedScreen({super.key});

  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen> {
  @override
  void initState() {
    super.initState();
    // Load after first frame to avoid calling providers during build.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<SavedProvider>().loadSaved();
    });

    AdManager.instance.loadSavedBanner(onLoaded: () {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    AdManager.instance.disposeSavedBanner();
    super.dispose();
  }

  // ── Delete flow ────────────────────────────────────────────────────────────

  Future<void> _deleteSelected() async {
    final provider = context.read<SavedProvider>();
    final count = provider.selectedCount;

    // Confirmation dialog — prevents accidental batch delete.
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Files'),
        content: Text(
          'Delete $count ${count == 1 ? "file" : "files"} permanently?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text(
              'Delete',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );

    if (confirm != true || !mounted) return;

    final deleted = await provider.deleteSelected();
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          deleted > 0
              ? '$deleted ${deleted == 1 ? "file" : "files"} deleted'
              : 'Nothing was deleted',
        ),
      ),
    );
  }

  Future<void> _deleteOne(StatusModel status) async {
    final provider = context.read<SavedProvider>();
    final ok = await provider.deleteStatus(status);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(ok ? 'File deleted' : 'Could not delete file'),
      ),
    );
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Consumer<SavedProvider>(
      builder: (context, provider, _) {
        final isMultiSelect = provider.isMultiSelectMode;

        return Scaffold(
          appBar: AppBar(
            title: isMultiSelect
                ? Text('${provider.selectedCount} selected')
                : const Text('Saved Statuses'),
            backgroundColor: isMultiSelect
                ? const Color(0xFF128C7E)
                : const Color(0xFF075E54),
            leading: isMultiSelect
                ? IconButton(
                    icon: const Icon(Icons.close),
                    tooltip: 'Cancel selection',
                    onPressed: provider.clearSelection,
                  )
                : null,
            actions: [
              if (isMultiSelect) ...[
                IconButton(
                  icon: const Icon(Icons.select_all),
                  tooltip: 'Select All',
                  onPressed: provider.selectAll,
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline_rounded),
                  tooltip: 'Delete selected',
                  onPressed: _deleteSelected,
                ),
              ] else ...[
                IconButton(
                  icon: const Icon(Icons.refresh_rounded),
                  tooltip: 'Refresh',
                  onPressed: provider.loadSaved,
                ),
              ],
            ],
          ),
          body: Column(
            children: [
              Expanded(child: _buildBody(provider)),
              const BannerAdWidget(adKey: 'saved'),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBody(SavedProvider provider) {
    if (provider.isLoading) {
      return _buildShimmer();
    }

    if (provider.savedStatuses.isEmpty) {
      return const EmptyStateWidget(
        icon: Icons.download_done_rounded,
        title: 'No Saved Statuses',
        subtitle: 'Download WhatsApp statuses from the\nWhatsApp tab — they appear here.',
      );
    }

    return _buildTabbedView(provider);
  }

  Widget _buildTabbedView(SavedProvider provider) {
    return DefaultTabController(
      length: 2,
      child: Column(
        children: [
          const TabBar(
            indicatorColor: Color(0xFF25D366),
            labelColor: Color(0xFF25D366),
            tabs: [
              Tab(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.image_outlined, size: 18),
                    SizedBox(width: 4),
                    Text('Images'),
                  ],
                ),
              ),
              Tab(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.videocam_outlined, size: 18),
                    SizedBox(width: 4),
                    Text('Videos'),
                  ],
                ),
              ),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                _buildGrid(provider, provider.savedImages),
                _buildGrid(provider, provider.savedVideos),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGrid(SavedProvider provider, List<StatusModel> statuses) {
    if (statuses.isEmpty) {
      return const EmptyStateWidget(
        icon: Icons.sentiment_neutral_rounded,
        title: 'Nothing Here Yet',
        subtitle: 'Saved statuses from the WhatsApp tab\nwill show up here.',
      );
    }

    return RefreshIndicator(
      color: const Color(0xFF25D366),
      onRefresh: provider.loadSaved,
      child: GridView.builder(
        padding: const EdgeInsets.all(4),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: AppConstants.gridCrossCount,
          crossAxisSpacing: AppConstants.gridSpacing,
          mainAxisSpacing: AppConstants.gridSpacing,
          childAspectRatio: AppConstants.gridAspectRatio,
        ),
        itemCount: statuses.length,
        addAutomaticKeepAlives: false,
        itemBuilder: (context, index) {
          final status = statuses[index];
          return RepaintBoundary(
            child: StatusCard(
              status: status,
              isSelected: provider.isSelected(status.path),
              isMultiSelectMode: provider.isMultiSelectMode,
              showDeleteButton: true,
              onTap: () {
                if (provider.isMultiSelectMode) {
                  provider.toggleSelection(status.path);
                } else {
                  final route = status.type == StatusType.video
                      ? '/video_player'
                      : '/image_viewer';
                  Navigator.of(context).pushNamed(route, arguments: status);
                }
              },
              onLongPress: () => provider.toggleSelection(status.path),
              onDelete: () => _deleteOne(status),
            ),
          );
        },
      ),
    );
  }

  Widget _buildShimmer() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Shimmer.fromColors(
      baseColor: isDark ? Colors.grey[800]! : Colors.grey[300]!,
      highlightColor: isDark ? Colors.grey[700]! : Colors.grey[100]!,
      child: GridView.builder(
        padding: const EdgeInsets.all(4),
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 4,
          mainAxisSpacing: 4,
          childAspectRatio: 0.8,
        ),
        itemCount: 12,
        itemBuilder: (_, __) => Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }
}
