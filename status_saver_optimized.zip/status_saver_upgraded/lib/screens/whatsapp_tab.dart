import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/status_provider.dart';
import '../utils/permission_utils.dart';
import '../widgets/banner_ad_widget.dart';
import 'images_fragment.dart';
import 'videos_fragment.dart';

class WhatsAppTab extends StatefulWidget {
  const WhatsAppTab({super.key});

  @override
  State<WhatsAppTab> createState() => _WhatsAppTabState();
}

class _WhatsAppTabState extends State<WhatsAppTab>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late TabController _tabController;

  // Prevents duplicate status loads triggered by rapid lifecycle events.
  bool _isRefreshing = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);

    // Register for app lifecycle events (auto-refresh on resume).
    WidgetsBinding.instance.addObserver(this);

    // Post-frame: safe to access providers and run async work.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _silentCheckAndLoad();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _tabController.dispose();
    super.dispose();
  }

  // ── App lifecycle ──────────────────────────────────────────────────────────

  /// FEATURE: Auto-refresh statuses when app returns from background.
  /// This catches cases where the user viewed a WA status, then came back.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (!mounted) return;
    if (state == AppLifecycleState.resumed) {
      _autoRefreshIfGranted();
    }
  }

  Future<void> _autoRefreshIfGranted() async {
    if (_isRefreshing) return;

    final hasPermission = await PermissionUtils.hasStoragePermission();
    if (!mounted) return;

    if (hasPermission) {
      final provider = context.read<StatusProvider>();
      // Only auto-refresh if already in a loaded state — don't interrupt idle.
      if (provider.state == StatusState.success ||
          provider.state == StatusState.empty) {
        provider.refresh();
      }
    }
  }

  // ── Silent initial load ────────────────────────────────────────────────────

  /// Silently checks permission and loads statuses if already granted.
  /// Does NOT show a dialog — the user must press "Grant Permission" for that.
  Future<void> _silentCheckAndLoad() async {
    if (!mounted) return;
    final provider = context.read<StatusProvider>();

    // Only auto-load when truly idle — avoids re-triggering mid-load.
    if (provider.state != StatusState.idle) return;

    final hasPermission = await PermissionUtils.hasStoragePermission();
    if (!mounted) return;

    if (hasPermission) {
      provider.loadStatuses();
    }
    // No permission → stay idle; _PermissionGate handles next step.
  }

  // ── Permission request ─────────────────────────────────────────────────────

  Future<void> _onGrantPermissionPressed() async {
    if (_isRefreshing) return;
    _isRefreshing = true;

    try {
      final granted = await PermissionUtils.requestStoragePermission();
      if (!mounted) return;

      if (granted) {
        context.read<StatusProvider>().loadStatuses();
      } else {
        final permanentlyDenied = await PermissionUtils.isPermanentlyDenied();
        if (!mounted) return;

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              permanentlyDenied
                  ? 'Permission denied. Enable it in App Settings to continue.'
                  : 'Storage permission is required to view WhatsApp statuses.',
            ),
            action: permanentlyDenied
                ? SnackBarAction(
                    label: 'Settings',
                    textColor: Colors.white,
                    onPressed: PermissionUtils.openSettings,
                  )
                : null,
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 4),
          ),
        );
      }
    } finally {
      _isRefreshing = false;
    }
  }

  Future<void> _onRefreshPressed() async {
    if (_isRefreshing) return;
    _isRefreshing = true;

    try {
      final hasPermission = await PermissionUtils.hasStoragePermission();
      if (!mounted) return;

      if (hasPermission) {
        await context.read<StatusProvider>().refresh();
      } else {
        await _onGrantPermissionPressed();
      }
    } finally {
      if (mounted) _isRefreshing = false;
    }
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<StatusProvider>();
    final isMultiSelect = provider.isMultiSelectMode;

    return Scaffold(
      appBar: AppBar(
        title: isMultiSelect
            ? Text('${provider.selectedCount} selected')
            : const Text('Status Saver'),
        backgroundColor:
            isMultiSelect ? const Color(0xFF128C7E) : const Color(0xFF075E54),
        leading: isMultiSelect
            ? IconButton(
                icon: const Icon(Icons.close),
                tooltip: 'Cancel',
                onPressed: provider.clearSelection,
              )
            : null,
        actions: [
          if (isMultiSelect) ...[
            IconButton(
              icon: const Icon(Icons.select_all),
              tooltip: 'Select All',
              onPressed: () {
                final list = _tabController.index == 0
                    ? provider.imageStatuses
                    : provider.videoStatuses;
                provider.selectAll(list);
              },
            ),
          ] else ...[
            // Show refresh only when there is already content.
            if (provider.state != StatusState.idle)
              IconButton(
                icon: _isRefreshing
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Icon(Icons.refresh_rounded),
                tooltip: 'Refresh',
                onPressed: _isRefreshing ? null : _onRefreshPressed,
              ),
          ],
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.image_outlined, size: 18),
                  const SizedBox(width: 6),
                  Text(
                    provider.state == StatusState.success
                        ? 'Images (${provider.imageStatuses.length})'
                        : 'Images',
                  ),
                ],
              ),
            ),
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.videocam_outlined, size: 18),
                  const SizedBox(width: 6),
                  Text(
                    provider.state == StatusState.success
                        ? 'Videos (${provider.videoStatuses.length})'
                        : 'Videos',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(child: _buildBody(provider)),
          const BannerAdWidget(adKey: 'home'),
        ],
      ),
    );
  }

  Widget _buildBody(StatusProvider provider) {
    switch (provider.state) {
      case StatusState.idle:
        return _PermissionGate(onGrantPressed: _onGrantPermissionPressed);

      case StatusState.loading:
        return Stack(
          children: [
            TabBarView(
              controller: _tabController,
              children: const [ImagesFragment(), VideosFragment()],
            ),
            // Subtle top progress bar — never blocks user interaction.
            const Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: LinearProgressIndicator(
                backgroundColor: Colors.transparent,
                color: Color(0xFF25D366),
                minHeight: 2,
              ),
            ),
          ],
        );

      case StatusState.success:
      case StatusState.empty:
      case StatusState.error:
        return TabBarView(
          controller: _tabController,
          children: const [ImagesFragment(), VideosFragment()],
        );
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Permission Gate UI
// ─────────────────────────────────────────────────────────────────────────────

class _PermissionGate extends StatelessWidget {
  final VoidCallback onGrantPressed;
  const _PermissionGate({required this.onGrantPressed});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Icon in a tinted circle.
            Container(
              width: 110,
              height: 110,
              decoration: BoxDecoration(
                color: const Color(0xFF25D366).withOpacity(0.10),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.lock_open_rounded,
                size: 56,
                color: Color(0xFF25D366),
              ),
            ),
            const SizedBox(height: 28),

            Text(
              'Permission Required',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: isDark ? Colors.white : Colors.black87,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),

            Text(
              'Status Saver needs storage access to read\n'
              'WhatsApp statuses on your device.',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
                height: 1.6,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),

            _Step(
              icon: Icons.chat_bubble_outline_rounded,
              text: 'Open WhatsApp and view someone\'s status',
            ),
            _Step(
              icon: Icons.folder_open_rounded,
              text: 'Grant storage permission below',
            ),
            _Step(
              icon: Icons.download_done_rounded,
              text: 'Browse and save statuses from here',
            ),

            const SizedBox(height: 32),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: onGrantPressed,
                icon: const Icon(Icons.security_rounded, size: 20),
                label: const Text(
                  'Grant Permission',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF25D366),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  elevation: 0,
                ),
              ),
            ),
            const SizedBox(height: 12),

            TextButton.icon(
              onPressed: PermissionUtils.openSettings,
              icon:
                  Icon(Icons.settings_outlined, size: 16, color: Colors.grey[500]),
              label: Text(
                'Open App Settings',
                style: TextStyle(fontSize: 13, color: Colors.grey[500]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Step extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Step({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xFF25D366), size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 13.5,
                color: Colors.grey[600],
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
