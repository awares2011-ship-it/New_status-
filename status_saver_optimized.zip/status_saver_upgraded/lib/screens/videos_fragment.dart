import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import '../models/status_model.dart';
import '../providers/status_provider.dart';
import '../providers/saved_provider.dart';
import '../utils/ad_manager.dart';
import '../utils/constants.dart';
import '../widgets/status_card.dart';
import '../widgets/native_ad_card.dart';
import '../widgets/empty_state_widget.dart';

class VideosFragment extends StatelessWidget {
  const VideosFragment({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<StatusProvider>(
      builder: (context, provider, _) {
        switch (provider.state) {
          case StatusState.idle:
            return const EmptyStateWidget(
              icon: Icons.videocam_off_outlined,
              title: 'No Statuses Yet',
              subtitle: 'Grant permission and open WhatsApp\nto view statuses here.',
            );

          case StatusState.loading:
            return _buildShimmer(context);

          case StatusState.error:
            return EmptyStateWidget(
              icon: Icons.error_outline_rounded,
              title: 'Something went wrong',
              subtitle: provider.errorMessage ??
                  'Could not read status files. Please try again.',
              actionLabel: 'Retry',
              onAction: provider.loadStatuses,
            );

          case StatusState.empty:
            return const EmptyStateWidget(
              icon: Icons.video_search_outlined,
              title: 'No Video Statuses',
              subtitle:
                  'Open WhatsApp and view video statuses,\nthen pull down to refresh.',
            );

          case StatusState.success:
            final videos = provider.videoStatuses;
            if (videos.isEmpty) {
              return const EmptyStateWidget(
                icon: Icons.videocam_outlined,
                title: 'No Video Statuses',
                subtitle:
                    'Open WhatsApp and view video statuses,\nthen pull down to refresh.',
              );
            }
            return _buildGrid(context, provider, videos);
        }
      },
    );
  }

  Widget _buildGrid(
    BuildContext context,
    StatusProvider provider,
    List<StatusModel> videos,
  ) {
    final items = _interleaveAds(videos);

    return RefreshIndicator(
      color: const Color(0xFF25D366),
      onRefresh: provider.refresh,
      child: GridView.builder(
        padding: const EdgeInsets.all(4),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 4,
          mainAxisSpacing: 4,
          childAspectRatio: 0.8,
        ),
        itemCount: items.length,
        addAutomaticKeepAlives: false,
        itemBuilder: (context, index) {
          final item = items[index];
          if (item is _AdSlot) return const NativeAdCard();

          final status = item as StatusModel;
          return RepaintBoundary(
            child: StatusCard(
              status: status,
              isSelected: provider.isSelected(status.path),
              isMultiSelectMode: provider.isMultiSelectMode,
              onTap: () {
                if (provider.isMultiSelectMode) {
                  provider.toggleSelection(status.path);
                } else {
                  Navigator.of(context)
                      .pushNamed('/video_player', arguments: status);
                }
              },
              onLongPress: () => provider.toggleSelection(status.path),
              onDownload: () => _saveStatus(context, provider, status),
            ),
          );
        },
      ),
    );
  }

  List<dynamic> _interleaveAds(List<StatusModel> videos) {
    final items = <dynamic>[];
    for (var i = 0; i < videos.length; i++) {
      if (i > 0 && i % AppConstants.nativeAdEveryN == 0) {
        items.add(_AdSlot());
      }
      items.add(videos[i]);
    }
    return items;
  }

  Future<void> _saveStatus(
    BuildContext context,
    StatusProvider statusProvider,
    StatusModel status,
  ) async {
    if (!context.mounted) return;

    final savedProvider = context.read<SavedProvider>();

    try {
      final ok = await savedProvider.saveStatus(status);
      if (!context.mounted) return;

      if (ok) {
        statusProvider.updateSavedState(status.path, true);
        AdManager.instance.onDownloadAction();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Row(
              children: [
                Icon(Icons.check_circle, color: Colors.white, size: 20),
                SizedBox(width: 8),
                Text('Video saved to StatusSaver folder'),
              ],
            ),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not save video. Please retry.')),
        );
      }
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('An error occurred. Please retry.')),
      );
    }
  }

  Widget _buildShimmer(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Shimmer.fromColors(
      baseColor: isDark ? Colors.grey[800]! : Colors.grey[300]!,
      highlightColor: isDark ? Colors.grey[700]! : Colors.grey[100]!,
      child: GridView.builder(
        padding: const EdgeInsets.all(4),
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 4,
          mainAxisSpacing: 4,
          childAspectRatio: 0.8,
        ),
        itemCount: 15,
        itemBuilder: (_, __) => Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }
}

class _AdSlot {}
