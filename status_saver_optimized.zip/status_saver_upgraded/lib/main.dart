import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';
import 'providers/status_provider.dart';
import 'providers/saved_provider.dart';
import 'providers/theme_provider.dart';
import 'utils/ad_manager.dart';

/// Entry point.
///
/// CRASH FIX: All initialisation is wrapped in a root [runZonedGuarded] so
/// that async errors thrown outside Flutter's widget error handler (e.g.
/// platform channel callbacks, isolates) are caught and logged instead of
/// silently killing the app.
void main() {
  runZonedGuarded(
    _boot,
    (error, stack) {
      // TODO: wire up Firebase Crashlytics:
      // FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
      debugPrint('runZonedGuarded caught: $error\n$stack');
    },
  );
}

Future<void> _boot() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ── Flutter framework error handler ─────────────────────────────────────
  // Catches all widget-tree exceptions (build, layout, paint errors).
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
    // TODO: FirebaseCrashlytics.instance.recordFlutterFatalError(details);
    debugPrint('FlutterError: ${details.exceptionAsString()}');
  };

  // ── Platform dispatcher error handler (async + isolate errors) ──────────
  // Catches errors not caught by FlutterError.onError.
  PlatformDispatcher.instance.onError = (Object error, StackTrace stack) {
    // TODO: FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
    debugPrint('PlatformDispatcher.onError: $error\n$stack');
    return true; // returning true = handled; prevents force-close on debug
  };

  // ── AdMob ────────────────────────────────────────────────────────────────
  // Initialize before runApp so banners can start loading during splash.
  try {
    await MobileAds.instance.initialize();
  } catch (e) {
    // AdMob init failure is non-fatal — app must continue without ads.
    debugPrint('MobileAds.initialize failed (non-fatal): $e');
  }

  // ── Orientation lock ─────────────────────────────────────────────────────
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // ── SharedPreferences ────────────────────────────────────────────────────
  late SharedPreferences prefs;
  try {
    prefs = await SharedPreferences.getInstance();
  } catch (e) {
    // Should never happen, but guard anyway.
    debugPrint('SharedPreferences.getInstance failed: $e');
    rethrow;
  }

  // ── AdManager lifecycle observer ─────────────────────────────────────────
  // Called after MobileAds.initialize() — order matters.
  AdManager.instance.initialize();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider(prefs)),
        ChangeNotifierProvider(create: (_) => StatusProvider()),
        ChangeNotifierProvider(create: (_) => SavedProvider()),
      ],
      child: const StatusSaverApp(),
    ),
  );
}
