import 'dart:io';
import 'package:flutter/foundation.dart';
import '../models/status_model.dart';
import '../utils/constants.dart';

/// Scans all WhatsApp status directories asynchronously.
///
/// CRASH FIX log:
/// • Replaced every listSync() / existsSync() / lastModifiedSync() call with
///   their async counterparts.  Blocking the platform thread on storage I/O
///   is the #1 cause of ANRs and crashes on low-end Android devices.
/// • Each directory scan is individually try-caught so one missing path
///   (e.g. WA Business not installed) does not abort the whole fetch.
/// • Simple file-level cache: if the set of paths hasn't changed since the
///   last scan, the cached StatusModel list is returned immediately.
class WhatsAppService {
  WhatsAppService._();
  static final WhatsAppService instance = WhatsAppService._();

  // ── Cache ─────────────────────────────────────────────────────────────────

  /// Last successful scan result.
  List<StatusModel> _cachedStatuses = [];

  /// File paths from the last scan — used for change detection.
  Set<String> _cachedPaths = {};

  /// Timestamp of the last scan — always re-scan after [_staleAfter].
  DateTime? _lastScanTime;
  static const _staleAfter = Duration(minutes: 5);

  // ── Public API ─────────────────────────────────────────────────────────────

  /// Returns all valid media statuses from every known WA directory.
  ///
  /// Uses a two-phase approach:
  ///  1. Async directory listing to build the raw file list.
  ///  2. Path-set comparison to decide whether to rebuild models or return cache.
  Future<List<StatusModel>> fetchAllStatuses() async {
    try {
      // Phase 1 — collect raw files from all directories.
      final rawFiles = await _collectAllFiles();

      final newPaths = rawFiles.map((f) => f.path).toSet();

      // Phase 2 — decide: use cache or rebuild?
      final isCacheValid = _lastScanTime != null &&
          DateTime.now().difference(_lastScanTime!) < _staleAfter &&
          _setsEqual(newPaths, _cachedPaths);

      if (isCacheValid) {
        if (kDebugMode) print('WhatsAppService: returning cached results');
        return _cachedStatuses;
      }

      // Phase 3 — build StatusModel list.
      final statuses = <StatusModel>[];
      for (final file in rawFiles) {
        try {
          final stat = await file.stat();       // async — safe on UI thread
          statuses.add(StatusModel(
            path: file.path,
            type: _fileType(file.path),
            date: stat.modified,
            isSaved: false,
          ));
        } catch (e) {
          if (kDebugMode) print('WhatsAppService: skipping bad file – $e');
        }
      }

      // Sort newest-first.
      statuses.sort((a, b) => b.date.compareTo(a.date));

      // Update cache.
      _cachedStatuses = statuses;
      _cachedPaths = newPaths;
      _lastScanTime = DateTime.now();

      return statuses;
    } catch (e, stack) {
      if (kDebugMode) print('WhatsAppService.fetchAllStatuses error:\n$e\n$stack');
      // Return whatever was cached — better than an empty list on retry.
      return _cachedStatuses;
    }
  }

  /// Forces the next [fetchAllStatuses] call to bypass the cache.
  void invalidateCache() {
    _lastScanTime = null;
    _cachedPaths = {};
  }

  // ── Directory scanning ─────────────────────────────────────────────────────

  Future<List<File>> _collectAllFiles() async {
    final allFiles = <File>[];

    final directories = [
      ...AppConstants.whatsappStatusPaths,
      ...AppConstants.whatsappBusinessStatusPaths,
    ];

    for (final dirPath in directories) {
      try {
        final dir = Directory(dirPath);
        final exists = await dir.exists(); // async check — no existsSync()
        if (!exists) continue;

        await for (final entity in dir.list(followLinks: false)) {
          if (entity is! File) continue;
          if (_isMediaFile(entity.path)) {
            allFiles.add(entity);
          }
        }
      } on FileSystemException catch (e) {
        // Expected when directory is missing or permission denied for that path.
        if (kDebugMode) print('WhatsAppService: skipping dir [$dirPath] – $e');
      } catch (e) {
        if (kDebugMode) print('WhatsAppService: unexpected error for [$dirPath] – $e');
      }
    }

    return allFiles;
  }

  // ── Helpers ────────────────────────────────────────────────────────────────

  bool _isMediaFile(String path) {
    final lower = path.toLowerCase();
    // Skip WA's ".nomedia" sentinel and already-seen duplicates.
    if (lower.endsWith('.nomedia')) return false;
    return AppConstants.imageExtensions.any(lower.endsWith) ||
        AppConstants.videoExtensions.any(lower.endsWith);
  }

  StatusType _fileType(String path) {
    final lower = path.toLowerCase();
    return AppConstants.videoExtensions.any(lower.endsWith)
        ? StatusType.video
        : StatusType.image;
  }

  bool _setsEqual(Set<String> a, Set<String> b) {
    if (a.length != b.length) return false;
    return a.containsAll(b);
  }
}
