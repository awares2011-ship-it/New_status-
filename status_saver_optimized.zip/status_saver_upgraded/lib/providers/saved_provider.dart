import 'dart:io';
import 'package:flutter/foundation.dart';
import '../models/status_model.dart';
import '../utils/file_utils.dart';
import '../utils/constants.dart';

class SavedProvider extends ChangeNotifier {
  List<StatusModel> _savedStatuses = [];
  bool _isLoading = false;

  // Prevents concurrent loadSaved() calls.
  bool _loadGuard = false;

  final Set<String> _selectedPaths = {};
  bool _isMultiSelectMode = false;

  List<StatusModel> get savedStatuses => _savedStatuses;
  List<StatusModel> get savedImages =>
      _savedStatuses.where((s) => s.type == StatusType.image).toList();
  List<StatusModel> get savedVideos =>
      _savedStatuses.where((s) => s.type == StatusType.video).toList();
  bool get isLoading => _isLoading;
  Set<String> get selectedPaths => Set.unmodifiable(_selectedPaths);
  bool get isMultiSelectMode => _isMultiSelectMode;
  int get selectedCount => _selectedPaths.length;

  List<StatusModel> get selectedStatuses =>
      _savedStatuses.where((s) => _selectedPaths.contains(s.path)).toList();

  // ── Load ─────────────────────────────────────────────────────────────────

  Future<void> loadSaved() async {
    // Guard: skip concurrent loads.
    if (_loadGuard) return;
    _loadGuard = true;
    _isLoading = true;
    notifyListeners();

    try {
      final files = await FileUtils.getSavedFiles();

      // CRASH FIX: lastModifiedSync() removed from main thread.
      // We use FileUtils.getSavedFiles() which already sorts the list and
      // returns File objects. We call lastModified() (async) safely here
      // inside a try-catch so a single bad file does not abort the whole load.
      final statuses = <StatusModel>[];
      for (final file in files) {
        try {
          final path = file.path;
          final lower = path.toLowerCase();
          final isVideo =
              AppConstants.videoExtensions.any((ext) => lower.endsWith(ext));

          DateTime date;
          try {
            date = await file.lastModified();
          } catch (_) {
            date = DateTime.now();
          }

          statuses.add(StatusModel(
            path: path,
            type: isVideo ? StatusType.video : StatusType.image,
            date: date,
            isSaved: true,
          ));
        } catch (e) {
          if (kDebugMode) print('SavedProvider: skipping bad file – $e');
        }
      }

      // Keep newest-first order.
      statuses.sort((a, b) => b.date.compareTo(a.date));
      _savedStatuses = statuses;
    } catch (e) {
      if (kDebugMode) print('SavedProvider.loadSaved error: $e');
      _savedStatuses = [];
    } finally {
      _isLoading = false;
      _loadGuard = false;
    }

    notifyListeners();
  }

  // ── Save ─────────────────────────────────────────────────────────────────

  Future<bool> saveStatus(StatusModel status) async {
    try {
      final savedPath = await FileUtils.saveStatus(status.path);
      if (savedPath == null) return false;

      // Skip duplicate entries.
      if (_savedStatuses.any((s) => s.path == savedPath)) return true;

      final isVideo = FileUtils.isVideo(savedPath);
      DateTime date;
      try {
        // CRASH FIX: async instead of lastModifiedSync().
        date = await File(savedPath).lastModified();
      } catch (_) {
        date = DateTime.now();
      }

      final saved = StatusModel(
        path: savedPath,
        type: isVideo ? StatusType.video : StatusType.image,
        date: date,
        isSaved: true,
      );

      _savedStatuses.insert(0, saved);
      notifyListeners();
      return true;
    } catch (e) {
      if (kDebugMode) print('SavedProvider.saveStatus error: $e');
      return false;
    }
  }

  Future<int> saveMultiple(List<StatusModel> statuses) async {
    int count = 0;
    for (final status in statuses) {
      if (await saveStatus(status)) count++;
    }
    return count;
  }

  // ── Delete ────────────────────────────────────────────────────────────────

  Future<bool> deleteStatus(StatusModel status) async {
    try {
      final ok = await FileUtils.deleteFile(status.path);
      if (ok) {
        _savedStatuses.removeWhere((s) => s.path == status.path);
        _selectedPaths.remove(status.path);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      if (kDebugMode) print('SavedProvider.deleteStatus error: $e');
      return false;
    }
  }

  Future<int> deleteSelected() async {
    final toDelete = List<StatusModel>.from(selectedStatuses);
    int count = 0;
    for (final status in toDelete) {
      if (await deleteStatus(status)) count++;
    }
    clearSelection();
    return count;
  }

  // ── Selection ─────────────────────────────────────────────────────────────

  void toggleSelection(String path) {
    if (_selectedPaths.contains(path)) {
      _selectedPaths.remove(path);
    } else {
      _selectedPaths.add(path);
    }
    _isMultiSelectMode = _selectedPaths.isNotEmpty;
    notifyListeners();
  }

  void selectAll() {
    _selectedPaths
      ..clear()
      ..addAll(_savedStatuses.map((s) => s.path));
    _isMultiSelectMode = _selectedPaths.isNotEmpty;
    notifyListeners();
  }

  void clearSelection() {
    _selectedPaths.clear();
    _isMultiSelectMode = false;
    notifyListeners();
  }

  bool isSelected(String path) => _selectedPaths.contains(path);
}
