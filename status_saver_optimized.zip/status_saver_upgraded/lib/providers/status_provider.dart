import 'package:flutter/foundation.dart';
import '../models/status_model.dart';
import '../services/whatsapp_service.dart';

// ─────────────────────────────────────────────────────────────────────────────
// State enum
// ─────────────────────────────────────────────────────────────────────────────

/// Canonical loading-state enum for the status screen.
///
/// * [idle]    — storage permission not yet granted; nothing loaded.
/// * [loading] — file scan is in progress.
/// * [success] — scan finished with at least one file.
/// * [empty]   — scan finished with zero files.
/// * [error]   — scan threw an unexpected exception.
enum StatusState { idle, loading, success, empty, error }

/// Backward-compat alias for call-sites that still use `LoadState.*`.
typedef LoadState = StatusState;

// ─────────────────────────────────────────────────────────────────────────────
// Provider
// ─────────────────────────────────────────────────────────────────────────────

class StatusProvider extends ChangeNotifier {
  List<StatusModel> _allStatuses = [];
  StatusState _state = StatusState.idle;
  String? _errorMessage;

  /// Multi-select state.
  final Set<String> _selectedPaths = {};
  bool _isMultiSelectMode = false;

  /// Prevents concurrent scans — guard checked before every scan.
  bool _isLoading = false;

  // ── Getters ───────────────────────────────────────────────────────────────

  List<StatusModel> get imageStatuses =>
      _allStatuses.where((s) => s.type == StatusType.image).toList();

  List<StatusModel> get videoStatuses =>
      _allStatuses.where((s) => s.type == StatusType.video).toList();

  List<StatusModel> get allStatuses => List.unmodifiable(_allStatuses);

  StatusState get state => _state;
  String? get errorMessage => _errorMessage;

  Set<String> get selectedPaths => Set.unmodifiable(_selectedPaths);
  bool get isMultiSelectMode => _isMultiSelectMode;
  int get selectedCount => _selectedPaths.length;

  /// Drives the bottom-nav badge — count of statuses not yet saved.
  int get newStatusCount => _allStatuses.where((s) => !s.isSaved).length;

  List<StatusModel> get selectedStatuses =>
      _allStatuses.where((s) => _selectedPaths.contains(s.path)).toList();

  // ── Loading ───────────────────────────────────────────────────────────────

  /// Scans all WhatsApp status folders.
  ///
  /// MUST only be called AFTER storage permission is granted.
  /// [_isLoading] guard prevents concurrent scans.
  Future<void> loadStatuses() async {
    if (_isLoading) return;
    _isLoading = true;

    _state = StatusState.loading;
    _errorMessage = null;
    notifyListeners();

    try {
      final results = await WhatsAppService.instance.fetchAllStatuses();
      _allStatuses = results;
      _state = results.isEmpty ? StatusState.empty : StatusState.success;
    } catch (e, stack) {
      _state = StatusState.error;
      _errorMessage = 'Could not load statuses. Please try again.';
      if (kDebugMode) {
        print('StatusProvider.loadStatuses error:\n$e\n$stack');
      }
    } finally {
      _isLoading = false;
    }

    notifyListeners();
  }

  /// Clears multi-select and rescans from scratch.
  Future<void> refresh() async {
    if (_isLoading) return;
    clearSelection();
    _state = StatusState.idle; // allow re-entry through the guard
    _isLoading = false;        // reset in case of stale state
    await loadStatuses();
  }

  /// Alias kept for call-sites that use `refreshStatuses()`.
  Future<void> refreshStatuses() => refresh();

  // ── Saved-state sync ───────────────────────────────────────────────────────

  /// Updates the [isSaved] flag on a single status without a full reload.
  void updateSavedState(String path, bool isSaved) {
    final index = _allStatuses.indexWhere((s) => s.path == path);
    if (index == -1) return;
    _allStatuses[index] = _allStatuses[index].copyWith(isSaved: isSaved);
    notifyListeners();
  }

  // ── Multi-select ───────────────────────────────────────────────────────────

  void toggleSelection(String path) {
    if (_selectedPaths.contains(path)) {
      _selectedPaths.remove(path);
    } else {
      _selectedPaths.add(path);
    }
    _isMultiSelectMode = _selectedPaths.isNotEmpty;
    notifyListeners();
  }

  void selectAll(List<StatusModel> statuses) {
    _selectedPaths
      ..clear()
      ..addAll(statuses.map((s) => s.path));
    _isMultiSelectMode = _selectedPaths.isNotEmpty;
    notifyListeners();
  }

  void clearSelection() {
    _selectedPaths.clear();
    _isMultiSelectMode = false;
    notifyListeners();
  }

  bool isSelected(String path) => _selectedPaths.contains(path);

  // ── Reset ──────────────────────────────────────────────────────────────────

  /// Resets back to [StatusState.idle] — call when permission is revoked.
  void reset() {
    _allStatuses = [];
    _state = StatusState.idle;
    _errorMessage = null;
    _isLoading = false;
    _selectedPaths.clear();
    _isMultiSelectMode = false;
    notifyListeners();
  }
}
