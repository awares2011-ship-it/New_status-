import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'constants.dart';

/// Manages the app-wide theme (light / dark / system).
///
/// Preference is persisted via SharedPreferences so it survives app restarts.
class ThemeProvider extends ChangeNotifier {
  ThemeMode _mode;
  final SharedPreferences _prefs;

  ThemeProvider(this._prefs)
      : _mode = _modeFromIndex(_prefs.getInt(AppConstants.prefThemeMode) ?? 0);

  ThemeMode get themeMode => _mode;

  bool get isDark => _mode == ThemeMode.dark;

  void setThemeMode(ThemeMode mode) {
    if (_mode == mode) return;
    _mode = mode;
    _prefs.setInt(AppConstants.prefThemeMode, _modeIndex(mode));
    notifyListeners();
  }

  void toggleTheme() {
    setThemeMode(_mode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark);
  }

  static ThemeMode _modeFromIndex(int index) {
    switch (index) {
      case 1: return ThemeMode.light;
      case 2: return ThemeMode.dark;
      default: return ThemeMode.system;
    }
  }

  static int _modeIndex(ThemeMode mode) {
    switch (mode) {
      case ThemeMode.light: return 1;
      case ThemeMode.dark: return 2;
      default: return 0;
    }
  }
}

// Re-export so providers/theme_provider.dart import path works.
export '../utils/constants.dart' show AppConstants;
