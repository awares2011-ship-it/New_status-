import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../utils/ad_manager.dart';

/// Displays a native ad in a grid cell.
///
/// Stateful so the [NativeAd] can be disposed when the cell scrolls off screen.
/// CRASH FIX:
/// • Checks [mounted] before setState in ad callbacks.
/// • Disposes the ad in dispose() — leaking NativeAd causes memory issues.
class NativeAdCard extends StatefulWidget {
  const NativeAdCard({super.key});

  @override
  State<NativeAdCard> createState() => _NativeAdCardState();
}

class _NativeAdCardState extends State<NativeAdCard> {
  NativeAd? _nativeAd;
  bool _adLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadAd();
  }

  void _loadAd() {
    _nativeAd = AdManager.instance.createNativeAd(
      listener: NativeAdListener(
        onAdLoaded: (ad) {
          if (!mounted) return;         // CRASH FIX: guard
          setState(() => _adLoaded = true);
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          if (!mounted) return;
          setState(() {
            _nativeAd = null;
            _adLoaded = false;
          });
        },
      ),
    );
    _nativeAd?.load();
  }

  @override
  void dispose() {
    _nativeAd?.dispose();
    _nativeAd = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_adLoaded || _nativeAd == null) {
      // Transparent placeholder — keeps grid alignment intact.
      return const SizedBox.shrink();
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: AdWidget(ad: _nativeAd!),
    );
  }
}
