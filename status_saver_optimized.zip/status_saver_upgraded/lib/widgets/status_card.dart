import 'dart:io';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../models/status_model.dart';

/// A thumbnail card displayed in the status grid.
///
/// CRASH FIX: Removed `file.existsSync()` from `build()`.
/// Synchronous file I/O in the widget tree can cause ANR on slow storage.
/// We rely on `Image.file`'s `errorBuilder` to handle missing / unreadable
/// files gracefully — no blocking call needed.
class StatusCard extends StatelessWidget {
  final StatusModel status;
  final bool isSelected;
  final bool isMultiSelectMode;
  final bool showDeleteButton;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final VoidCallback? onDownload;
  final VoidCallback? onDelete;

  const StatusCard({
    super.key,
    required this.status,
    required this.isSelected,
    required this.isMultiSelectMode,
    required this.onTap,
    required this.onLongPress,
    this.onDownload,
    this.onDelete,
    this.showDeleteButton = false,
  });

  Future<void> _share() async {
    try {
      await Share.shareXFiles(
        [XFile(status.path)],
        text: 'Shared via Status Saver',
      );
    } catch (_) {
      // Share failure is non-fatal — silently ignore.
    }
  }

  @override
  Widget build(BuildContext context) {
    final isVideo = status.type == StatusType.video;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: isSelected
              ? Border.all(color: const Color(0xFF25D366), width: 2.5)
              : Border.all(color: Colors.transparent, width: 2.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // ── Thumbnail ──────────────────────────────────────────────────
              _buildThumbnail(isDark),

              // ── Gradient overlay ───────────────────────────────────────────
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  height: 60,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [Colors.black87, Colors.transparent],
                    ),
                  ),
                ),
              ),

              // ── Video badge ────────────────────────────────────────────────
              if (isVideo)
                Positioned(
                  top: 6,
                  left: 6,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.play_circle_filled_rounded,
                            color: Colors.white, size: 12),
                        SizedBox(width: 3),
                        Text(
                          'VIDEO',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

              // ── Business badge ─────────────────────────────────────────────
              if (status.isFromBusiness)
                Positioned(
                  top: 6,
                  right: 6,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                    decoration: BoxDecoration(
                      color: const Color(0xFF25D366).withOpacity(0.85),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Text(
                      'BIZ',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),

              // ── Bottom actions: Share + Download/Delete ─────────────────────
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      _OverlayIconButton(
                        icon: Icons.share_rounded,
                        onTap: _share,
                      ),
                      const SizedBox(width: 4),
                      if (showDeleteButton && onDelete != null)
                        _OverlayIconButton(
                          icon: Icons.delete_outline_rounded,
                          onTap: onDelete!,
                          color: Colors.redAccent,
                        )
                      else if (onDownload != null)
                        _OverlayIconButton(
                          icon: status.isSaved
                              ? Icons.check_circle_rounded
                              : Icons.download_rounded,
                          onTap: status.isSaved ? null : onDownload,
                          color: status.isSaved
                              ? const Color(0xFF25D366)
                              : Colors.white,
                        ),
                    ],
                  ),
                ),
              ),

              // ── Multi-select checkmark ──────────────────────────────────────
              if (isMultiSelectMode)
                Positioned(
                  top: 6,
                  right: 6,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      color: isSelected
                          ? const Color(0xFF25D366)
                          : Colors.black.withOpacity(0.4),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                    child: isSelected
                        ? const Icon(Icons.check_rounded,
                            color: Colors.white, size: 14)
                        : null,
                  ),
                ),

              // ── Selection tint ──────────────────────────────────────────────
              if (isSelected)
                Container(
                  color: const Color(0xFF25D366).withOpacity(0.15),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildThumbnail(bool isDark) {
    // Broken-image fallback widget — reused in multiple error paths.
    Widget brokenFallback() => Container(
          color: isDark ? const Color(0xFF2A3942) : const Color(0xFFE5EBF0),
          child: const Icon(Icons.broken_image_outlined,
              color: Colors.grey, size: 32),
        );

    if (status.type == StatusType.image) {
      // CRASH FIX: No existsSync() here. Image.file + errorBuilder handles all
      // cases: missing file, permission error, corrupt image, etc.
      return Image.file(
        File(status.path),
        fit: BoxFit.cover,
        // cacheWidth / cacheHeight keep memory usage low for grid thumbnails.
        cacheWidth: 300,
        errorBuilder: (_, __, ___) => brokenFallback(),
      );
    }

    // Video — show a dark background with a play icon.
    // Generating real thumbnails requires a native plugin (e.g. video_thumbnail).
    return Container(
      color: isDark ? const Color(0xFF1A2733) : const Color(0xFF1A2733),
      child: const Center(
        child: Icon(
          Icons.play_circle_fill_rounded,
          color: Color(0xFF25D366),
          size: 44,
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _OverlayIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final Color color;

  const _OverlayIconButton({
    required this.icon,
    this.onTap,
    this.color = Colors.white,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.45),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: color, size: 17),
      ),
    );
  }
}
