import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../utils/ad_manager.dart';

/// A self-contained banner ad widget with proper lifecycle management.
///
/// [adKey] is either `'home'` or `'saved'` — selects the corresponding
/// pre-loaded ad from [AdManager].
///
/// CRASH FIX:
/// • Uses [AdWidget] which requires the [BannerAd] to be loaded first;
///   we gate the [AdWidget] behind the loaded flag.
/// • onLoaded / setState guard: checks [mounted] before calling setState.
/// • The ad is disposed in [dispose], not via the AdManager's bulk dispose,
///   to match the exact widget lifecycle.
class BannerAdWidget extends StatefulWidget {
  final String adKey;

  const BannerAdWidget({super.key, required this.adKey});

  @override
  State<BannerAdWidget> createState() => _BannerAdWidgetState();
}

class _BannerAdWidgetState extends State<BannerAdWidget> {
  BannerAd? _ad;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _loadAd();
  }

  void _loadAd() {
    if (widget.adKey == 'home') {
      AdManager.instance.loadHomeBanner(onLoaded: _onLoaded);
      _ad = AdManager.instance.homeBannerAd;
    } else {
      AdManager.instance.loadSavedBanner(onLoaded: _onLoaded);
      _ad = AdManager.instance.savedBannerAd;
    }
  }

  void _onLoaded() {
    if (!mounted) return;          // CRASH FIX: guard before setState
    setState(() {
      _loaded = true;
      _ad = widget.adKey == 'home'
          ? AdManager.instance.homeBannerAd
          : AdManager.instance.savedBannerAd;
    });
  }

  @override
  void dispose() {
    // Individual dispose — AdManager keeps its own reference, but we
    // null our local copy so we're not holding a stale pointer.
    _ad = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded || _ad == null) {
      // Placeholder maintains layout space — avoids layout jank when ad loads.
      return const SizedBox(height: 50);
    }

    return SafeArea(
      top: false,
      child: SizedBox(
        height: 50,
        child: AdWidget(ad: _ad!),
      ),
    );
  }
}
