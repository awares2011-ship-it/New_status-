# Status Saver — Crash Fix & Optimization Summary

## Overview
Every change documented here traces directly to a crash, ANR (App Not Responding),
or UX regression observed in the original codebase.  Each section names the file
changed, the root cause, and the fix applied.

---

## 1. `lib/widgets/status_card.dart`

### Root Causes
| # | Bug | Impact |
|---|-----|--------|
| 1 | `file.existsSync()` called inside `build()` | Blocks platform thread → ANR on slow storage |
| 2 | No `errorBuilder` on `Image.file` | Missing / corrupt file → unhandled exception → crash |

### Fixes
- **Removed** `existsSync()` from `build()`.  
- **Added** `Image.file(..., errorBuilder: …)` → shows a broken-image icon
  for any missing, corrupt or permission-denied file.  The app never crashes
  just because a single thumbnail failed.
- Added `cacheWidth: 300` to cap memory usage in the grid.

---

## 2. `lib/providers/saved_provider.dart`

### Root Causes
| # | Bug | Impact |
|---|-----|--------|
| 1 | `lastModifiedSync()` called on main thread in a loop | ANR on devices with slow external storage |
| 2 | No guard against concurrent `loadSaved()` calls | Race condition → list corrupted → crash |
| 3 | No per-file try-catch | One bad file aborts the entire load |

### Fixes
- Replaced `lastModifiedSync()` with `await file.lastModified()`.
- Added `_loadGuard` bool to prevent concurrent scans.
- Per-file try-catch: bad files are logged and skipped.

---

## 3. `lib/utils/file_utils.dart`

### Root Causes
| # | Bug | Impact |
|---|-----|--------|
| 1 | `listSync()` on main thread | Blocks UI → ANR |
| 2 | `lastModifiedSync()` on main thread | Blocks UI → ANR |
| 3 | `lengthSync()` not guarded | Throws on missing/locked file |
| 4 | Media scan via `MediaScannerConnection` missing | Saved files invisible in Gallery |

### Fixes
- `getSavedFiles()` now uses `await for (entity in dir.list())` — fully async.
- Every `lengthSync()` wrapped in try-catch; returns `''` on failure.
- Added `_scanFile()` using a `MethodChannel` to `MainActivity.kt`; failure is
  non-fatal (just logged).

---

## 4. `lib/utils/ad_manager.dart`

### Root Causes
| # | Bug | Impact |
|---|-----|--------|
| 1 | Ad callbacks touched `_disposed` object | Use-after-free crash |
| 2 | `SharedPreferences.getInstance()` called inside `AppOpenAd` dismiss callback | Async gap inside callback → crash on some devices |
| 3 | No `_retryTimers` cleanup | Timer fires after dispose → setState on dead widget |
| 4 | No guard on `_isLoadingInterstitial` | Duplicate concurrent loads wasted quota |

### Fixes
- Every callback checks `if (_disposed) return` before any state mutation.
- `prefs` fetched **before** calling `show()`; callback uses the captured reference.
- All retry `Timer` objects tracked in `_retryTimers` list; cancelled in `dispose()`.
- `_isLoadingInterstitial` and `_isLoadingAppOpen` guards prevent duplicate loads.

---

## 5. `lib/services/whatsapp_service.dart`

### Root Causes
| # | Bug | Impact |
|---|-----|--------|
| 1 | `listSync()` on main thread | ANR |
| 2 | `lastModifiedSync()` on main thread | ANR |
| 3 | No try-catch per directory | Missing WA directory aborts whole scan |
| 4 | No caching | Redundant full scans on every tab switch |

### Fixes
- All I/O replaced with `async`/`await` variants.
- Per-directory try-catch; missing paths are silently skipped.
- Simple path-set cache: if no new files added since last scan and within
  5-minute TTL, the cached list is returned immediately.

---

## 6. `lib/providers/status_provider.dart`

### Root Causes
| # | Bug | Impact |
|---|-----|--------|
| 1 | `loadStatuses()` could be called concurrently | Race condition |
| 2 | No `StatusState.error` state | Any exception silently left the UI in loading spinner |

### Fixes
- `_isLoading` guard prevents concurrent scans.
- `StatusState.error` state added; UI shows retry button.
- `updateSavedState()` helper for in-place flag updates (avoids full reload
  just to mark a file as saved).

---

## 7. `lib/main.dart`

### Root Causes
| # | Bug | Impact |
|---|-----|--------|
| 1 | No `FlutterError.onError` | Framework errors silently crash release builds |
| 2 | No `PlatformDispatcher.instance.onError` | Platform/async errors uncaught |
| 3 | No `runZonedGuarded` | Zone-crossing async errors uncaught |

### Fixes
- `runZonedGuarded` wraps the entire app boot.
- `FlutterError.onError` and `PlatformDispatcher.instance.onError` both set up;
  both have TODO stubs for Crashlytics integration.
- `MobileAds.instance.initialize()` wrapped in try-catch; AdMob failure is
  non-fatal.

---

## 8. `lib/widgets/banner_ad_widget.dart` & `native_ad_card.dart`

### Root Causes
| # | Bug | Impact |
|---|-----|--------|
| 1 | `setState()` in ad callback without `mounted` check | `setState` on dead widget crash |
| 2 | `NativeAd` not disposed on widget removal | Memory leak |

### Fixes
- Both widgets check `if (!mounted) return` before `setState`.
- `NativeAd.dispose()` called in `dispose()`.

---

## 9. `android/app/src/main/kotlin/…/MainActivity.kt`

### Root Causes
| # | Bug | Impact |
|---|-----|--------|
| 1 | No `MediaScannerConnection` | Saved files invisible in Gallery until reboot |
| 2 | MediaScanner callback was calling `result.success()` on wrong thread | "Reply already submitted" crash |

### Fixes
- `MethodChannel` `scanFile` registered and wired to `MediaScannerConnection.scanFile`.
- `result.success(null)` called **before** the scanner callback (fire-and-forget).

---

## 10. `AndroidManifest.xml`

### Additions
- `READ_MEDIA_IMAGES` + `READ_MEDIA_VIDEO` for Android 13+.
- `MANAGE_EXTERNAL_STORAGE` with `tools:ignore="ScopedStorage"` for .Statuses access.
- `<queries>` block declaring WhatsApp packages + share intents (required on Android 11+
  for `PackageManager` resolution; absence causes `ActivityNotFoundException` crash).
- `FileProvider` declaration with correct `file_paths.xml` reference.

---

## General Rules Applied Everywhere

1. **No synchronous file I/O in `build()`** — every `*Sync()` call audited and replaced.  
2. **`mounted` check before every `setState()`** — standard Flutter requirement.  
3. **Try-catch around every I/O and ad operation** — failures degrade gracefully.  
4. **Single source of truth** — all magic strings moved to `constants.dart`.  
5. **`copyWith` on `StatusModel`** — immutable updates prevent shared-state bugs.  
6. **`RepaintBoundary` on grid cells** — reduces repaint area during scroll.
