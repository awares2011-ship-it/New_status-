import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';
import 'providers/status_provider.dart';
import 'providers/saved_provider.dart';
import 'providers/theme_provider.dart';
import 'utils/ad_manager.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ── Global error handlers ──────────────────────────────────────────────────
  // Registered before runApp so framework errors are caught from the very start.
  //
  // CRASH FIX: Without these handlers an unhandled exception in a widget build
  // or an async callback shows a red-screen crash in release builds.
  // With them, errors are logged (and can be forwarded to Crashlytics) while
  // the app continues running.
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
    // TODO: Forward to Firebase Crashlytics once integrated:
    // FirebaseCrashlytics.instance.recordFlutterFatalError(details);
    debugPrint('FlutterError: ${details.exceptionAsString()}');
  };

  // Catches async errors that escape the Flutter framework (e.g. isolate
  // errors, Dart zone errors).
  PlatformDispatcher.instance.onError = (Object error, StackTrace stack) {
    // TODO: FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
    debugPrint('Uncaught platform error: $error\n$stack');
    return true; // returning true marks it as handled — app does NOT crash
  };

  // ── AdMob ──────────────────────────────────────────────────────────────────
  // CRASH FIX: Wrap in try-catch — on some devices/emulators the AdMob SDK
  // throws during initialization (e.g. Play Services not updated).
  try {
    await MobileAds.instance.initialize();
  } catch (e) {
    debugPrint('MobileAds init failed (non-fatal): $e');
  }

  // ── System UI ──────────────────────────────────────────────────────────────
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // ── Shared Preferences ─────────────────────────────────────────────────────
  final prefs = await SharedPreferences.getInstance();

  // ── AdManager ─────────────────────────────────────────────────────────────
  // Registers the WidgetsBindingObserver for App Open Ads and loads the first
  // interstitial + app-open ad in the background.
  AdManager.instance.initialize();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider(prefs)),
        ChangeNotifierProvider(create: (_) => StatusProvider()),
        ChangeNotifierProvider(create: (_) => SavedProvider()),
      ],
      child: const StatusSaverApp(),
    ),
  );
}
