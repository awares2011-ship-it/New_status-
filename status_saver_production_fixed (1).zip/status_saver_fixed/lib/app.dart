import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/theme_provider.dart';
import 'screens/splash_screen.dart';
import 'screens/home_screen.dart';
import 'screens/image_viewer_screen.dart';
import 'screens/video_player_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/saved_screen.dart';
import 'models/status_model.dart';

class StatusSaverApp extends StatelessWidget {
  const StatusSaverApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, _) {
        return MaterialApp(
          title: 'Status Saver',
          debugShowCheckedModeBanner: false,
          themeMode: themeProvider.themeMode,
          theme: _buildLightTheme(),
          darkTheme: _buildDarkTheme(),
          initialRoute: '/splash',
          // CRASH FIX: onGenerateRoute with a safe fallback — if any route
          // receives the wrong argument type (e.g. null instead of StatusModel),
          // navigate to HomeScreen instead of throwing a cast exception.
          onGenerateRoute: (settings) {
            switch (settings.name) {
              case '/splash':
                return _fadeRoute(const SplashScreen(), settings);
              case '/home':
                return _fadeRoute(const HomeScreen(), settings);
              case '/saved':
                return _fadeRoute(const SavedScreen(), settings);
              case '/settings':
                return _fadeRoute(const SettingsScreen(), settings);
              case '/image_viewer':
                final status = settings.arguments;
                if (status is! StatusModel) {
                  // Safe fallback — never throws a cast error.
                  return _fadeRoute(const HomeScreen(), settings);
                }
                return _fadeRoute(ImageViewerScreen(status: status), settings);
              case '/video_player':
                final status = settings.arguments;
                if (status is! StatusModel) {
                  return _fadeRoute(const HomeScreen(), settings);
                }
                return _fadeRoute(VideoPlayerScreen(status: status), settings);
              default:
                return _fadeRoute(const HomeScreen(), settings);
            }
          },
        );
      },
    );
  }

  ThemeData _buildLightTheme() {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF25D366),
        primary: const Color(0xFF25D366),
        secondary: const Color(0xFF128C7E),
        tertiary: const Color(0xFF075E54),
        surface: Colors.white,
        brightness: Brightness.light,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF075E54),
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.3,
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: Colors.white,
        indicatorColor: const Color(0xFF25D366).withOpacity(0.15),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return const TextStyle(
                color: Color(0xFF25D366), fontSize: 12, fontWeight: FontWeight.w600);
          }
          return const TextStyle(color: Colors.grey, fontSize: 12);
        }),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return const IconThemeData(color: Color(0xFF25D366));
          }
          return const IconThemeData(color: Colors.grey);
        }),
      ),
      tabBarTheme: const TabBarTheme(
        indicatorColor: Colors.white,
        labelColor: Colors.white,
        unselectedLabelColor: Colors.white70,
        labelStyle: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
        unselectedLabelStyle: TextStyle(fontWeight: FontWeight.normal, fontSize: 14),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: Color(0xFF25D366),
        foregroundColor: Colors.white,
      ),
      cardTheme: CardTheme(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        color: Colors.white,
      ),
      scaffoldBackgroundColor: const Color(0xFFF0F2F5),
      snackBarTheme: const SnackBarThemeData(
        backgroundColor: Color(0xFF075E54),
        contentTextStyle: TextStyle(color: Colors.white),
        behavior: SnackBarBehavior.floating,
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return const Color(0xFF25D366);
          return null;
        }),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return const Color(0xFF25D366);
          return null;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return const Color(0xFF25D366).withOpacity(0.5);
          }
          return null;
        }),
      ),
    );
  }

  ThemeData _buildDarkTheme() {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF25D366),
        primary: const Color(0xFF25D366),
        secondary: const Color(0xFF128C7E),
        tertiary: const Color(0xFF075E54),
        surface: const Color(0xFF1F2C34),
        brightness: Brightness.dark,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF1F2C34),
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.3,
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: const Color(0xFF1F2C34),
        indicatorColor: const Color(0xFF25D366).withOpacity(0.2),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return const TextStyle(
                color: Color(0xFF25D366), fontSize: 12, fontWeight: FontWeight.w600);
          }
          return TextStyle(color: Colors.grey[400], fontSize: 12);
        }),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return const IconThemeData(color: Color(0xFF25D366));
          }
          return const IconThemeData(color: Colors.grey);
        }),
      ),
      tabBarTheme: TabBarTheme(
        indicatorColor: const Color(0xFF25D366),
        labelColor: const Color(0xFF25D366),
        unselectedLabelColor: Colors.grey[400],
        labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
        unselectedLabelStyle:
            const TextStyle(fontWeight: FontWeight.normal, fontSize: 14),
      ),
      scaffoldBackgroundColor: const Color(0xFF0B141A),
      cardTheme: CardTheme(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        color: const Color(0xFF1F2C34),
      ),
      snackBarTheme: const SnackBarThemeData(
        backgroundColor: Color(0xFF25D366),
        contentTextStyle: TextStyle(color: Colors.white),
        behavior: SnackBarBehavior.floating,
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return const Color(0xFF25D366);
          return null;
        }),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return const Color(0xFF25D366);
          return null;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return const Color(0xFF25D366).withOpacity(0.5);
          }
          return null;
        }),
      ),
    );
  }

  PageRoute _fadeRoute(Widget page, RouteSettings settings) {
    return PageRouteBuilder(
      settings: settings,
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, animation, __, child) {
        return FadeTransition(opacity: animation, child: child);
      },
      transitionDuration: const Duration(milliseconds: 250),
    );
  }
}
