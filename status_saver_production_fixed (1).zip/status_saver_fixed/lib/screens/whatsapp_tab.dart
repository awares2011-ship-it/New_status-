import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/status_provider.dart';
import '../utils/permission_utils.dart';
import '../widgets/banner_ad_widget.dart';
import 'images_fragment.dart';
import 'videos_fragment.dart';

class WhatsAppTab extends StatefulWidget {
  const WhatsAppTab({super.key});

  @override
  State<WhatsAppTab> createState() => _WhatsAppTabState();
}

// LIFECYCLE FIX: Mix in WidgetsBindingObserver to detect app resume.
// When the user backgrounds the app (e.g., to open WhatsApp and view
// a status) and then returns, statuses are refreshed automatically.
class _WhatsAppTabState extends State<WhatsAppTab>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late TabController _tabController;

  // Tracks whether the app is currently in the foreground — used to
  // prevent unnecessary refreshes on internal navigation transitions.
  bool _isAppInForeground = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    WidgetsBinding.instance.addObserver(this); // LIFECYCLE FIX

    // Use addPostFrameCallback so the widget tree is fully built before
    // accessing providers or running any async work.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _silentCheckAndLoad();
    });
  }

  // ── App lifecycle ─────────────────────────────────────────────────────────

  /// LIFECYCLE FIX: Auto-refresh statuses when the user returns from
  /// WhatsApp. Only refreshes when permission is already granted and a
  /// previous load succeeded — never interrupts loading or idle states.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _isAppInForeground = false;
    } else if (state == AppLifecycleState.resumed && !_isAppInForeground) {
      _isAppInForeground = true;
      _onAppResumed();
    }
  }

  Future<void> _onAppResumed() async {
    if (!mounted) return;
    final provider = context.read<StatusProvider>();

    // Only auto-refresh if we already have data — don't interrupt a load
    // in progress or show the permission gate again.
    if (provider.state != StatusState.success &&
        provider.state != StatusState.empty) {
      return;
    }

    final hasPermission = await PermissionUtils.hasStoragePermission();
    if (!mounted) return;

    if (hasPermission) {
      provider.refresh();
    }
  }

  // ── Initial load ──────────────────────────────────────────────────────────

  /// Silently checks permission and loads statuses if already granted.
  /// Does NOT show a dialog — the user must press "Grant Permission" for that.
  Future<void> _silentCheckAndLoad() async {
    if (!mounted) return;
    final provider = context.read<StatusProvider>();

    if (provider.state != StatusState.idle) return;

    final hasPermission = await PermissionUtils.hasStoragePermission();
    if (!mounted) return;

    if (hasPermission) {
      provider.loadStatuses();
    }
  }

  // ── Permission request ────────────────────────────────────────────────────

  Future<void> _onGrantPermissionPressed() async {
    final granted = await PermissionUtils.requestStoragePermission();
    if (!mounted) return;

    if (granted) {
      context.read<StatusProvider>().loadStatuses();
    } else {
      final permanentlyDenied = await PermissionUtils.isPermanentlyDenied();
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            permanentlyDenied
                ? 'Permission denied. Enable it in App Settings to continue.'
                : 'Storage permission is required to view WhatsApp statuses.',
          ),
          action: permanentlyDenied
              ? SnackBarAction(
                  label: 'Settings',
                  textColor: Colors.white,
                  onPressed: PermissionUtils.openSettings,
                )
              : null,
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 4),
        ),
      );
    }
  }

  Future<void> _onRefreshPressed() async {
    final hasPermission = await PermissionUtils.hasStoragePermission();
    if (!mounted) return;

    if (hasPermission) {
      context.read<StatusProvider>().refresh();
    } else {
      await _onGrantPermissionPressed();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this); // LIFECYCLE FIX
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<StatusProvider>();
    final isMultiSelect = provider.isMultiSelectMode;

    return Scaffold(
      appBar: AppBar(
        title: isMultiSelect
            ? Text('${provider.selectedCount} selected')
            : const Text('Status Saver'),
        backgroundColor:
            isMultiSelect ? const Color(0xFF128C7E) : const Color(0xFF075E54),
        leading: isMultiSelect
            ? IconButton(
                icon: const Icon(Icons.close),
                tooltip: 'Cancel',
                onPressed: provider.clearSelection,
              )
            : null,
        actions: [
          if (isMultiSelect) ...[
            IconButton(
              icon: const Icon(Icons.select_all),
              tooltip: 'Select All',
              onPressed: () {
                final list = _tabController.index == 0
                    ? provider.imageStatuses
                    : provider.videoStatuses;
                provider.selectAll(list);
              },
            ),
          ] else ...[
            if (provider.state != StatusState.idle && provider.state != StatusState.loading)
              IconButton(
                icon: const Icon(Icons.refresh_rounded),
                tooltip: 'Refresh',
                onPressed: _onRefreshPressed,
              ),
          ],
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.image_outlined, size: 18),
                  const SizedBox(width: 6),
                  Text(
                    provider.state == StatusState.success
                        ? 'Images (${provider.imageStatuses.length})'
                        : 'Images',
                  ),
                ],
              ),
            ),
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.videocam_outlined, size: 18),
                  const SizedBox(width: 6),
                  Text(
                    provider.state == StatusState.success
                        ? 'Videos (${provider.videoStatuses.length})'
                        : 'Videos',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(child: _buildBody(provider)),
          const BannerAdWidget(adKey: 'home'),
        ],
      ),
    );
  }

  Widget _buildBody(StatusProvider provider) {
    switch (provider.state) {
      case StatusState.idle:
        return _PermissionGate(onGrantPressed: _onGrantPermissionPressed);

      case StatusState.loading:
        return Stack(
          children: [
            TabBarView(
              controller: _tabController,
              children: const [ImagesFragment(), VideosFragment()],
            ),
            const Positioned(
              top: 0, left: 0, right: 0,
              child: LinearProgressIndicator(
                backgroundColor: Colors.transparent,
                color: Color(0xFF25D366),
                minHeight: 2,
              ),
            ),
          ],
        );

      case StatusState.success:
      case StatusState.empty:
      case StatusState.error:
        return TabBarView(
          controller: _tabController,
          children: const [ImagesFragment(), VideosFragment()],
        );
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Permission Gate UI
// ─────────────────────────────────────────────────────────────────────────────

class _PermissionGate extends StatelessWidget {
  final VoidCallback onGrantPressed;
  const _PermissionGate({required this.onGrantPressed});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 110, height: 110,
              decoration: BoxDecoration(
                color: const Color(0xFF25D366).withOpacity(0.10),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.lock_open_rounded, size: 56, color: Color(0xFF25D366)),
            ),
            const SizedBox(height: 28),
            Text(
              'Permission Required',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: isDark ? Colors.white : Colors.black87,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(
              'Status Saver needs storage access to read\nWhatsApp statuses on your device.',
              style: TextStyle(fontSize: 14, color: Colors.grey[600], height: 1.6),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            _Step(icon: Icons.chat_bubble_outline_rounded, text: 'Open WhatsApp and view someone\'s status'),
            _Step(icon: Icons.folder_open_rounded, text: 'Grant storage permission below'),
            _Step(icon: Icons.download_done_rounded, text: 'Browse and save statuses from here'),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: onGrantPressed,
                icon: const Icon(Icons.security_rounded, size: 20),
                label: const Text(
                  'Grant Permission',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF25D366),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  elevation: 0,
                ),
              ),
            ),
            const SizedBox(height: 12),
            TextButton.icon(
              onPressed: PermissionUtils.openSettings,
              icon: Icon(Icons.settings_outlined, size: 16, color: Colors.grey[500]),
              label: Text('Open App Settings', style: TextStyle(fontSize: 13, color: Colors.grey[500])),
            ),
          ],
        ),
      ),
    );
  }
}

class _Step extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Step({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xFF25D366), size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: TextStyle(fontSize: 13.5, color: Colors.grey[600], height: 1.4),
            ),
          ),
        ],
      ),
    );
  }
}
