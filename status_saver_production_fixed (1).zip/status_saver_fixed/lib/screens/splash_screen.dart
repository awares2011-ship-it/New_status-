import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/status_provider.dart';
import '../providers/saved_provider.dart';
import '../utils/permission_utils.dart';
import '../utils/constants.dart';

/// Splash screen shown at app startup.
///
/// Pattern:
/// 1. Render instantly (no heavy work in [initState]).
/// 2. Use [addPostFrameCallback] to kick off initialisation after first frame.
/// 3. Run saved-file loading, permission check, and minimum splash timer in
///    parallel — no sequential bottleneck.
/// 4. Navigate to [HomeScreen] and start status loading in the background.
///
/// CRASH FIX: Wrapped [Future.wait] in try-catch.  If any parallel future
/// throws (e.g. permissions plugin unavailable on an unusual device), the app
/// now safely falls through to home instead of crashing with an unhandled
/// exception.  Also added individual error handling per future so one failure
/// cannot cancel the other parallel tasks.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnim;
  late Animation<double> _fadeAnim;
  late Animation<double> _subtitleFade;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _scaleAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
    );

    _fadeAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.5, curve: Curves.easeIn),
      ),
    );

    _subtitleFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.4, 1.0, curve: Curves.easeIn),
      ),
    );

    _controller.forward();

    // Defer heavy work until after the first frame — no blank screen.
    WidgetsBinding.instance.addPostFrameCallback((_) => _initApp());
  }

  Future<void> _initApp() async {
    if (!mounted) return;

    final statusProvider = context.read<StatusProvider>();
    final savedProvider = context.read<SavedProvider>();

    // CRASH FIX: Each future is individually error-handled so one failure
    // cannot propagate through Future.wait and cancel everything else.
    bool hasPermission = false;

    try {
      final results = await Future.wait([
        // Wrap each future so a single failure never kills the group.
        savedProvider.loadSaved().then<dynamic>((_) => null).catchError((e) {
          debugPrint('SplashScreen: loadSaved error — $e');
          return null;
        }),
        PermissionUtils.hasStoragePermission().then<dynamic>((v) => v).catchError((e) {
          debugPrint('SplashScreen: hasStoragePermission error — $e');
          return false;
        }),
        Future<dynamic>.delayed(
          Duration(milliseconds: AppConstants.splashMinMs),
        ),
      ]);

      if (!mounted) return;
      // results[1] is the permission bool (false on error via catchError above).
      hasPermission = (results[1] as bool?) ?? false;
    } catch (e, stack) {
      // Belt-and-suspenders: should not be reachable now that each future has
      // its own catchError, but guard here anyway.
      debugPrint('SplashScreen._initApp fatal: $e\n$stack');
    }

    if (!mounted) return;

    // Navigate first so the transition starts immediately.
    Navigator.of(context).pushReplacementNamed('/home');

    // Kick off status loading in the background — home screen renders
    // instantly and the grid fills in as data arrives.
    if (hasPermission) {
      statusProvider.loadStatuses();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF075E54),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: AnimatedBuilder(
                  animation: _controller,
                  builder: (_, __) {
                    return FadeTransition(
                      opacity: _fadeAnim,
                      child: ScaleTransition(
                        scale: _scaleAnim,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 110,
                              height: 110,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(28),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.2),
                                    blurRadius: 24,
                                    offset: const Offset(0, 8),
                                  ),
                                ],
                              ),
                              child: const Icon(
                                Icons.download_for_offline_rounded,
                                size: 68,
                                color: Color(0xFF25D366),
                              ),
                            ),
                            const SizedBox(height: 24),
                            const Text(
                              'Status Saver',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 32,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.2,
                              ),
                            ),
                            const SizedBox(height: 8),
                            FadeTransition(
                              opacity: _subtitleFade,
                              child: const Text(
                                'Save & Share WhatsApp Statuses',
                                style: TextStyle(
                                  color: Colors.white70,
                                  fontSize: 15,
                                  letterSpacing: 0.3,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(bottom: 48),
              child: Column(
                children: [
                  SizedBox(
                    width: 32, height: 32,
                    child: CircularProgressIndicator(
                      color: Color(0xFF25D366),
                      strokeWidth: 2.5,
                    ),
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Loading…',
                    style: TextStyle(color: Colors.white54, fontSize: 13),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
