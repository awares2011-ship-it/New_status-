import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/status_model.dart';
import '../providers/saved_provider.dart';
import '../utils/ad_manager.dart';

class ImageViewerScreen extends StatefulWidget {
  final StatusModel status;
  const ImageViewerScreen({super.key, required this.status});

  @override
  State<ImageViewerScreen> createState() => _ImageViewerScreenState();
}

class _ImageViewerScreenState extends State<ImageViewerScreen> {
  bool _isSaving = false;
  bool _fileExists = true;
  bool _checked = false;

  @override
  void initState() {
    super.initState();
    // CRASH FIX: Check file existence asynchronously after first frame.
    // Showing an error state is far better than letting Image.file throw
    // and bubble up to Flutter's error boundary.
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkFile());
  }

  Future<void> _checkFile() async {
    try {
      final exists = await File(widget.status.path).exists();
      if (mounted) setState(() { _fileExists = exists; _checked = true; });
    } catch (_) {
      if (mounted) setState(() { _fileExists = false; _checked = true; });
    }
  }

  Future<void> _saveStatus() async {
    if (_isSaving) return;
    setState(() => _isSaving = true);

    final savedProvider = context.read<SavedProvider>();
    final ok = await savedProvider.saveStatus(widget.status);

    if (!mounted) return;
    setState(() => _isSaving = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(ok ? Icons.check_circle : Icons.error_outline,
                color: Colors.white, size: 20),
            const SizedBox(width: 8),
            Text(ok ? 'Image saved to StatusSaver!' : 'Save failed. Try again.'),
          ],
        ),
      ),
    );
    if (ok) AdManager.instance.onDownloadAction();
  }

  Future<void> _shareStatus() async {
    try {
      await Share.shareXFiles([XFile(widget.status.path)],
          text: 'Shared via Status Saver');
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not share file')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.black54,
        foregroundColor: Colors.white,
        title: Text(widget.status.fileName,
            style: const TextStyle(fontSize: 14), overflow: TextOverflow.ellipsis),
        systemOverlayStyle: SystemUiOverlayStyle.light,
        actions: [
          IconButton(
              icon: const Icon(Icons.share_rounded),
              tooltip: 'Share',
              onPressed: _shareStatus),
          IconButton(
            icon: _isSaving
                ? const SizedBox(
                    width: 20, height: 20,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : Icon(widget.status.isSaved
                    ? Icons.check_circle_rounded
                    : Icons.download_rounded),
            onPressed: widget.status.isSaved || _isSaving ? null : _saveStatus,
            tooltip: widget.status.isSaved ? 'Already saved' : 'Save',
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    // Still checking if file exists → show spinner.
    if (!_checked) {
      return const Center(
          child: CircularProgressIndicator(color: Color(0xFF25D366)));
    }

    // File missing → friendly error, not a crash.
    if (!_fileExists) {
      return Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.broken_image_outlined, color: Colors.white54, size: 72),
          const SizedBox(height: 16),
          const Text('Image file not found',
              style: TextStyle(color: Colors.white54, fontSize: 16)),
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Go Back', style: TextStyle(color: Color(0xFF25D366))),
          ),
        ]),
      );
    }

    return Column(
      children: [
        Expanded(
          child: InteractiveViewer(
            minScale: 0.5,
            maxScale: 5.0,
            child: Center(
              child: Image.file(
                File(widget.status.path),
                fit: BoxFit.contain,
                // PERF FIX: Don't cap cacheWidth here — full-res is fine for
                // a single-image viewer; the user may want to zoom in.
                errorBuilder: (_, __, ___) => const Icon(
                    Icons.broken_image_outlined,
                    color: Colors.white54, size: 72),
              ),
            ),
          ),
        ),
        if (!widget.status.isSaved)
          Container(
            color: Colors.black87,
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
            child: Row(
              children: [
                const Icon(Icons.info_outline, color: Colors.white70, size: 16),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text('Tap download to save this image',
                      style: TextStyle(color: Colors.white70, fontSize: 13)),
                ),
                ElevatedButton.icon(
                  onPressed: _isSaving ? null : _saveStatus,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF25D366),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                  ),
                  icon: _isSaving
                      ? const SizedBox(
                          width: 16, height: 16,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2))
                      : const Icon(Icons.download_rounded, size: 18),
                  label: Text(_isSaving ? 'Saving...' : 'Save'),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
