import 'dart:io';
import 'package:flutter/material.dart';

import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/status_model.dart';
import '../providers/saved_provider.dart';
import '../utils/ad_manager.dart';

class VideoPlayerScreen extends StatefulWidget {
  final StatusModel status;
  const VideoPlayerScreen({super.key, required this.status});

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  VideoPlayerController? _videoPlayerController;
  ChewieController? _chewieController;
  bool _isInitialized = false;
  bool _hasError = false;
  bool _isSaving = false;
  String? _errorDetail;

  // Tracks whether init is still running — prevents double-dispose.
  bool _initInProgress = false;

  @override
  void initState() {
    super.initState();
    _initPlayer();
  }

  Future<void> _initPlayer() async {
    if (_initInProgress) return;
    _initInProgress = true;

    try {
      final file = File(widget.status.path);

      // CRASH FIX: Check file existence asynchronously before creating the
      // controller — avoids a confusing "Failed to load" error from the player.
      bool fileExists = false;
      try {
        fileExists = await file.exists();
      } catch (_) {
        fileExists = false;
      }

      if (!mounted) {
        _initInProgress = false;
        return;
      }

      if (!fileExists) {
        setState(() {
          _hasError = true;
          _errorDetail = 'Video file not found on device.';
        });
        _initInProgress = false;
        return;
      }

      _videoPlayerController = VideoPlayerController.file(file);

      try {
        await _videoPlayerController!.initialize();
      } catch (e) {
        // CRASH FIX: Dispose the controller immediately if initialize() throws
        // to avoid a dangling un-initialised controller in dispose().
        _videoPlayerController?.dispose();
        _videoPlayerController = null;
        if (!mounted) {
          _initInProgress = false;
          return;
        }
        setState(() {
          _hasError = true;
          _errorDetail = 'Could not decode this video format.';
        });
        _initInProgress = false;
        return;
      }

      // CRASH FIX: Always check mounted after every await before calling
      // setState or accessing the widget tree.
      if (!mounted) {
        _videoPlayerController?.dispose();
        _videoPlayerController = null;
        _initInProgress = false;
        return;
      }

      _chewieController = ChewieController(
        videoPlayerController: _videoPlayerController!,
        autoPlay: true,
        looping: true,
        allowFullScreen: true,
        allowMuting: true,
        showControlsOnInitialize: true,
        placeholder: const Center(
          child: CircularProgressIndicator(color: Color(0xFF25D366)),
        ),
        materialProgressColors: ChewieProgressColors(
          playedColor: const Color(0xFF25D366),
          handleColor: const Color(0xFF25D366),
          backgroundColor: Colors.white24,
          bufferedColor: Colors.white38,
        ),
        errorBuilder: (context, errorMessage) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline_rounded,
                    color: Colors.white54, size: 64),
                const SizedBox(height: 12),
                Text(
                  'Playback error: $errorMessage',
                  style: const TextStyle(color: Colors.white54),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          );
        },
      );

      if (mounted) {
        setState(() => _isInitialized = true);
      }
    } catch (e) {
      // Belt-and-suspenders catch for any unexpected error path.
      _videoPlayerController?.dispose();
      _videoPlayerController = null;
      if (mounted) {
        setState(() {
          _hasError = true;
          _errorDetail = 'Unexpected error loading video.';
        });
      }
      debugPrint('VideoPlayer unexpected init error: $e');
    } finally {
      _initInProgress = false;
    }
  }

  Future<void> _saveStatus() async {
    if (_isSaving) return;
    setState(() => _isSaving = true);

    final savedProvider = context.read<SavedProvider>();
    final ok = await savedProvider.saveStatus(widget.status);

    if (!mounted) return;
    setState(() => _isSaving = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              ok ? Icons.check_circle : Icons.error_outline,
              color: Colors.white,
              size: 20,
            ),
            const SizedBox(width: 8),
            Text(ok ? 'Video saved to StatusSaver!' : 'Save failed. Try again.'),
          ],
        ),
      ),
    );
    if (ok) AdManager.instance.onDownloadAction();
  }

  Future<void> _shareStatus() async {
    try {
      await Share.shareXFiles(
        [XFile(widget.status.path)],
        text: 'Shared via Status Saver',
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not share file')),
      );
    }
  }

  @override
  void dispose() {
    // CRASH FIX: Dispose ChewieController BEFORE VideoPlayerController.
    // Chewie holds a reference to the video controller and must be released
    // first, otherwise Chewie's internal listeners fire on an already-disposed
    // VideoPlayerController and throw.
    _chewieController?.dispose();
    _videoPlayerController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(
          widget.status.fileName,
          style: const TextStyle(fontSize: 14, color: Colors.white),
          overflow: TextOverflow.ellipsis,
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.share_rounded),
            onPressed: _shareStatus,
            tooltip: 'Share',
          ),
          IconButton(
            icon: _isSaving
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                        color: Colors.white, strokeWidth: 2),
                  )
                : Icon(
                    widget.status.isSaved
                        ? Icons.check_circle_rounded
                        : Icons.download_rounded,
                  ),
            onPressed: widget.status.isSaved || _isSaving ? null : _saveStatus,
            tooltip: widget.status.isSaved ? 'Already saved' : 'Save',
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_hasError) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.videocam_off_outlined,
                  color: Colors.white54, size: 72),
              const SizedBox(height: 16),
              const Text(
                'Unable to play this video',
                style: TextStyle(
                    color: Colors.white54,
                    fontSize: 16,
                    fontWeight: FontWeight.w600),
              ),
              if (_errorDetail != null) ...[
                const SizedBox(height: 8),
                Text(
                  _errorDetail!,
                  style: const TextStyle(color: Colors.white38, fontSize: 13),
                  textAlign: TextAlign.center,
                ),
              ],
            ],
          ),
        ),
      );
    }

    if (!_isInitialized) {
      return const Center(
        child: CircularProgressIndicator(color: Color(0xFF25D366)),
      );
    }

    return Column(
      children: [
        Expanded(child: Chewie(controller: _chewieController!)),
        if (!widget.status.isSaved)
          Container(
            color: Colors.black87,
            padding:
                const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
            child: Row(
              children: [
                const Icon(Icons.info_outline,
                    color: Colors.white70, size: 16),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text(
                    'Tap download to save this video',
                    style:
                        TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                ),
                ElevatedButton.icon(
                  onPressed: _isSaving ? null : _saveStatus,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF25D366),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                  ),
                  icon: _isSaving
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2),
                        )
                      : const Icon(Icons.download_rounded, size: 18),
                  label: Text(_isSaving ? 'Saving...' : 'Save'),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
