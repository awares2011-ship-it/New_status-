import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import '../models/status_model.dart';
import '../providers/status_provider.dart';
import '../providers/saved_provider.dart';
import '../utils/ad_manager.dart';
import '../utils/constants.dart';
import '../widgets/status_card.dart';
import '../widgets/native_ad_card.dart';
import '../widgets/empty_state_widget.dart';

class ImagesFragment extends StatelessWidget {
  const ImagesFragment({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<StatusProvider>(
      builder: (context, provider, _) {
        switch (provider.state) {
          case StatusState.idle:
            return const _EmptyPlaceholder();

          case StatusState.loading:
            return _buildShimmer(context);

          case StatusState.error:
            return EmptyStateWidget(
              icon: Icons.error_outline_rounded,
              title: 'Something went wrong',
              subtitle: provider.errorMessage ??
                  'Could not read status files. Please try again.',
              actionLabel: 'Retry',
              onAction: provider.loadStatuses,
            );

          case StatusState.empty:
            return const EmptyStateWidget(
              icon: Icons.image_search_rounded,
              title: 'No Statuses Found',
              subtitle:
                  'Open WhatsApp and view some statuses,\nthen pull down to refresh.',
            );

          case StatusState.success:
            final images = provider.imageStatuses;
            if (images.isEmpty) {
              return const EmptyStateWidget(
                icon: Icons.photo_outlined,
                title: 'No Image Statuses',
                subtitle:
                    'Open WhatsApp and view image statuses,\nthen pull down to refresh.',
              );
            }
            return _buildGrid(context, provider, images);
        }
      },
    );
  }

  Widget _buildGrid(
    BuildContext context,
    StatusProvider provider,
    List<StatusModel> images,
  ) {
    final items = _interleaveAds(images);

    return RefreshIndicator(
      color: const Color(0xFF25D366),
      onRefresh: provider.refresh,
      child: GridView.builder(
        padding: const EdgeInsets.all(4),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 4,
          mainAxisSpacing: 4,
          childAspectRatio: 0.8,
        ),
        itemCount: items.length,
        addAutomaticKeepAlives: false,
        itemBuilder: (context, index) {
          final item = items[index];
          if (item is _AdSlot) return const NativeAdCard();

          final status = item as StatusModel;
          return StatusCard(
            status: status,
            isSelected: provider.isSelected(status.path),
            isMultiSelectMode: provider.isMultiSelectMode,
            onTap: () {
              if (provider.isMultiSelectMode) {
                provider.toggleSelection(status.path);
              } else {
                // REVENUE FIX: Track preview opens toward the interstitial
                // frequency cap, not just download actions.
                AdManager.instance.onPreviewOpen();
                Navigator.of(context)
                    .pushNamed('/image_viewer', arguments: status);
              }
            },
            onLongPress: () => provider.toggleSelection(status.path),
            onDownload: () => _saveStatus(context, provider, status),
          );
        },
      ),
    );
  }

  List<dynamic> _interleaveAds(List<StatusModel> statuses) {
    final items = <dynamic>[];
    for (var i = 0; i < statuses.length; i++) {
      if (i > 0 && i % AppConstants.nativeAdEveryN == 0) {
        items.add(_AdSlot());
      }
      items.add(statuses[i]);
    }
    return items;
  }

  Future<void> _saveStatus(
    BuildContext context,
    StatusProvider provider,
    StatusModel status,
  ) async {
    final savedProvider = context.read<SavedProvider>();
    final ok = await savedProvider.saveStatus(status);
    if (!context.mounted) return;

    if (ok) {
      provider.updateSavedState(status.path, true);
      AdManager.instance.onDownloadAction();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Row(
            children: [
              Icon(Icons.check_circle, color: Colors.white, size: 20),
              SizedBox(width: 8),
              Text('Image saved to StatusSaver folder'),
            ],
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not save image. Please retry.')),
      );
    }
  }

  Widget _buildShimmer(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Shimmer.fromColors(
      baseColor: isDark ? Colors.grey[800]! : Colors.grey[300]!,
      highlightColor: isDark ? Colors.grey[700]! : Colors.grey[100]!,
      child: GridView.builder(
        padding: const EdgeInsets.all(4),
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 4,
          mainAxisSpacing: 4,
          childAspectRatio: 0.8,
        ),
        itemCount: 15,
        itemBuilder: (_, __) => Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }
}

class _AdSlot {}

class _EmptyPlaceholder extends StatelessWidget {
  const _EmptyPlaceholder();

  @override
  Widget build(BuildContext context) {
    return const EmptyStateWidget(
      icon: Icons.image_search_rounded,
      title: 'No Statuses Yet',
      subtitle: 'Grant permission and open WhatsApp\nto view statuses here.',
    );
  }
}
