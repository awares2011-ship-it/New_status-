import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import '../models/status_model.dart';
import '../providers/saved_provider.dart';
import '../utils/ad_manager.dart';

import '../widgets/status_card.dart';
import '../widgets/banner_ad_widget.dart';
import '../widgets/empty_state_widget.dart';
import 'image_viewer_screen.dart';
import 'video_player_screen.dart';

class SavedScreen extends StatefulWidget {
  const SavedScreen({super.key});
  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen>
    with AutomaticKeepAliveClientMixin, SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    // Banner ad is managed entirely by BannerAdWidget.
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _confirmDeleteSelected(SavedProvider provider) async {
    final count = provider.selectedCount;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Selected'),
        content: Text(
            'Delete $count item${count > 1 ? 's' : ''}? This cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (!mounted || confirmed != true) return;
    final deleted = await provider.deleteSelected();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('$deleted item${deleted > 1 ? 's' : ''} deleted'),
    ));
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Consumer<SavedProvider>(builder: (context, provider, _) {
      final isMultiSelect = provider.isMultiSelectMode;
      return Scaffold(
        appBar: AppBar(
          title: isMultiSelect
              ? Text('${provider.selectedCount} selected')
              : const Text('Saved Statuses'),
          backgroundColor: isMultiSelect
              ? const Color(0xFF128C7E)
              : const Color(0xFF075E54),
          leading: isMultiSelect
              ? IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: provider.clearSelection,
                )
              : null,
          actions: [
            if (isMultiSelect) ...[
              IconButton(
                icon: const Icon(Icons.select_all),
                tooltip: 'Select All',
                onPressed: provider.selectAll,
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline_rounded),
                tooltip: 'Delete Selected',
                onPressed: () => _confirmDeleteSelected(provider),
              ),
            ],
          ],
          bottom: TabBar(
            controller: _tabController,
            tabs: [
              Tab(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.image_outlined, size: 18),
                    const SizedBox(width: 6),
                    Text('Images (${provider.savedImages.length})'),
                  ],
                ),
              ),
              Tab(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.videocam_outlined, size: 18),
                    const SizedBox(width: 6),
                    Text('Videos (${provider.savedVideos.length})'),
                  ],
                ),
              ),
            ],
          ),
        ),
        body: Column(
          children: [
            Expanded(
              child: provider.isLoading
                  ? _buildShimmer(context)
                  : TabBarView(
                      controller: _tabController,
                      children: [
                        _SavedGrid(
                          statuses: provider.savedImages,
                          provider: provider,
                          emptyIcon: Icons.photo_outlined,
                          emptyTitle: 'No Saved Images',
                          emptySubtitle:
                              'Images you save will appear here.',
                        ),
                        _SavedGrid(
                          statuses: provider.savedVideos,
                          provider: provider,
                          emptyIcon: Icons.videocam_outlined,
                          emptyTitle: 'No Saved Videos',
                          emptySubtitle:
                              'Videos you save will appear here.',
                        ),
                      ],
                    ),
            ),
            const BannerAdWidget(adKey: 'saved'),
          ],
        ),
      );
    });
  }

  Widget _buildShimmer(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Shimmer.fromColors(
      baseColor: isDark ? Colors.grey[800]! : Colors.grey[300]!,
      highlightColor: isDark ? Colors.grey[700]! : Colors.grey[100]!,
      child: GridView.builder(
        padding: const EdgeInsets.all(4),
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3, crossAxisSpacing: 4, mainAxisSpacing: 4,
          childAspectRatio: 0.8,
        ),
        itemCount: 9,
        itemBuilder: (_, __) => Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }
}

// ── Saved grid ───────────────────────────────────────────────────────────────

class _SavedGrid extends StatelessWidget {
  final List<StatusModel> statuses;
  final SavedProvider provider;
  final IconData emptyIcon;
  final String emptyTitle;
  final String emptySubtitle;

  const _SavedGrid({
    required this.statuses,
    required this.provider,
    required this.emptyIcon,
    required this.emptyTitle,
    required this.emptySubtitle,
  });

  @override
  Widget build(BuildContext context) {
    if (statuses.isEmpty) {
      return EmptyStateWidget(
          icon: emptyIcon, title: emptyTitle, subtitle: emptySubtitle);
    }

    return RefreshIndicator(
      color: const Color(0xFF25D366),
      onRefresh: provider.loadSaved,
      child: GridView.builder(
        padding: const EdgeInsets.all(4),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3, crossAxisSpacing: 4, mainAxisSpacing: 4,
          childAspectRatio: 0.8,
        ),
        itemCount: statuses.length,
        addAutomaticKeepAlives: false,
        itemBuilder: (context, index) {
          final status = statuses[index];
          return StatusCard(
            status: status,
            isSelected: provider.isSelected(status.path),
            isMultiSelectMode: provider.isMultiSelectMode,
            showDeleteButton: true,
            onTap: () {
              if (provider.isMultiSelectMode) {
                provider.toggleSelection(status.path);
              } else {
                AdManager.instance.onPreviewOpen();
                if (status.type == StatusType.video) {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => VideoPlayerScreen(status: status),
                  ));
                } else {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => ImageViewerScreen(status: status),
                  ));
                }
              }
            },
            onLongPress: () => provider.toggleSelection(status.path),
            onDelete: () => _confirmDelete(context, provider, status),
          );
        },
      ),
    );
  }

  Future<void> _confirmDelete(
    BuildContext context,
    SavedProvider provider,
    StatusModel status,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete File'),
        content: const Text('Delete this file? This cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (!context.mounted || confirmed != true) return;
    await provider.deleteStatus(status);
  }
}
