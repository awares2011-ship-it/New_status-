import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/status_provider.dart';
import 'whatsapp_tab.dart';
import 'saved_screen.dart';
import 'settings_screen.dart';

/// Root scaffold that hosts the bottom navigation bar and the three main tabs.
///
/// Uses [IndexedStack] so each tab preserves its scroll state across switches.
///
/// CRASH FIX: context.select is scoped to just [newStatusCount] so the
/// entire HomeScreen does not rebuild every time StatusProvider emits — only
/// the badge area does.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  // Kept in a list so IndexedStack preserves tab state across navigations.
  static const List<Widget> _screens = [
    WhatsAppTab(),
    SavedScreen(),
    SettingsScreen(),
  ];

  void _onTabSelected(int index) {
    if (_currentIndex == index) return;
    setState(() => _currentIndex = index);

    // Clear the new-status badge when the user switches to the WhatsApp tab.
    if (index == 0) {
      context.read<StatusProvider>().clearNewStatusCount();
    }
  }

  @override
  Widget build(BuildContext context) {
    // Use context.select so only the badge rebuilds when newStatusCount changes.
    final newCount = context.select<StatusProvider, int>(
      (p) => p.newStatusCount,
    );

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: _onTabSelected,
        destinations: [
          NavigationDestination(
            icon: Badge(
              isLabelVisible: newCount > 0,
              label: Text(
                newCount > 99 ? '99+' : '$newCount',
                style: const TextStyle(fontSize: 10),
              ),
              child: const Icon(Icons.chat_bubble_outline_rounded),
            ),
            selectedIcon: Badge(
              isLabelVisible: newCount > 0,
              label: Text(
                newCount > 99 ? '99+' : '$newCount',
                style: const TextStyle(fontSize: 10),
              ),
              child: const Icon(Icons.chat_bubble_rounded),
            ),
            label: 'WhatsApp',
          ),
          const NavigationDestination(
            icon: Icon(Icons.save_alt_outlined),
            selectedIcon: Icon(Icons.save_alt_rounded),
            label: 'Saved',
          ),
          const NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings_rounded),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}
