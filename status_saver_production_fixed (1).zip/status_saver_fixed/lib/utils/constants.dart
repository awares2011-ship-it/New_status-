/// Central constants file — no magic strings anywhere else in the codebase.
///
/// Replace all Ad Unit IDs with your real production IDs before publishing.
/// The IDs below are Google's official test IDs and will always return test ads.
class AppConstants {
  AppConstants._();

  // ── App info ───────────────────────────────────────────────────────────────
  static const String appName = 'Status Saver';
  static const String appVersion = '1.0.1';

  // ── WhatsApp status directories ────────────────────────────────────────────
  static const List<String> whatsappStatusPaths = [
    '/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/.Statuses',
    '/storage/emulated/0/WhatsApp/Media/.Statuses',
    '/sdcard/WhatsApp/Media/.Statuses',
    '/sdcard/Android/media/com.whatsapp/WhatsApp/Media/.Statuses',
  ];

  static const List<String> whatsappBusinessStatusPaths = [
    '/storage/emulated/0/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses',
    '/storage/emulated/0/WhatsApp Business/Media/.Statuses',
    '/sdcard/WhatsApp Business/Media/.Statuses',
  ];

  // ── Save directory ─────────────────────────────────────────────────────────
  static const String savePath = '/storage/emulated/0/Pictures/StatusSaver';

  // ── File extensions ────────────────────────────────────────────────────────
  static const List<String> imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
  static const List<String> videoExtensions = ['.mp4', '.mkv', '.avi', '.mov', '.3gp'];

  // ── AdMob unit IDs ─────────────────────────────────────────────────────────
  // TODO: Replace with your real production IDs before publishing.
  static const String bannerAdUnitId      = 'ca-app-pub-3940256099942544/6300978111';
  static const String interstitialAdUnitId = 'ca-app-pub-3940256099942544/1033173712';
  static const String nativeAdUnitId      = 'ca-app-pub-3940256099942544/2247696110';
  static const String appOpenAdUnitId     = 'ca-app-pub-3940256099942544/9257395921';

  // ── Ad behaviour ───────────────────────────────────────────────────────────
  static const int interstitialShowAfter      = 3;   // actions before showing
  static const int interstitialCooldownSeconds = 120; // min seconds between ads
  static const int adRetrySeconds             = 30;   // retry delay on failure
  static const int nativeAdEveryN             = 9;    // grid items between native ads
  static const int appOpenAdCooldownHours     = 4;    // min hours between app-open ads

  // ── SharedPreferences keys ─────────────────────────────────────────────────
  static const String prefLastInterstitialMs = 'last_interstitial_ms';
  static const String prefLastAppOpenAd      = 'last_app_open_ad_ms';
  static const String prefThemeMode          = 'theme_mode';
  // Used by ThemeProvider:
  static const String prefDarkMode  = 'dark_mode';
  static const String prefAutoSave  = 'auto_save';

  // ── Splash ─────────────────────────────────────────────────────────────────
  static const int splashMinMs = 1500;

  // ── UI grid ────────────────────────────────────────────────────────────────
  static const double gridCrossAxisSpacing = 4.0;
  static const double gridMainAxisSpacing  = 4.0;
  static const double gridChildAspectRatio = 0.8;
  static const int    gridCrossAxisCount   = 3;

  // ── Links ──────────────────────────────────────────────────────────────────
  static const String privacyPolicyUrl =
      'https://your-domain.com/privacy-policy';
  static const String playStoreUrl =
      'https://play.google.com/store/apps/details?id=com.yourname.statussaver';
}
