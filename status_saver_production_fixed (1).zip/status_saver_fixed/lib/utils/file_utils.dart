import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'constants.dart';

class FileUtils {
  FileUtils._();

  static const _mediaChannel = MethodChannel('com.yourname.statussaver/media');

  // ── Directory ─────────────────────────────────────────────────────────────

  static Future<Directory> getSaveDirectory() async {
    final dir = Directory(AppConstants.savePath);
    try {
      if (!await dir.exists()) {
        await dir.create(recursive: true);
      }
    } catch (e) {
      if (kDebugMode) print('getSaveDirectory: could not create dir — $e');
    }
    return dir;
  }

  // ── Save ──────────────────────────────────────────────────────────────────

  static Future<String?> saveStatus(String sourcePath) async {
    try {
      final sourceFile = File(sourcePath);
      if (!await sourceFile.exists()) {
        if (kDebugMode) print('Source does not exist: $sourcePath');
        return null;
      }

      final saveDir = await getSaveDirectory();
      final fileName = sourcePath.split('/').last;
      final destPath = '${saveDir.path}/$fileName';

      if (await File(destPath).exists()) return destPath;

      final savedFile = await sourceFile.copy(destPath);
      await _scanFile(savedFile.path);
      return savedFile.path;
    } catch (e) {
      if (kDebugMode) print('Error saving status: $e');
      return null;
    }
  }

  static Future<void> _scanFile(String filePath) async {
    try {
      await _mediaChannel.invokeMethod<void>('scanFile', {'path': filePath});
    } on MissingPluginException {
      if (kDebugMode) print('MediaScanner channel not available');
    } catch (e) {
      if (kDebugMode) print('Media scan failed (non-fatal): $e');
    }
  }

  // ── Delete ────────────────────────────────────────────────────────────────

  static Future<bool> deleteFile(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        await file.delete();
        return true;
      }
      return false;
    } catch (e) {
      if (kDebugMode) print('Error deleting file: $e');
      return false;
    }
  }

  // ── List ──────────────────────────────────────────────────────────────────

  /// Returns all saved status files, newest first.
  ///
  /// CRASH FIX: Replaced synchronous listSync() with async dir.list() so
  /// this method never blocks the UI thread.
  ///
  /// CRASH FIX: Per-file try-catch around lastModified() so a single
  /// disappearing file (race condition) cannot crash the whole list.
  static Future<List<File>> getSavedFiles() async {
    try {
      final saveDir = await getSaveDirectory();
      if (!await saveDir.exists()) return [];

      final List<FileSystemEntity> entities;
      try {
        // ASYNC FIX: Use await + toList() instead of listSync().
        entities = await saveDir.list(followLinks: false).toList();
      } on FileSystemException catch (e) {
        if (kDebugMode) print('Permission denied reading save dir: $e');
        return [];
      }

      final files = entities
          .whereType<File>()
          .where((f) {
            final lower = f.path.toLowerCase();
            return AppConstants.imageExtensions.any((ext) => lower.endsWith(ext)) ||
                AppConstants.videoExtensions.any((ext) => lower.endsWith(ext));
          })
          .toList();

      // CRASH FIX: Wrap per-file date read in try-catch.
      // A file may be deleted between listing and stat — fall back to epoch.
      files.sort((a, b) {
        DateTime aDate, bDate;
        try { aDate = a.lastModifiedSync(); } catch (_) { aDate = DateTime(0); }
        try { bDate = b.lastModifiedSync(); } catch (_) { bDate = DateTime(0); }
        return bDate.compareTo(aDate);
      });

      return files;
    } catch (e) {
      if (kDebugMode) print('Error getting saved files: $e');
      return [];
    }
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  static Future<bool> isAlreadySaved(String sourcePath) async {
    try {
      final fileName = sourcePath.split('/').last;
      final destPath = '${AppConstants.savePath}/$fileName';
      return File(destPath).exists();
    } catch (_) {
      return false;
    }
  }

  static String getFileSize(String filePath) {
    try {
      final bytes = File(filePath).lengthSync();
      if (bytes < 1024) return '${bytes}B';
      if (bytes < 1048576) return '${(bytes / 1024).toStringAsFixed(1)}KB';
      return '${(bytes / 1048576).toStringAsFixed(1)}MB';
    } catch (_) {
      return '';
    }
  }

  static bool isVideo(String path) {
    final lower = path.toLowerCase();
    return AppConstants.videoExtensions.any((ext) => lower.endsWith(ext));
  }

  static bool isImage(String path) {
    final lower = path.toLowerCase();
    return AppConstants.imageExtensions.any((ext) => lower.endsWith(ext));
  }
}
