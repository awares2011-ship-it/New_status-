
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'constants.dart';

/// Singleton that manages all AdMob ad types for the app.
///
/// Design goals:
/// * Preload ads so they are ready when needed.
/// * Never block the UI thread.
/// * Prevent ad spam with frequency caps.
/// * Handle failures gracefully — the app must work without ads.
/// * App Open Ads only fire on genuine foreground resumes, never on
///   in-app navigation transitions.
///
/// CRASH FIX: All ad callbacks are individually wrapped in try-catch.
/// A bad ad SDK callback (e.g. from a test environment) can no longer
/// crash the app.
class AdManager with WidgetsBindingObserver {
  AdManager._internal();
  static final AdManager instance = AdManager._internal();

  // ── Ad objects ─────────────────────────────────────────────────────────────
  BannerAd? _homeBannerAd;
  BannerAd? _savedBannerAd;
  InterstitialAd? _interstitialAd;
  AppOpenAd? _appOpenAd;

  // ── Load state ─────────────────────────────────────────────────────────────
  bool _isHomeBannerLoaded = false;
  bool _isSavedBannerLoaded = false;
  bool _isInterstitialLoaded = false;
  bool _isAppOpenAdAvailable = false;

  // ── Guards ─────────────────────────────────────────────────────────────────
  bool _isShowingAppOpenAd = false;
  bool _isShowingFullScreenAd = false;
  int _actionCounter = 0;
  bool _initialised = false;
  int _lastInterstitialMs = 0;

  // ── Getters ────────────────────────────────────────────────────────────────
  BannerAd? get homeBannerAd => _homeBannerAd;
  BannerAd? get savedBannerAd => _savedBannerAd;
  bool get isHomeBannerLoaded => _isHomeBannerLoaded;
  bool get isSavedBannerLoaded => _isSavedBannerLoaded;

  // ── Initialization ─────────────────────────────────────────────────────────

  void initialize() {
    if (_initialised) return;
    _initialised = true;
    try {
      WidgetsBinding.instance.addObserver(this);
      _loadLastInterstitialTime();
      loadInterstitial();
      loadAppOpenAd();
    } catch (e) {
      if (kDebugMode) print('AdManager.initialize error: $e');
    }
  }

  Future<void> _loadLastInterstitialTime() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _lastInterstitialMs =
          prefs.getInt(AppConstants.prefLastInterstitialMs) ?? 0;
    } catch (_) {}
  }

  // ── App Lifecycle ──────────────────────────────────────────────────────────

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    try {
      if (state == AppLifecycleState.resumed && !_isShowingFullScreenAd) {
        showAppOpenAd();
      }
    } catch (e) {
      if (kDebugMode) print('AdManager lifecycle error: $e');
    }
  }

  // ── Banner Ads ─────────────────────────────────────────────────────────────

  void loadHomeBanner({VoidCallback? onLoaded}) {
    try {
      _homeBannerAd?.dispose();
      _isHomeBannerLoaded = false;
      _homeBannerAd = _buildBanner(
        onLoaded: () {
          _isHomeBannerLoaded = true;
          onLoaded?.call();
        },
        onFailed: () {
          _isHomeBannerLoaded = false;
          _homeBannerAd = null;
        },
      );
      _homeBannerAd!.load();
    } catch (e) {
      if (kDebugMode) print('loadHomeBanner error: $e');
    }
  }

  void loadSavedBanner({VoidCallback? onLoaded}) {
    try {
      _savedBannerAd?.dispose();
      _isSavedBannerLoaded = false;
      _savedBannerAd = _buildBanner(
        onLoaded: () {
          _isSavedBannerLoaded = true;
          onLoaded?.call();
        },
        onFailed: () {
          _isSavedBannerLoaded = false;
          _savedBannerAd = null;
        },
      );
      _savedBannerAd!.load();
    } catch (e) {
      if (kDebugMode) print('loadSavedBanner error: $e');
    }
  }

  BannerAd _buildBanner({
    required VoidCallback onLoaded,
    required VoidCallback onFailed,
  }) {
    return BannerAd(
      adUnitId: AppConstants.bannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) {
          try { onLoaded(); } catch (_) {}
        },
        onAdFailedToLoad: (ad, error) {
          try {
            ad.dispose();
            onFailed();
            if (kDebugMode) print('Banner failed: $error');
          } catch (_) {}
        },
      ),
    );
  }

  void disposeHomeBanner() {
    try {
      _homeBannerAd?.dispose();
      _homeBannerAd = null;
      _isHomeBannerLoaded = false;
    } catch (_) {}
  }

  void disposeSavedBanner() {
    try {
      _savedBannerAd?.dispose();
      _savedBannerAd = null;
      _isSavedBannerLoaded = false;
    } catch (_) {}
  }

  // ── Interstitial Ad ────────────────────────────────────────────────────────

  void loadInterstitial() {
    try {
      InterstitialAd.load(
        adUnitId: AppConstants.interstitialAdUnitId,
        request: const AdRequest(),
        adLoadCallback: InterstitialAdLoadCallback(
          onAdLoaded: (ad) {
            try {
              _interstitialAd = ad;
              _isInterstitialLoaded = true;
              _interstitialAd!.setImmersiveMode(true);
              if (kDebugMode) print('Interstitial loaded');
            } catch (_) {}
          },
          onAdFailedToLoad: (error) {
            _isInterstitialLoaded = false;
            _interstitialAd = null;
            if (kDebugMode) print('Interstitial failed: $error');
            Future.delayed(
              Duration(seconds: AppConstants.adRetrySeconds),
              () { try { loadInterstitial(); } catch (_) {} },
            );
          },
        ),
      );
    } catch (e) {
      if (kDebugMode) print('loadInterstitial error: $e');
    }
  }

  /// Call after every user download action OR preview open.
  /// Shows interstitial once every [AppConstants.interstitialShowAfter] actions.
  void onDownloadAction() => _trackAction();

  /// Separate counter for preview opens so both event types count toward
  /// the interstitial threshold, maximising revenue without spamming.
  void onPreviewOpen() => _trackAction();

  void _trackAction() {
    try {
      _actionCounter++;
      if (_actionCounter >= AppConstants.interstitialShowAfter) {
        _actionCounter = 0;
        final nowMs = DateTime.now().millisecondsSinceEpoch;
        final cooldownMs = AppConstants.interstitialCooldownSeconds * 1000;
        if (nowMs - _lastInterstitialMs >= cooldownMs) {
          showInterstitial();
        }
      }
    } catch (e) {
      if (kDebugMode) print('_trackAction error: $e');
    }
  }

  void showInterstitial({VoidCallback? onDismissed}) {
    if (!_isInterstitialLoaded || _interstitialAd == null) {
      onDismissed?.call();
      return;
    }

    try {
      _isShowingFullScreenAd = true;
      _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (ad) {
          try {
            _isShowingFullScreenAd = false;
            ad.dispose();
            _interstitialAd = null;
            _isInterstitialLoaded = false;
            _recordInterstitialTime();
            loadInterstitial();
            onDismissed?.call();
          } catch (_) {}
        },
        onAdFailedToShowFullScreenContent: (ad, error) {
          try {
            _isShowingFullScreenAd = false;
            ad.dispose();
            _interstitialAd = null;
            _isInterstitialLoaded = false;
            loadInterstitial();
            onDismissed?.call();
            if (kDebugMode) print('Interstitial show failed: $error');
          } catch (_) {}
        },
      );
      _interstitialAd!.show();
    } catch (e) {
      _isShowingFullScreenAd = false;
      if (kDebugMode) print('showInterstitial error: $e');
      onDismissed?.call();
    }
  }

  Future<void> _recordInterstitialTime() async {
    _lastInterstitialMs = DateTime.now().millisecondsSinceEpoch;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(AppConstants.prefLastInterstitialMs, _lastInterstitialMs);
    } catch (_) {}
  }

  // ── Native Ad ──────────────────────────────────────────────────────────────

  NativeAd createNativeAd({required NativeAdListener listener}) {
    return NativeAd(
      adUnitId: AppConstants.nativeAdUnitId,
      factoryId: 'listTile',
      request: const AdRequest(),
      listener: listener,
    );
  }

  // ── App Open Ad ────────────────────────────────────────────────────────────

  void loadAppOpenAd() {
    try {
      AppOpenAd.load(
        adUnitId: AppConstants.appOpenAdUnitId,
        request: const AdRequest(),
        adLoadCallback: AppOpenAdLoadCallback(
          onAdLoaded: (ad) {
            try {
              _appOpenAd = ad;
              _isAppOpenAdAvailable = true;
              if (kDebugMode) print('App Open Ad loaded');
            } catch (_) {}
          },
          onAdFailedToLoad: (error) {
            _isAppOpenAdAvailable = false;
            _appOpenAd = null;
            if (kDebugMode) print('App Open Ad failed: $error');
          },
        ),
      );
    } catch (e) {
      if (kDebugMode) print('loadAppOpenAd error: $e');
    }
  }

  Future<void> showAppOpenAd() async {
    if (!_isAppOpenAdAvailable ||
        _appOpenAd == null ||
        _isShowingAppOpenAd ||
        _isShowingFullScreenAd) {
      return;
    }

    try {
      // Cooldown check — do not spam the user every time they alt-tab.
      final prefs = await SharedPreferences.getInstance();
      final lastShown = prefs.getInt(AppConstants.prefLastAppOpenAd) ?? 0;
      final nowMs = DateTime.now().millisecondsSinceEpoch;
      final cooldownMs = AppConstants.appOpenAdCooldownHours * 60 * 60 * 1000;

      if (nowMs - lastShown < cooldownMs) {
        if (kDebugMode) print('App Open Ad on cooldown');
        return;
      }

      // Re-check after the await — state may have changed.
      if (!_isAppOpenAdAvailable || _appOpenAd == null || _isShowingFullScreenAd) return;

      _isShowingAppOpenAd = true;
      _isShowingFullScreenAd = true;

      _appOpenAd!.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (ad) {
          try {
            _isShowingAppOpenAd = false;
            _isShowingFullScreenAd = false;
            ad.dispose();
            _appOpenAd = null;
            _isAppOpenAdAvailable = false;
            prefs.setInt(AppConstants.prefLastAppOpenAd, DateTime.now().millisecondsSinceEpoch);
            loadAppOpenAd();
          } catch (_) {}
        },
        onAdFailedToShowFullScreenContent: (ad, error) {
          try {
            _isShowingAppOpenAd = false;
            _isShowingFullScreenAd = false;
            ad.dispose();
            _appOpenAd = null;
            _isAppOpenAdAvailable = false;
            loadAppOpenAd();
            if (kDebugMode) print('App Open Ad show failed: $error');
          } catch (_) {}
        },
      );

      _appOpenAd!.show();
    } catch (e) {
      _isShowingAppOpenAd = false;
      _isShowingFullScreenAd = false;
      if (kDebugMode) print('showAppOpenAd error: $e');
    }
  }

  // ── Cleanup ────────────────────────────────────────────────────────────────

  void dispose() {
    try {
      WidgetsBinding.instance.removeObserver(this);
      _homeBannerAd?.dispose();
      _savedBannerAd?.dispose();
      _interstitialAd?.dispose();
      _appOpenAd?.dispose();
    } catch (_) {}
  }
}
