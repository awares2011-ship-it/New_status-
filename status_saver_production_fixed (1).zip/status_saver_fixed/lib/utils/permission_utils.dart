import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';

/// Centralises all runtime-permission logic.
///
/// CRASH FIX: Every public method is wrapped in try-catch so that an
/// unexpected PermissionHandler platform exception (e.g. on a heavily
/// customised OEM ROM) can never crash the app.  The safe default on error
/// is always "permission not granted" — the UI will show the permission gate.
class PermissionUtils {
  PermissionUtils._();

  // ── Status checks ──────────────────────────────────────────────────────────

  /// Returns true if the app currently has the necessary storage permission.
  static Future<bool> hasStoragePermission() async {
    try {
      // Android 13+ uses READ_MEDIA_IMAGES + READ_MEDIA_VIDEO.
      // Earlier versions use READ_EXTERNAL_STORAGE.
      // permission_handler abstracts this, but we check both paths.
      final storageStatus = await Permission.storage.status;
      if (storageStatus.isGranted) return true;

      final mediaImages = await Permission.photos.status;
      final mediaVideo = await Permission.videos.status;
      if (mediaImages.isGranted && mediaVideo.isGranted) return true;

      // MANAGE_EXTERNAL_STORAGE (Android 11+ broad access).
      final manageStatus =
          await Permission.manageExternalStorage.status;
      return manageStatus.isGranted;
    } catch (e) {
      debugPrint('PermissionUtils.hasStoragePermission error: $e');
      return false;
    }
  }

  /// Requests storage permission and returns whether it was granted.
  ///
  /// Handles the Android 13 split (READ_MEDIA_IMAGES / READ_MEDIA_VIDEO)
  /// vs the legacy READ_EXTERNAL_STORAGE automatically.
  static Future<bool> requestStoragePermission() async {
    try {
      // Try the media-specific permissions first (Android 13+).
      final mediaImages = await Permission.photos.request();
      final mediaVideo = await Permission.videos.request();
      if (mediaImages.isGranted && mediaVideo.isGranted) return true;

      // Fall back to broad READ_EXTERNAL_STORAGE (Android 8–12).
      final storageStatus = await Permission.storage.request();
      if (storageStatus.isGranted) return true;

      // Last resort: MANAGE_EXTERNAL_STORAGE (Android 11+).
      final manageStatus =
          await Permission.manageExternalStorage.request();
      return manageStatus.isGranted;
    } catch (e) {
      debugPrint('PermissionUtils.requestStoragePermission error: $e');
      return false;
    }
  }

  /// Returns true if storage permission is permanently denied (user tapped
  /// "Don't ask again").  In this state the only remedy is opening Settings.
  static Future<bool> isPermanentlyDenied() async {
    try {
      final storage = await Permission.storage.isPermanentlyDenied;
      final photos = await Permission.photos.isPermanentlyDenied;
      final videos = await Permission.videos.isPermanentlyDenied;
      // If ANY of the required permissions is permanently denied, surface
      // the "Open Settings" button.
      return storage || photos || videos;
    } catch (e) {
      debugPrint('PermissionUtils.isPermanentlyDenied error: $e');
      return false;
    }
  }

  /// Opens the app's system settings page so the user can manually grant
  /// a permanently-denied permission.
  static Future<void> openSettings() async {
    try {
      await openAppSettings();
    } catch (e) {
      debugPrint('PermissionUtils.openSettings error: $e');
    }
  }
}
