import 'dart:io';
import 'package:flutter/foundation.dart';
import '../models/status_model.dart';
import '../utils/constants.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Isolate payload — must be a top-level class (no closures) for [compute].
// ─────────────────────────────────────────────────────────────────────────────

class _ScanPayload {
  final String dirPath;
  final bool isFromBusiness;
  final Set<String> alreadySavedNames;

  const _ScanPayload(this.dirPath, this.isFromBusiness, this.alreadySavedNames);
}

/// Top-level — runs inside an isolate via [compute].
List<StatusModel> _scanDirectory(_ScanPayload payload) {
  const imageExts = {'.jpg', '.jpeg', '.png', '.gif', '.webp'};
  const videoExts = {'.mp4', '.mkv', '.avi', '.mov', '.3gp'};

  final result = <StatusModel>[];
  try {
    final dir = Directory(payload.dirPath);

    bool exists = false;
    try {
      exists = dir.existsSync();
    } catch (_) {
      return result;
    }
    if (!exists) return result;

    List<FileSystemEntity> entities;
    try {
      entities = dir.listSync(followLinks: false);
    } on FileSystemException catch (e) {
      if (kDebugMode) print('WA dir read error [${payload.dirPath}]: $e');
      return result;
    }

    for (final entity in entities) {
      if (entity is! File) continue;
      final path = entity.path;
      if (path.endsWith('.nomedia')) continue;

      final lower = path.toLowerCase();
      final isImage = imageExts.any(lower.endsWith);
      final isVideo = videoExts.any(lower.endsWith);
      if (!isImage && !isVideo) continue;

      DateTime date;
      try {
        date = entity.lastModifiedSync();
      } catch (_) {
        date = DateTime.now();
      }

      final fileName = path.split('/').last;
      result.add(StatusModel(
        path: path,
        type: isVideo ? StatusType.video : StatusType.image,
        date: date,
        isFromBusiness: payload.isFromBusiness,
        isSaved: payload.alreadySavedNames.contains(fileName),
      ));
    }

    result.sort((a, b) => b.date.compareTo(a.date));
  } catch (e) {
    if (kDebugMode) print('_scanDirectory error [${payload.dirPath}]: $e');
  }
  return result;
}

/// Top-level — reads saved filenames in an isolate.
Set<String> _readSavedNames(String savePath) {
  try {
    final dir = Directory(savePath);
    bool exists = false;
    try {
      exists = dir.existsSync();
    } catch (_) {
      return {};
    }
    if (!exists) return {};
    return dir
        .listSync(followLinks: false)
        .whereType<File>()
        .map((f) => f.path.split('/').last)
        .toSet();
  } catch (_) {
    return {};
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Change-detection payload — top-level for compute.
// ─────────────────────────────────────────────────────────────────────────────

class _DirSnapshotPayload {
  final List<String> dirPaths;
  const _DirSnapshotPayload(this.dirPaths);
}

/// Computes a quick snapshot (count + latest mtime) for a list of directories.
/// Runs in an isolate to keep the UI thread free.
Map<String, dynamic> _takeDirSnapshot(_DirSnapshotPayload payload) {
  int totalCount = 0;
  int latestMtimeMs = 0;

  for (final dirPath in payload.dirPaths) {
    try {
      final dir = Directory(dirPath);
      if (!dir.existsSync()) continue;
      final entities = dir.listSync(followLinks: false).whereType<File>().toList();
      totalCount += entities.length;
      for (final f in entities) {
        try {
          final ms = f.lastModifiedSync().millisecondsSinceEpoch;
          if (ms > latestMtimeMs) latestMtimeMs = ms;
        } catch (_) {}
      }
    } catch (_) {}
  }

  return {'count': totalCount, 'mtime': latestMtimeMs};
}

// ─────────────────────────────────────────────────────────────────────────────
// Service
// ─────────────────────────────────────────────────────────────────────────────

/// Scans every known WhatsApp / WA-Business status folder.
///
/// All heavy file I/O runs inside [compute] (Dart isolates) so the UI thread
/// is never blocked.
///
/// PERF: Change detection — stores the last snapshot (file count + newest
/// mtime). If [fetchAllStatuses] is called again and the snapshot is identical,
/// the cached results are returned immediately instead of re-scanning.
class WhatsAppService {
  WhatsAppService._();
  static final WhatsAppService instance = WhatsAppService._();

  // ── Change-detection cache ─────────────────────────────────────────────────
  List<StatusModel>? _cachedStatuses;
  int _lastSnapshotCount = -1;
  int _lastSnapshotMtimeMs = -1;

  // All watched directories combined for snapshot.
  static List<String> get _allDirs => [
    ...AppConstants.whatsappStatusPaths,
    ...AppConstants.whatsappBusinessStatusPaths,
  ];

  /// Fetches all statuses — returns cached results if nothing has changed.
  Future<List<StatusModel>> fetchAllStatuses() async {
    // Step 1 — quick snapshot to detect changes.
    final snapshot = await compute<_DirSnapshotPayload, Map<String, dynamic>>(
      _takeDirSnapshot,
      _DirSnapshotPayload(_allDirs),
    );

    final newCount = (snapshot['count'] as int?) ?? 0;
    final newMtime = (snapshot['mtime'] as int?) ?? 0;

    // Return cached list if nothing changed since last scan.
    if (_cachedStatuses != null &&
        newCount == _lastSnapshotCount &&
        newMtime == _lastSnapshotMtimeMs) {
      if (kDebugMode) print('WhatsAppService: cache hit, skipping re-scan');
      return _cachedStatuses!;
    }

    // Step 2 — collect already-saved filenames off the UI thread.
    final savedNames = await compute<String, Set<String>>(
      _readSavedNames,
      AppConstants.savePath,
    );

    // Step 3 — fan out to a separate isolate per directory.
    final scanFutures = <Future<List<StatusModel>>>[];

    for (final dirPath in AppConstants.whatsappStatusPaths) {
      scanFutures.add(
        compute(_scanDirectory, _ScanPayload(dirPath, false, savedNames)),
      );
    }
    for (final dirPath in AppConstants.whatsappBusinessStatusPaths) {
      scanFutures.add(
        compute(_scanDirectory, _ScanPayload(dirPath, true, savedNames)),
      );
    }

    // Step 4 — merge + dedup by filename.
    final results = await Future.wait(scanFutures);
    final allStatuses = <StatusModel>[];
    final seenNames = <String>{};

    for (final list in results) {
      for (final status in list) {
        final name = status.path.split('/').last;
        if (seenNames.add(name)) {
          allStatuses.add(status);
        }
      }
    }

    allStatuses.sort((a, b) => b.date.compareTo(a.date));

    // Update cache.
    _cachedStatuses = allStatuses;
    _lastSnapshotCount = newCount;
    _lastSnapshotMtimeMs = newMtime;

    return allStatuses;
  }

  /// Invalidates the cache — forces a full re-scan on the next call.
  void invalidateCache() {
    _cachedStatuses = null;
    _lastSnapshotCount = -1;
    _lastSnapshotMtimeMs = -1;
  }

  // ── Installation checks ───────────────────────────────────────────────────

  Future<bool> isWhatsAppInstalled() async {
    for (final path in AppConstants.whatsappStatusPaths) {
      try {
        if (Directory(path).existsSync()) return true;
      } catch (_) {}
    }
    return false;
  }

  Future<bool> isWhatsAppBusinessInstalled() async {
    for (final path in AppConstants.whatsappBusinessStatusPaths) {
      try {
        if (Directory(path).existsSync()) return true;
      } catch (_) {}
    }
    return false;
  }
}
