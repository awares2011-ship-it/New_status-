import 'package:flutter/foundation.dart';
import '../models/status_model.dart';
import '../services/whatsapp_service.dart';

enum StatusState { idle, loading, success, empty, error }

/// Provider for WhatsApp status data.
///
/// CRASH FIX:
/// - Concurrent-load guard (_isLoadingGuard) prevents double-scan when
///   pull-to-refresh and lifecycle resume both fire at the same moment.
/// - Per-item error handling in the service means a single bad file
///   cannot poison the whole result list.
/// - updateSavedState() uses copyWith() (added to StatusModel) so the
///   mutable field update never rebuilds the wrong object.
///
/// NEW: newStatusCount — exposes the number of newly discovered statuses
/// since the last clear so HomeScreen can show a badge on the tab.
class StatusProvider extends ChangeNotifier {
  List<StatusModel> _statuses = [];
  StatusState _state = StatusState.idle;
  String? _errorMessage;
  Set<String> _selectedPaths = {};
  bool _isMultiSelectMode = false;

  // Tracks paths seen on the PREVIOUS successful load so we can compute
  // newStatusCount without keeping a separate snapshot.
  Set<String> _previousPaths = {};
  int _newStatusCount = 0;

  // Guard: prevents concurrent loads.
  bool _isLoadingGuard = false;

  // ── Getters ────────────────────────────────────────────────────────────────

  List<StatusModel> get statuses      => _statuses;
  StatusState       get state         => _state;
  String?           get errorMessage  => _errorMessage;
  Set<String>       get selectedPaths => _selectedPaths;
  bool              get isMultiSelectMode => _isMultiSelectMode;
  int               get selectedCount => _selectedPaths.length;
  int               get newStatusCount => _newStatusCount;

  List<StatusModel> get imageStatuses =>
      _statuses.where((s) => s.type == StatusType.image).toList();
  List<StatusModel> get videoStatuses =>
      _statuses.where((s) => s.type == StatusType.video).toList();
  List<StatusModel> get selectedStatuses =>
      _statuses.where((s) => _selectedPaths.contains(s.path)).toList();

  bool isSelected(String path) => _selectedPaths.contains(path);

  // ── Load ───────────────────────────────────────────────────────────────────

  Future<void> loadStatuses() async {
    if (_isLoadingGuard) return;
    _isLoadingGuard = true;

    _state = StatusState.loading;
    _errorMessage = null;
    notifyListeners();

    try {
      final statuses = await WhatsAppService.instance.fetchAllStatuses();

      // Compute badge count: paths not seen in the previous load.
      final newPaths = statuses.map((s) => s.path).toSet();
      _newStatusCount = newPaths.difference(_previousPaths).length;
      _previousPaths = newPaths;

      _statuses = statuses;
      _state = statuses.isEmpty ? StatusState.empty : StatusState.success;
    } catch (e, stack) {
      debugPrint('StatusProvider.loadStatuses error: $e\n$stack');
      _state = StatusState.error;
      _errorMessage = _friendlyError(e);
      _statuses = [];
    }

    _isLoadingGuard = false;
    notifyListeners();
  }

  /// Force-refresh: invalidates the service cache then re-scans.
  Future<void> refresh() async {
    if (_isLoadingGuard) return;
    WhatsAppService.instance.invalidateCache();
    await loadStatuses();
  }

  /// Called when the user opens the WhatsApp tab — resets the new-status badge.
  void clearNewStatusCount() {
    if (_newStatusCount == 0) return;
    _newStatusCount = 0;
    notifyListeners();
  }

  // ── Selection ──────────────────────────────────────────────────────────────

  void toggleSelection(String path) {
    if (_selectedPaths.contains(path)) {
      _selectedPaths.remove(path);
    } else {
      _selectedPaths.add(path);
    }
    _isMultiSelectMode = _selectedPaths.isNotEmpty;
    notifyListeners();
  }

  void selectAll(List<StatusModel> list) {
    _selectedPaths = list.map((s) => s.path).toSet();
    _isMultiSelectMode = _selectedPaths.isNotEmpty;
    notifyListeners();
  }

  void clearSelection() {
    _selectedPaths.clear();
    _isMultiSelectMode = false;
    notifyListeners();
  }

  // ── Saved-state sync ───────────────────────────────────────────────────────

  /// Called by the UI after SavedProvider saves a status, so the grid card's
  /// download icon updates to a checkmark without a full re-scan.
  void updateSavedState(String path, bool isSaved) {
    final idx = _statuses.indexWhere((s) => s.path == path);
    if (idx != -1) {
      _statuses[idx] = _statuses[idx].copyWith(isSaved: isSaved);
      notifyListeners();
    }
  }

  // ── Helpers ────────────────────────────────────────────────────────────────

  String _friendlyError(Object e) {
    final msg = e.toString().toLowerCase();
    if (msg.contains('permission')) {
      return 'Storage permission required to view statuses.';
    }
    if (msg.contains('not found') || msg.contains('no such')) {
      return 'WhatsApp status folder not found. Open WhatsApp and view a status first.';
    }
    return 'Could not load statuses. Please try again.';
  }
}
