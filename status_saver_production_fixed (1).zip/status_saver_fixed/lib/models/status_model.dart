enum StatusType { image, video }

class StatusModel {
  final String path;
  final StatusType type;
  final DateTime date;
  final bool isFromBusiness;
  final bool isSaved;

  const StatusModel({
    required this.path,
    required this.type,
    required this.date,
    this.isFromBusiness = false,
    this.isSaved = false,
  });

  String get fileName => path.split('/').last;

  /// CRASH FIX: Added null-safe copyWith so callers never need to
  /// reconstruct the full object when updating a single field.
  StatusModel copyWith({
    String? path,
    StatusType? type,
    DateTime? date,
    bool? isFromBusiness,
    bool? isSaved,
  }) {
    return StatusModel(
      path: path ?? this.path,
      type: type ?? this.type,
      date: date ?? this.date,
      isFromBusiness: isFromBusiness ?? this.isFromBusiness,
      isSaved: isSaved ?? this.isSaved,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is StatusModel && other.path == path);

  @override
  int get hashCode => path.hashCode;

  @override
  String toString() =>
      'StatusModel(path: $path, type: $type, isSaved: $isSaved)';
}
