import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../utils/ad_manager.dart';

/// A native ad card interleaved in the status grid.
///
/// CRASH FIX: The ad is created and loaded in initState, but the widget
/// only renders it once `_isLoaded` is true.  If load fails, the widget
/// renders a transparent SizedBox so the grid layout stays intact.
/// The NativeAd is always disposed in dispose() to prevent memory leaks.
class NativeAdCard extends StatefulWidget {
  const NativeAdCard({super.key});

  @override
  State<NativeAdCard> createState() => _NativeAdCardState();
}

class _NativeAdCardState extends State<NativeAdCard> {
  NativeAd? _nativeAd;
  bool _isLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadAd();
  }

  void _loadAd() {
    try {
      _nativeAd = AdManager.instance.createNativeAd(
        listener: NativeAdListener(
          onAdLoaded: (_) {
            if (mounted) setState(() => _isLoaded = true);
          },
          onAdFailedToLoad: (ad, error) {
            ad.dispose();
            _nativeAd = null;
            if (mounted) setState(() => _isLoaded = false);
          },
        ),
      );
      _nativeAd?.load();
    } catch (e) {
      // Non-fatal — grid slot is just empty.
      debugPrint('NativeAdCard load error: $e');
    }
  }

  @override
  void dispose() {
    // CRASH FIX: Always dispose NativeAd to free SDK resources.
    _nativeAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_isLoaded || _nativeAd == null) {
      // Transparent placeholder keeps the grid geometry intact.
      return const SizedBox.shrink();
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.dark
              ? const Color(0xFF1A2733)
              : const Color(0xFFF0F4F8),
          borderRadius: BorderRadius.circular(8),
        ),
        child: AdWidget(ad: _nativeAd!),
      ),
    );
  }
}
