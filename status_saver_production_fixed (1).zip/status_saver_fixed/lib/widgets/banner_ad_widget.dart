import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../utils/ad_manager.dart';

/// Displays an AdMob banner ad at the bottom of a screen.
///
/// [adKey] should be 'home' or 'saved' to select the correct pre-loaded
/// banner instance from AdManager.
///
/// CRASH FIX: If the banner is null or not yet loaded, the widget
/// renders SizedBox.shrink() — zero height, no crash.  The banner loads
/// lazily after initState so the screen never blocks on an ad request.
class BannerAdWidget extends StatefulWidget {
  final String adKey;
  const BannerAdWidget({super.key, required this.adKey});

  @override
  State<BannerAdWidget> createState() => _BannerAdWidgetState();
}

class _BannerAdWidgetState extends State<BannerAdWidget> {
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadAd());
  }

  void _loadAd() {
    if (!mounted) return;
    final onLoaded = () {
      if (mounted) setState(() => _loaded = true);
    };

    if (widget.adKey == 'saved') {
      AdManager.instance.loadSavedBanner(onLoaded: onLoaded);
    } else {
      AdManager.instance.loadHomeBanner(onLoaded: onLoaded);
    }
  }

  @override
  Widget build(BuildContext context) {
    final BannerAd? ad = widget.adKey == 'saved'
        ? AdManager.instance.savedBannerAd
        : AdManager.instance.homeBannerAd;

    if (!_loaded || ad == null) return const SizedBox.shrink();

    return SafeArea(
      top: false,
      child: SizedBox(
        height: ad.size.height.toDouble(),
        child: AdWidget(ad: ad),
      ),
    );
  }
}
