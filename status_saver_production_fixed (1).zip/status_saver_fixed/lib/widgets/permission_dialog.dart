import 'package:flutter/material.dart';
import '../utils/permission_utils.dart';

class PermissionDialog extends StatelessWidget {
  final VoidCallback onGranted;
  final VoidCallback onDenied;

  const PermissionDialog({
    super.key,
    required this.onGranted,
    required this.onDenied,
  });

  Future<void> _requestPermission(BuildContext context) async {
    // Fix: Check permanently-denied BEFORE requesting so we can skip straight to settings
    final isPermanentlyDenied = await PermissionUtils.isPermanentlyDenied();
    // Fix: always check context.mounted after every await
    if (!context.mounted) return;

    if (isPermanentlyDenied) {
      await PermissionUtils.openSettings();
      if (!context.mounted) return;
      final hasPermission = await PermissionUtils.hasStoragePermission();
      if (!context.mounted) return;
      if (hasPermission) {
        onGranted();
      } else {
        onDenied();
      }
      return;
    }

    final granted = await PermissionUtils.requestStoragePermission();
    if (!context.mounted) return;

    if (granted) {
      onGranted();
      return;
    }

    // Permission was denied — check if permanently denied now
    final permanentlyDenied = await PermissionUtils.isPermanentlyDenied();
    if (!context.mounted) return;

    if (permanentlyDenied) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text('Permission Required'),
          content: const Text(
            'Storage permission was permanently denied. Please enable it in App Settings to use Status Saver.',
          ),
          actions: [
            TextButton(
              onPressed: onDenied,
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                Navigator.of(context, rootNavigator: true).pop();
                await PermissionUtils.openSettings();
                // Fix: cannot use outer context after pop + await; check mounted
                final ok = await PermissionUtils.hasStoragePermission();
                if (ok) {
                  onGranted();
                } else {
                  onDenied();
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF25D366),
                foregroundColor: Colors.white,
              ),
              child: const Text('Open Settings'),
            ),
          ],
        ),
      );
    } else {
      onDenied();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: const Color(0xFF25D366).withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.folder_open_rounded,
                size: 44,
                color: Color(0xFF25D366),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Storage Permission Needed',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(
              'Status Saver needs access to your storage to read and save WhatsApp statuses.',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            _PermissionStep(
              icon: Icons.looks_one_rounded,
              text: 'Open WhatsApp and view statuses',
            ),
            _PermissionStep(
              icon: Icons.looks_two_rounded,
              text: 'Grant storage permission when prompted',
            ),
            _PermissionStep(
              icon: Icons.looks_3_rounded,
              text: 'View and save statuses from this app',
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => _requestPermission(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF25D366),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
                child: const Text(
                  'Grant Permission',
                  style:
                      TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: onDenied,
              child: Text(
                'Not Now',
                style: TextStyle(color: Colors.grey[500], fontSize: 14),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PermissionStep extends StatelessWidget {
  final IconData icon;
  final String text;
  const _PermissionStep({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF25D366), size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(fontSize: 13, color: Colors.grey[600]),
            ),
          ),
        ],
      ),
    );
  }
}
