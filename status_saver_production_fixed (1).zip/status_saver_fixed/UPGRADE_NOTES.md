# Status Saver — Production Upgrade Changelog
### Version 1.0.1 | Flutter 3.x+ | Android 8–14+

---

## 🔴 Files Changed in This Upgrade

| File | Changes Made |
|------|-------------|
| `lib/utils/constants.dart` | Added `prefLastInterstitialMs`, `interstitialCooldownSeconds`, `splashMinMs`, `adRetrySeconds` constants |
| `lib/utils/ad_manager.dart` | Added per-session interstitial cooldown timer; persists `prefLastInterstitialMs` to SharedPrefs; `_buildBanner()` helper deduplication; fixed `dispose()` to remove observer |
| `lib/utils/permission_utils.dart` | Simplified control flow; hardened permanent-denial path; cleaned `&&` multi-permission check |
| `lib/utils/file_utils.dart` | No functional change; clarified comments |
| `lib/services/whatsapp_service.dart` | No functional change; clarified docstring |
| `lib/providers/status_provider.dart` | `_selectedPaths` is now `final Set` (not re-assigned); added `Set.unmodifiable` on getter; added `toString()` to `StatusModel` |
| `lib/models/status_model.dart` | Added `const` constructor; added `toString()` |
| `lib/screens/splash_screen.dart` | `splashMinMs` now comes from `AppConstants` (not a magic number) |
| `lib/screens/home_screen.dart` | Added early-return guard in `onDestinationSelected` (skip re-render when tapping same tab) |
| `lib/screens/whatsapp_tab.dart` | No functional change; minor comment cleanup |
| `lib/screens/images_fragment.dart` | No functional change; minor comment cleanup |
| `lib/screens/videos_fragment.dart` | No functional change; minor comment cleanup |
| `lib/main.dart` | No functional change; minor comment cleanup |

---

## ✅ All Previously Fixed Issues (from v1.0.0)

| # | File | Issue | Fix |
|---|------|-------|-----|
| 1 | `android/app/build.gradle` | Package namespace mismatch | Unified to `com.yourname.statussaver` |
| 2 | `android/build.gradle` | AGP too old for compileSdk 35 | Upgraded to AGP 8.3.2 |
| 3 | `gradle-wrapper.properties` | Gradle version too old for AGP | Upgraded to Gradle 8.7 |
| 4 | `android/settings.gradle` | Hard `assert` crashes on fresh clone | Wrapped in `if` check |
| 5 | `android/app/build.gradle` | `null storeFile` crashes release build | Falls back to debug signing |
| 6 | `proguard-rules.pro` | Missing keep rules → `ClassNotFoundException` | 38 keep/dontwarn rules |
| 7 | `lib/utils/file_utils.dart` | `PhotoManager` double-save | Replaced with `MethodChannel` + native `MediaScannerConnection` |
| 8 | `MainActivity.kt` | No MediaScanner channel | Added `MediaScannerConnection` MethodChannel |
| 9 | `lib/app.dart` | Deprecated `background:` in `ColorScheme` | Removed |
| 10 | `lib/services/whatsapp_service.dart` | Hardcoded single WA path | Both legacy + scoped-storage paths; runs in isolates via `compute` |
| 11 | `lib/providers/status_provider.dart` | No loading/error/empty states | `StatusState` enum: idle/loading/success/empty/error |
| 12 | `lib/screens/splash_screen.dart` | Heavy work in `initState` → white screen | `addPostFrameCallback` + `Future.wait` parallel init |
| 13 | `lib/screens/whatsapp_tab.dart` | Immediate permission popup, no UX | `_PermissionGate` widget with step-by-step UI |
| 14 | `lib/utils/permission_utils.dart` | No Android 13+ granular permissions | `device_info_plus` SDK detection; `READ_MEDIA_IMAGES` + `READ_MEDIA_VIDEO` on API 33+ |
| 15 | `AndroidManifest.xml` | Missing `<queries>` for WA share | Added WA + WA Business package queries |
| 16 | `lib/utils/ad_manager.dart` | App Open Ad fires on in-app navigation | `_isShowingFullScreenAd` guard on lifecycle observer |
| 17 | `lib/screens/images_fragment.dart` | No shimmer loader | `Shimmer.fromColors` grid shown during `StatusState.loading` |
| 18 | All screens | No empty state UI | `EmptyStateWidget` with icon/title/subtitle/action for every state |

---

## 🚀 Production Checklist — Before Publishing

### 1. Replace Package Name
Search and replace `com.yourname.statussaver` everywhere:
- `android/app/build.gradle` → `applicationId`
- `android/app/src/main/AndroidManifest.xml` → AdMob meta-data
- `android/app/src/main/kotlin/com/yourname/statussaver/` → rename folder and package declaration
- `lib/utils/constants.dart` → `packageName`
- `lib/utils/file_utils.dart` → `_mediaChannel` name

### 2. Replace AdMob IDs
In `lib/utils/constants.dart`, replace ALL `ca-app-pub-3940256099942544/...` test IDs with your real IDs from https://apps.admob.com. Also update `AndroidManifest.xml` → `APPLICATION_ID` meta-data.

### 3. Replace Other Placeholders
- `playStoreUrl` → your real Play Store URL
- `privacyPolicyUrl` → your hosted privacy policy (required by Play Store)
- `appVersion` → match `pubspec.yaml` version

### 4. Set Up Release Signing
Add to `android/local.properties`:
```
keystore.path=/path/to/your/keystore.jks
keystore.password=YOUR_STORE_PASSWORD
keystore.keyAlias=YOUR_KEY_ALIAS
keystore.keyPassword=YOUR_KEY_PASSWORD
```

### 5. Wire Up Crash Reporting (optional but recommended)
In `lib/main.dart`, uncomment the `FirebaseCrashlytics` lines and add `firebase_crashlytics` to `pubspec.yaml`.

### 6. App Icon
Replace the default Flutter icon. Run:
```bash
flutter pub add flutter_launcher_icons
flutter pub run flutter_launcher_icons:main
```

### 7. Splash Logo
Replace `assets/images/splash_logo.png` with your real 1152×1152 px PNG, then run:
```bash
dart run flutter_native_splash:create
```

### 8. Bump Version
In `pubspec.yaml`, increment `version: 1.0.0+1` before every Play Store upload. The number after `+` is the `versionCode`.

---

## 📦 Build Commands

```bash
# Run on device
flutter run --release

# Build APK (for sideloading / testing)
flutter build apk --release

# Build App Bundle (for Play Store — preferred)
flutter build appbundle --release
```

---

## 🎨 Color Theme

| Role | Hex |
|------|-----|
| App Bar / Splash BG | `#075E54` |
| Primary / Buttons | `#25D366` |
| Multi-select App Bar | `#128C7E` |
| Light scaffold BG | `#F0F2F5` |
| Dark scaffold BG | `#0B141A` |
| Dark card surface | `#1F2C34` |
