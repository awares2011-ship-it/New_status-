import 'dart:io';

import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/app_export.dart';
import '../../routes/app_routes.dart';
import '../../services/downloads_service.dart';

enum DateFilter { all, today, thisWeek, thisMonth }

class DownloadsScreen extends StatefulWidget {
  const DownloadsScreen({super.key});

  @override
  State<DownloadsScreen> createState() => _DownloadsScreenState();
}

class _DownloadsScreenState extends State<DownloadsScreen> {
  List<StatusModel> _allSaved = [];
  List<StatusModel> _filtered = [];
  DateFilter _activeFilter = DateFilter.all;
  bool _isLoading = true;
  bool _isSelectionMode = false;
  final Set<String> _selectedIds = {};

  @override
  void initState() {
    super.initState();
    _loadSaved();
  }

  Future<void> _loadSaved() async {
    setState(() => _isLoading = true);
    final items = await DownloadsService.getSavedStatuses();
    if (mounted) {
      setState(() {
        _allSaved = items;
        _applyFilter(_activeFilter);
        _isLoading = false;
      });
    }
  }

  void _applyFilter(DateFilter filter) {
    final now = DateTime.now();
    setState(() {
      _activeFilter = filter;
      switch (filter) {
        case DateFilter.all:
          _filtered = List.from(_allSaved);
          break;
        case DateFilter.today:
          _filtered = _allSaved.where((s) {
            final d = s.dateModified;
            return d.year == now.year &&
                d.month == now.month &&
                d.day == now.day;
          }).toList();
          break;
        case DateFilter.thisWeek:
          final weekAgo = now.subtract(const Duration(days: 7));
          _filtered = _allSaved
              .where((s) => s.dateModified.isAfter(weekAgo))
              .toList();
          break;
        case DateFilter.thisMonth:
          _filtered = _allSaved.where((s) {
            return s.dateModified.year == now.year &&
                s.dateModified.month == now.month;
          }).toList();
          break;
      }
    });
  }

  Future<void> _deleteStatus(StatusModel status) async {
    final confirmed = await _showDeleteDialog(count: 1);
    if (!confirmed) return;

    final ok = await DownloadsService.deleteStatus(status);
    if (ok && mounted) {
      setState(() {
        _allSaved.removeWhere((s) => s.id == status.id);
        _applyFilter(_activeFilter);
      });
      _showSnackBar('Deleted successfully', isError: false);
    } else if (mounted) {
      _showSnackBar('Could not delete file', isError: true);
    }
  }

  Future<void> _deleteSelected() async {
    if (_selectedIds.isEmpty) return;
    final confirmed = await _showDeleteDialog(count: _selectedIds.length);
    if (!confirmed) return;

    int deleted = 0;
    for (final id in _selectedIds.toList()) {
      final idx = _allSaved.indexWhere((s) => s.id == id);
      if (idx == -1) continue;
      final ok = await DownloadsService.deleteStatus(_allSaved[idx]);
      if (ok) deleted++;
    }

    setState(() {
      _allSaved.removeWhere((s) => _selectedIds.contains(s.id));
      _selectedIds.clear();
      _isSelectionMode = false;
      _applyFilter(_activeFilter);
    });

    if (mounted) _showSnackBar('Deleted $deleted item(s)', isError: false);
  }

  Future<bool> _showDeleteDialog({required int count}) async {
    return await showDialog<bool>(
          context: context,
          builder: (ctx) {
            final isDark = Theme.of(ctx).brightness == Brightness.dark;
            return AlertDialog(
              backgroundColor: isDark ? AppTheme.surfaceVariant : Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              title: Text(
                count == 1 ? 'Delete File?' : 'Delete $count Files?',
                style: TextStyle(
                  color: isDark
                      ? AppTheme.onBackground
                      : const Color(0xFF1A1A1A),
                  fontWeight: FontWeight.w700,
                ),
              ),
              content: Text(
                count == 1
                    ? 'This file will be permanently deleted from your device.'
                    : 'These $count files will be permanently deleted.',
                style: TextStyle(
                  color: isDark ? AppTheme.mutedLight : const Color(0xFF6B6B6B),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: Text(
                    'Cancel',
                    style: TextStyle(
                      color: isDark ? AppTheme.mutedLight : Colors.grey,
                    ),
                  ),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  style: FilledButton.styleFrom(
                    backgroundColor: AppTheme.error,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Delete'),
                ),
              ],
            );
          },
        ) ??
        false;
  }

  Future<void> _shareStatus(StatusModel status) async {
    try {
      final file = File(status.filePath);
      if (!await file.exists()) {
        if (mounted) {
          _showSnackBar('File no longer exists on device', isError: true);
        }
        return;
      }
      await Share.shareXFiles([
        XFile(status.filePath),
      ], text: 'Shared via Status Saver');
    } catch (e) {
      if (mounted) _showSnackBar('Could not share file', isError: true);
    }
  }

  void _toggleSelection(String id) {
    setState(() {
      if (_selectedIds.contains(id)) {
        _selectedIds.remove(id);
        if (_selectedIds.isEmpty) _isSelectionMode = false;
      } else {
        _selectedIds.add(id);
      }
    });
  }

  void _enterSelectionMode(String id) {
    HapticFeedback.mediumImpact();
    setState(() {
      _isSelectionMode = true;
      _selectedIds.add(id);
    });
  }

  void _exitSelectionMode() {
    setState(() {
      _isSelectionMode = false;
      _selectedIds.clear();
    });
  }

  void _showSnackBar(String msg, {required bool isError}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: isError ? AppTheme.error : AppTheme.surface,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? AppTheme.background : const Color(0xFFF0F2F5);

    return Scaffold(
      backgroundColor: bgColor,
      body: Column(
        children: [
          _buildAppBar(isDark),
          _buildFilterBar(isDark),
          Expanded(
            child: _isLoading
                ? const Center(
                    child: CircularProgressIndicator(color: AppTheme.primary),
                  )
                : _filtered.isEmpty
                ? _buildEmptyState(isDark)
                : _buildGrid(isDark),
          ),
        ],
      ),
    );
  }

  Widget _buildAppBar(bool isDark) {
    final topPadding = MediaQuery.of(context).padding.top;
    final textColor = isDark ? AppTheme.onBackground : const Color(0xFF1A1A1A);
    final mutedColor = isDark ? AppTheme.mutedLight : const Color(0xFF6B6B6B);

    return Container(
      padding: EdgeInsets.fromLTRB(8, topPadding + 8, 8, 8),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF0D1F14) : Colors.white,
        border: Border(
          bottom: BorderSide(
            color: isDark ? const Color(0xFF1E2E22) : const Color(0xFFE0E0E0),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: _isSelectionMode
                ? _exitSelectionMode
                : () => Navigator.pop(context),
            icon: Icon(
              _isSelectionMode
                  ? Icons.close_rounded
                  : Icons.arrow_back_ios_new_rounded,
              color: textColor,
              size: 20,
            ),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _isSelectionMode
                      ? '${_selectedIds.length} selected'
                      : 'Downloads',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: textColor,
                    letterSpacing: -0.3,
                  ),
                ),
                if (!_isSelectionMode)
                  Text(
                    '${_filtered.length} saved ${_filtered.length == 1 ? 'file' : 'files'}',
                    style: TextStyle(fontSize: 12, color: mutedColor),
                  ),
              ],
            ),
          ),
          if (_isSelectionMode)
            IconButton(
              onPressed: _deleteSelected,
              icon: const Icon(
                Icons.delete_outline_rounded,
                color: AppTheme.error,
                size: 22,
              ),
              tooltip: 'Delete selected',
            )
          else
            IconButton(
              onPressed: _loadSaved,
              icon: Icon(Icons.refresh_rounded, color: mutedColor, size: 22),
              tooltip: 'Refresh',
            ),
        ],
      ),
    );
  }

  Widget _buildFilterBar(bool isDark) {
    final filters = [
      (DateFilter.all, 'All'),
      (DateFilter.today, 'Today'),
      (DateFilter.thisWeek, 'This Week'),
      (DateFilter.thisMonth, 'This Month'),
    ];

    return Container(
      height: 48,
      color: isDark ? AppTheme.background : const Color(0xFFF0F2F5),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        itemCount: filters.length,
        itemBuilder: (_, i) {
          final filter = filters[i].$1;
          final label = filters[i].$2;
          final isActive = _activeFilter == filter;
          return GestureDetector(
            onTap: () => _applyFilter(filter),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              decoration: BoxDecoration(
                color: isActive
                    ? AppTheme.primary
                    : (isDark ? AppTheme.surfaceVariant : Colors.white),
                borderRadius: BorderRadius.circular(100),
                border: Border.all(
                  color: isActive
                      ? AppTheme.primary
                      : (isDark ? AppTheme.outline : const Color(0xFFD0D0D0)),
                  width: 1,
                ),
              ),
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: isActive
                      ? Colors.black
                      : (isDark ? AppTheme.onSurface : const Color(0xFF555555)),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildEmptyState(bool isDark) {
    final textColor = isDark ? AppTheme.onBackground : const Color(0xFF1A1A1A);
    final mutedColor = isDark ? AppTheme.mutedLight : const Color(0xFF6B6B6B);

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: isDark
                    ? AppTheme.surfaceVariant
                    : const Color(0xFFEEEEEE),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Icon(
                Icons.download_done_rounded,
                size: 40,
                color: isDark ? AppTheme.muted : const Color(0xFFAAAAAA),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'No Downloads Yet',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: textColor,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _activeFilter == DateFilter.all
                  ? 'Save statuses from the home screen\nand they\'ll appear here.'
                  : 'No files saved in this time period.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: mutedColor, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGrid(bool isDark) {
    return RefreshIndicator(
      onRefresh: _loadSaved,
      color: AppTheme.primary,
      child: GridView.builder(
        padding: const EdgeInsets.all(12),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 0.85,
        ),
        itemCount: _filtered.length,
        itemBuilder: (_, i) {
          final status = _filtered[i];
          return _DownloadCard(
            status: status,
            isDark: isDark,
            isSelected: _selectedIds.contains(status.id),
            isSelectionMode: _isSelectionMode,
            onTap: () {
              if (_isSelectionMode) {
                _toggleSelection(status.id);
              } else {
                Navigator.pushNamed(
                  context,
                  AppRoutes.previewScreen,
                  arguments: {'status': status, 'onSaved': (StatusModel _) {}},
                );
              }
            },
            onLongPress: () => _enterSelectionMode(status.id),
            onDelete: () => _deleteStatus(status),
            onShare: () => _shareStatus(status),
          );
        },
      ),
    );
  }
}

class _DownloadCard extends StatelessWidget {
  final StatusModel status;
  final bool isDark;
  final bool isSelected;
  final bool isSelectionMode;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final VoidCallback onDelete;
  final VoidCallback onShare;

  const _DownloadCard({
    required this.status,
    required this.isDark,
    required this.isSelected,
    required this.isSelectionMode,
    required this.onTap,
    required this.onLongPress,
    required this.onDelete,
    required this.onShare,
  });

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inDays == 0) return 'Today';
    if (diff.inDays == 1) return 'Yesterday';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    return '${dt.day}/${dt.month}/${dt.year}';
  }

  @override
  Widget build(BuildContext context) {
    final cardColor = isDark ? AppTheme.surface : Colors.white;
    final mutedColor = isDark ? AppTheme.mutedLight : const Color(0xFF888888);

    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? AppTheme.primary : Colors.transparent,
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withAlpha(isDark ? 40 : 15),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(12),
                    ),
                    child: status.isImage
                        ? Image.file(
                            File(status.filePath),
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              color: isDark
                                  ? AppTheme.surfaceVariant
                                  : const Color(0xFFEEEEEE),
                              child: Icon(
                                Icons.broken_image_outlined,
                                color: mutedColor,
                                size: 32,
                              ),
                            ),
                          )
                        : Container(
                            color: isDark
                                ? AppTheme.surfaceVariant
                                : const Color(0xFFEEEEEE),
                            child: const Center(
                              child: Icon(
                                Icons.play_circle_fill_rounded,
                                color: AppTheme.primary,
                                size: 40,
                              ),
                            ),
                          ),
                  ),
                  if (isSelected)
                    Container(
                      decoration: BoxDecoration(
                        color: AppTheme.primary.withAlpha(80),
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(12),
                        ),
                      ),
                      child: const Center(
                        child: Icon(
                          Icons.check_circle_rounded,
                          color: Colors.white,
                          size: 32,
                        ),
                      ),
                    ),
                  if (!isSelectionMode)
                    Positioned(
                      top: 6,
                      right: 6,
                      child: Row(
                        children: [
                          _ActionBtn(
                            icon: Icons.share_rounded,
                            onTap: onShare,
                            isDark: isDark,
                          ),
                          const SizedBox(width: 4),
                          _ActionBtn(
                            icon: Icons.delete_outline_rounded,
                            onTap: onDelete,
                            isDark: isDark,
                            isDestructive: true,
                          ),
                        ],
                      ),
                    ),
                  Positioned(
                    bottom: 6,
                    left: 6,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: status.isVideo
                            ? AppTheme.videoBadge
                            : AppTheme.imageBadge,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        status.isVideo ? 'VIDEO' : 'IMAGE',
                        style: const TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Text(
                _formatDate(status.dateModified),
                style: TextStyle(
                  fontSize: 11,
                  color: mutedColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool isDark;
  final bool isDestructive;

  const _ActionBtn({
    required this.icon,
    required this.onTap,
    required this.isDark,
    this.isDestructive = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          color: Colors.black.withAlpha(140),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(
          icon,
          size: 14,
          color: isDestructive ? AppTheme.error : Colors.white,
        ),
      ),
    );
  }
}
