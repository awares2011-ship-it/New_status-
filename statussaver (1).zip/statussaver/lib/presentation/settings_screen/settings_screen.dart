import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../theme/app_theme.dart';
import '../../services/theme_service.dart';

class SettingsScreen extends StatefulWidget {
  final ThemeService themeService;

  const SettingsScreen({super.key, required this.themeService});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  void initState() {
    super.initState();
    widget.themeService.addListener(_onThemeChanged);
  }

  void _onThemeChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    widget.themeService.removeListener(_onThemeChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = widget.themeService.isDark;
    final bgColor = isDark ? AppTheme.background : const Color(0xFFF0F2F5);
    final textColor = isDark ? AppTheme.onBackground : const Color(0xFF1A1A1A);

    return Scaffold(
      backgroundColor: bgColor,
      body: CustomScrollView(
        slivers: [
          _buildAppBar(context, isDark, textColor),
          SliverToBoxAdapter(
            child: Column(
              children: [
                const SizedBox(height: 8),
                _buildAppearanceSection(isDark, textColor),
                const SizedBox(height: 8),
                _buildStorageSection(isDark, textColor),
                const SizedBox(height: 8),
                _buildAboutSection(isDark, textColor, context),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ],
      ),
    );
  }

  SliverAppBar _buildAppBar(
    BuildContext context,
    bool isDark,
    Color textColor,
  ) {
    return SliverAppBar(
      pinned: true,
      backgroundColor: isDark ? AppTheme.background : Colors.white,
      surfaceTintColor: Colors.transparent,
      leading: IconButton(
        onPressed: () => Navigator.pop(context),
        icon: Icon(
          Icons.arrow_back_ios_new_rounded,
          color: textColor,
          size: 20,
        ),
      ),
      title: Text(
        'Settings',
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w700,
          color: textColor,
        ),
      ),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(
          height: 1,
          color: isDark ? AppTheme.outlineVariant : const Color(0xFFE0E0E0),
        ),
      ),
    );
  }

  Widget _buildAppearanceSection(bool isDark, Color textColor) {
    return _SettingsSection(
      title: 'APPEARANCE',
      isDark: isDark,
      children: [
        _SettingsToggleRow(
          icon: isDark ? Icons.dark_mode_rounded : Icons.light_mode_rounded,
          iconColor: isDark ? const Color(0xFF6366F1) : const Color(0xFFF59E0B),
          label: 'Dark Mode',
          subtitle: isDark
              ? 'Currently using dark theme'
              : 'Currently using light theme',
          value: isDark,
          isDark: isDark,
          onChanged: (val) {
            HapticFeedback.lightImpact();
            widget.themeService.toggleTheme();
          },
        ),
      ],
    );
  }

  Widget _buildStorageSection(bool isDark, Color textColor) {
    return _SettingsSection(
      title: 'STORAGE',
      isDark: isDark,
      children: [
        _SettingsInfoRow(
          icon: Icons.folder_outlined,
          iconColor: AppTheme.primary,
          label: 'Save Location',
          value: 'Pictures/StatusSaver',
          isDark: isDark,
          isLast: true,
        ),
      ],
    );
  }

  Widget _buildAboutSection(
    bool isDark,
    Color textColor,
    BuildContext context,
  ) {
    return _SettingsSection(
      title: 'ABOUT',
      isDark: isDark,
      children: [
        _SettingsInfoRow(
          icon: Icons.info_outline_rounded,
          iconColor: AppTheme.secondary,
          label: 'App Version',
          value: '1.0.0',
          isDark: isDark,
        ),
        _SettingsInfoRow(
          icon: Icons.android_rounded,
          iconColor: const Color(0xFF3DDC84),
          label: 'Platform',
          value: 'Android',
          isDark: isDark,
        ),
        _SettingsActionRow(
          icon: Icons.privacy_tip_outlined,
          iconColor: AppTheme.secondary,
          label: 'Privacy Policy',
          isDark: isDark,
          onTap: () => _showWebContent(
            context,
            'Privacy Policy',
            _privacyPolicyText,
            isDark,
          ),
        ),
        _SettingsActionRow(
          icon: Icons.gavel_rounded,
          iconColor: AppTheme.warning,
          label: 'Terms of Service',
          isDark: isDark,
          onTap: () =>
              _showWebContent(context, 'Terms of Service', _termsText, isDark),
        ),
        _SettingsActionRow(
          icon: Icons.star_outline_rounded,
          iconColor: AppTheme.warning,
          label: 'Rate on Play Store',
          isDark: isDark,
          onTap: () => _showSnackBar(context, 'Opening Play Store...'),
          isLast: true,
        ),
      ],
    );
  }

  void _showWebContent(
    BuildContext context,
    String title,
    String content,
    bool isDark,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) =>
          _ContentSheet(title: title, content: content, isDark: isDark),
    );
  }

  void _showSnackBar(BuildContext context, String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  static const String _privacyPolicyText = '''Privacy Policy

Last updated: January 2025

Status Saver ("we", "our", or "us") is committed to protecting your privacy.

Information We Collect
This app does NOT collect, store, or transmit any personal data to external servers. All operations are performed locally on your device.

Media Access
The app requires access to your device storage to read and save media files. This access is used solely to display and save status media files stored on your device.

No Data Sharing
We do not share, sell, or transfer any of your data to third parties. Your media files remain on your device at all times.

Advertising
This app may display advertisements via Google AdMob. AdMob may collect certain device information for ad personalization. Please refer to Google's Privacy Policy for more details.

Contact Us
If you have questions about this Privacy Policy, contact us at support@statussaver.app

Disclaimer
This app is independent and not affiliated with any third-party messaging or social media applications.''';

  static const String _termsText = '''Terms of Service

Last updated: January 2025

By using Status Saver, you agree to these Terms of Service.

Acceptable Use
- Use this app only for personal, non-commercial purposes
- Do not use this app to infringe on others' intellectual property rights
- Respect the privacy of others when saving and sharing media

Disclaimer of Warranties
This app is provided "as is" without warranties of any kind. We do not guarantee uninterrupted or error-free operation.

Limitation of Liability
We are not liable for any damages arising from your use of this app.

Third-Party Content
We are not responsible for content accessed through this app. Users are responsible for ensuring they have the right to save and share any media.

Independent App
This app is independent and not affiliated with, endorsed by, or connected to any third-party messaging or social media applications.

Changes to Terms
We may update these terms at any time. Continued use of the app constitutes acceptance of updated terms.

Contact
For questions, contact us at support@statussaver.app''';
}

class _SettingsSection extends StatelessWidget {
  final String title;
  final List<Widget> children;
  final bool isDark;

  const _SettingsSection({
    required this.title,
    required this.children,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: AppTheme.primary,
              letterSpacing: 0.8,
            ),
          ),
        ),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: isDark ? AppTheme.surface : Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: isDark ? AppTheme.outlineVariant : const Color(0xFFE8E8E8),
              width: 1,
            ),
          ),
          child: Column(children: children),
        ),
      ],
    );
  }
}

class _SettingsToggleRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label;
  final String subtitle;
  final bool value;
  final bool isDark;
  final ValueChanged<bool> onChanged;

  const _SettingsToggleRow({
    required this.icon,
    required this.iconColor,
    required this.label,
    required this.subtitle,
    required this.value,
    required this.isDark,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final textColor = isDark ? AppTheme.onBackground : const Color(0xFF1A1A1A);
    final mutedColor = isDark ? AppTheme.mutedLight : const Color(0xFF888888);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: iconColor.withAlpha(30),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: iconColor, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: textColor,
                  ),
                ),
                Text(
                  subtitle,
                  style: TextStyle(fontSize: 12, color: mutedColor),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: AppTheme.primary,
          ),
        ],
      ),
    );
  }
}

class _SettingsInfoRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label;
  final String value;
  final bool isDark;
  final bool isLast;

  const _SettingsInfoRow({
    required this.icon,
    required this.iconColor,
    required this.label,
    required this.value,
    required this.isDark,
    this.isLast = false,
  });

  @override
  Widget build(BuildContext context) {
    final textColor = isDark ? AppTheme.onBackground : const Color(0xFF1A1A1A);
    final mutedColor = isDark ? AppTheme.mutedLight : const Color(0xFF888888);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: iconColor.withAlpha(30),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: iconColor, size: 20),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: textColor,
                  ),
                ),
              ),
              Text(value, style: TextStyle(fontSize: 13, color: mutedColor)),
            ],
          ),
        ),
        if (!isLast)
          Container(
            margin: const EdgeInsets.only(left: 68),
            height: 1,
            color: isDark ? AppTheme.outlineVariant : const Color(0xFFEEEEEE),
          ),
      ],
    );
  }
}

class _SettingsActionRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label;
  final bool isDark;
  final VoidCallback onTap;
  final bool isLast;

  const _SettingsActionRow({
    required this.icon,
    required this.iconColor,
    required this.label,
    required this.isDark,
    required this.onTap,
    this.isLast = false,
  });

  @override
  Widget build(BuildContext context) {
    final textColor = isDark ? AppTheme.onBackground : const Color(0xFF1A1A1A);
    final mutedColor = isDark ? AppTheme.muted : const Color(0xFFBBBBBB);

    return Column(
      children: [
        InkWell(
          onTap: onTap,
          borderRadius: isLast
              ? const BorderRadius.only(
                  bottomLeft: Radius.circular(16),
                  bottomRight: Radius.circular(16),
                )
              : BorderRadius.zero,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
            child: Row(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: iconColor.withAlpha(30),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: iconColor, size: 20),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: textColor,
                    ),
                  ),
                ),
                Icon(Icons.chevron_right_rounded, color: mutedColor, size: 20),
              ],
            ),
          ),
        ),
        if (!isLast)
          Container(
            margin: const EdgeInsets.only(left: 68),
            height: 1,
            color: isDark ? AppTheme.outlineVariant : const Color(0xFFEEEEEE),
          ),
      ],
    );
  }
}

class _ContentSheet extends StatelessWidget {
  final String title;
  final String content;
  final bool isDark;

  const _ContentSheet({
    required this.title,
    required this.content,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.85,
      maxChildSize: 0.95,
      minChildSize: 0.5,
      builder: (_, controller) => Container(
        decoration: BoxDecoration(
          color: isDark ? AppTheme.surface : Colors.white,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          children: [
            const SizedBox(height: 12),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: isDark ? AppTheme.outline : const Color(0xFFDDDDDD),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 16, 12),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      title,
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                        color: isDark
                            ? AppTheme.onBackground
                            : const Color(0xFF1A1A1A),
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: Icon(
                      Icons.close_rounded,
                      color: isDark ? AppTheme.mutedLight : Colors.grey,
                      size: 20,
                    ),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                ],
              ),
            ),
            Container(
              height: 1,
              color: isDark ? AppTheme.outlineVariant : const Color(0xFFEEEEEE),
            ),
            Expanded(
              child: SingleChildScrollView(
                controller: controller,
                padding: const EdgeInsets.all(20),
                child: Text(
                  content,
                  style: TextStyle(
                    fontSize: 13,
                    color: isDark
                        ? AppTheme.onSurface
                        : const Color(0xFF444444),
                    height: 1.7,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
