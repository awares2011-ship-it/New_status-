import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../theme/app_theme.dart';
import '../home_screen.dart';

class FilterTabWidget extends StatelessWidget {
  final FilterTab activeTab;
  final int allCount;
  final int imageCount;
  final int videoCount;
  final ValueChanged<FilterTab> onTabChanged;

  const FilterTabWidget({
    super.key,
    required this.activeTab,
    required this.allCount,
    required this.imageCount,
    required this.videoCount,
    required this.onTabChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          _FilterChip(
            label: 'All',
            count: allCount,
            icon: Icons.grid_view_rounded,
            isActive: activeTab == FilterTab.all,
            onTap: () {
              HapticFeedback.selectionClick();
              onTabChanged(FilterTab.all);
            },
          ),
          const SizedBox(width: 8),
          _FilterChip(
            label: 'Images',
            count: imageCount,
            icon: Icons.image_rounded,
            isActive: activeTab == FilterTab.images,
            activeColor: AppTheme.imageBadge,
            onTap: () {
              HapticFeedback.selectionClick();
              onTabChanged(FilterTab.images);
            },
          ),
          const SizedBox(width: 8),
          _FilterChip(
            label: 'Videos',
            count: videoCount,
            icon: Icons.videocam_rounded,
            isActive: activeTab == FilterTab.videos,
            activeColor: AppTheme.videoBadge,
            onTap: () {
              HapticFeedback.selectionClick();
              onTabChanged(FilterTab.videos);
            },
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatefulWidget {
  final String label;
  final int count;
  final IconData icon;
  final bool isActive;
  final Color? activeColor;
  final VoidCallback onTap;

  const _FilterChip({
    required this.label,
    required this.count,
    required this.icon,
    required this.isActive,
    required this.onTap,
    this.activeColor,
  });

  @override
  State<_FilterChip> createState() => _FilterChipState();
}

class _FilterChipState extends State<_FilterChip>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
    _scaleAnim = Tween<double>(
      begin: 1.0,
      end: 0.94,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.activeColor ?? AppTheme.primary;

    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        widget.onTap();
      },
      onTapCancel: () => _controller.reverse(),
      child: ScaleTransition(
        scale: _scaleAnim,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 0),
          decoration: BoxDecoration(
            color: widget.isActive
                ? color.withAlpha(38)
                : AppTheme.surfaceVariant,
            borderRadius: BorderRadius.circular(100),
            border: Border.all(
              color: widget.isActive ? color : AppTheme.outline,
              width: widget.isActive ? 1.5 : 1,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                widget.icon,
                size: 14,
                color: widget.isActive ? color : AppTheme.mutedLight,
              ),
              const SizedBox(width: 6),
              Text(
                widget.label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: widget.isActive
                      ? FontWeight.w700
                      : FontWeight.w500,
                  color: widget.isActive ? color : AppTheme.mutedLight,
                ),
              ),
              if (widget.count > 0) ...[
                const SizedBox(width: 6),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 1,
                  ),
                  decoration: BoxDecoration(
                    color: widget.isActive
                        ? color.withAlpha(51)
                        : AppTheme.outline,
                    borderRadius: BorderRadius.circular(100),
                  ),
                  child: Text(
                    '${widget.count}',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: widget.isActive ? color : AppTheme.muted,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
