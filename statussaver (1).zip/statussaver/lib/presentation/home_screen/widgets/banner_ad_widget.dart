import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../../../theme/app_theme.dart';

class BannerAdWidget extends StatelessWidget {
  final BannerAd? bannerAd;

  const BannerAdWidget({super.key, required this.bannerAd});

  @override
  Widget build(BuildContext context) {
    if (kIsWeb || bannerAd == null) return const SizedBox.shrink();

    return Container(
      width: double.infinity,
      height: 52,
      decoration: const BoxDecoration(
        color: AppTheme.surfaceVariant,
        border: Border(
          top: BorderSide(color: AppTheme.outlineVariant, width: 1),
        ),
      ),
      child: AdWidget(ad: bannerAd!),
    );
  }
}
