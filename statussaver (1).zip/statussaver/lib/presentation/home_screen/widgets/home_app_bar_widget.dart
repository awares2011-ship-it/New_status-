import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';
import '../../../routes/app_routes.dart';

class HomeAppBarWidget extends StatelessWidget {
  final int totalCount;
  final VoidCallback onRefresh;
  final bool isLoading;

  const HomeAppBarWidget({
    super.key,
    required this.totalCount,
    required this.onRefresh,
    required this.isLoading,
  });

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: EdgeInsets.fromLTRB(20, topPadding + 12, 8, 12),
      decoration: BoxDecoration(
        gradient: isDark
            ? const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF0D1F14), Color(0xFF0D0D0D)],
              )
            : const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFFE8F5EE), Color(0xFFF5F5F5)],
              ),
        border: Border(
          bottom: BorderSide(
            color: isDark ? const Color(0xFF1E2E22) : const Color(0xFFD0E8D8),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          // App icon
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF25D366), Color(0xFF128C7E)],
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.primary.withAlpha(77),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(
              Icons.download_for_offline_rounded,
              color: Colors.white,
              size: 22,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Status Saver',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: isDark
                        ? AppTheme.onBackground
                        : const Color(0xFF1A1A1A),
                    letterSpacing: -0.3,
                  ),
                ),
                if (totalCount > 0)
                  Text(
                    '$totalCount ${totalCount == 1 ? 'status' : 'statuses'} found',
                    style: TextStyle(
                      fontSize: 12,
                      color: isDark
                          ? AppTheme.mutedLight
                          : const Color(0xFF6B6B6B),
                      fontWeight: FontWeight.w400,
                    ),
                  ),
              ],
            ),
          ),
          // Refresh button
          _RefreshButton(
            isLoading: isLoading,
            onPressed: onRefresh,
            isDark: isDark,
          ),
          // Downloads button
          IconButton(
            onPressed: () =>
                Navigator.pushNamed(context, AppRoutes.downloadsScreen),
            icon: Icon(
              Icons.download_done_rounded,
              color: isDark ? AppTheme.mutedLight : const Color(0xFF6B6B6B),
              size: 22,
            ),
            tooltip: 'Downloads',
          ),
          // Settings button
          IconButton(
            onPressed: () =>
                Navigator.pushNamed(context, AppRoutes.settingsScreen),
            icon: Icon(
              Icons.settings_outlined,
              color: isDark ? AppTheme.mutedLight : const Color(0xFF6B6B6B),
              size: 22,
            ),
            tooltip: 'Settings',
          ),
          // Info / About button
          IconButton(
            onPressed: () =>
                Navigator.pushNamed(context, AppRoutes.aboutScreen),
            icon: Icon(
              Icons.info_outline_rounded,
              color: isDark ? AppTheme.mutedLight : const Color(0xFF6B6B6B),
              size: 22,
            ),
            tooltip: 'About',
          ),
        ],
      ),
    );
  }
}

class _RefreshButton extends StatefulWidget {
  final bool isLoading;
  final VoidCallback onPressed;
  final bool isDark;

  const _RefreshButton({
    required this.isLoading,
    required this.onPressed,
    required this.isDark,
  });

  @override
  State<_RefreshButton> createState() => _RefreshButtonState();
}

class _RefreshButtonState extends State<_RefreshButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _spinController;

  @override
  void initState() {
    super.initState();
    _spinController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
  }

  @override
  void didUpdateWidget(_RefreshButton old) {
    super.didUpdateWidget(old);
    if (widget.isLoading && !_spinController.isAnimating) {
      _spinController.repeat();
    } else if (!widget.isLoading && _spinController.isAnimating) {
      _spinController.stop();
      _spinController.reset();
    }
  }

  @override
  void dispose() {
    _spinController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: widget.isLoading ? null : widget.onPressed,
      icon: RotationTransition(
        turns: _spinController,
        child: Icon(
          Icons.refresh_rounded,
          color: widget.isLoading
              ? AppTheme.primary
              : (widget.isDark ? AppTheme.mutedLight : const Color(0xFF6B6B6B)),
          size: 24,
        ),
      ),
      tooltip: 'Refresh statuses',
    );
  }
}
