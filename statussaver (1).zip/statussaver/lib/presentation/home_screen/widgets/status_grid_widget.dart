import '../../../core/app_export.dart';

class StatusGridWidget extends StatefulWidget {
  final List<StatusModel> statuses;
  final ValueChanged<StatusModel> onStatusTap;
  final bool isTablet;

  const StatusGridWidget({
    super.key,
    required this.statuses,
    required this.onStatusTap,
    required this.isTablet,
  });

  @override
  State<StatusGridWidget> createState() => _StatusGridWidgetState();
}

class _StatusGridWidgetState extends State<StatusGridWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _entranceController;
  final List<Animation<double>> _itemAnims = [];

  @override
  void initState() {
    super.initState();
    _entranceController = AnimationController(
      vsync: this,
      duration: Duration(
        milliseconds: 350 + (widget.statuses.length.clamp(0, 8) * 40),
      ),
    );
    _buildItemAnimations();
    _entranceController.forward();
  }

  void _buildItemAnimations() {
    _itemAnims.clear();
    final count = widget.statuses.length.clamp(0, 12);
    for (int i = 0; i < count; i++) {
      final start = (i * 0.06).clamp(0.0, 0.7);
      final end = (start + 0.35).clamp(0.0, 1.0);
      _itemAnims.add(
        CurvedAnimation(
          parent: _entranceController,
          curve: Interval(start, end, curve: Curves.easeOutCubic),
        ),
      );
    }
  }

  @override
  void didUpdateWidget(StatusGridWidget old) {
    super.didUpdateWidget(old);
    if (old.statuses.length != widget.statuses.length) {
      _buildItemAnimations();
      _entranceController.reset();
      _entranceController.forward();
    }
  }

  @override
  void dispose() {
    _entranceController.dispose();
    super.dispose();
  }

  int get _crossAxisCount {
    if (widget.isTablet) {
      return MediaQuery.of(context).size.width >= 840 ? 4 : 3;
    }
    return 2;
  }

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: _crossAxisCount,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.82,
      ),
      itemCount: widget.statuses.length,
      itemBuilder: (context, index) {
        final status = widget.statuses[index];
        final anim = index < _itemAnims.length
            ? _itemAnims[index]
            : const AlwaysStoppedAnimation(1.0);

        return FadeTransition(
          opacity: anim,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0, 0.12),
              end: Offset.zero,
            ).animate(anim),
            child: StatusCardWidget(
              status: status,
              onTap: () => widget.onStatusTap(status),
            ),
          ),
        );
      },
    );
  }
}

class StatusCardWidget extends StatefulWidget {
  final StatusModel status;
  final VoidCallback onTap;

  const StatusCardWidget({super.key, required this.status, required this.onTap});

  @override
  State<StatusCardWidget> createState() => _StatusCardWidgetState();
}

class _StatusCardWidgetState extends State<StatusCardWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _pressController;
  late Animation<double> _pressAnim;

  @override
  void initState() {
    super.initState();
    _pressController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _pressAnim = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _pressController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final status = widget.status;

    return GestureDetector(
      onTapDown: (_) => _pressController.forward(),
      onTapUp: (_) {
        _pressController.reverse();
        widget.onTap();
      },
      onTapCancel: () => _pressController.reverse(),
      child: ScaleTransition(
        scale: _pressAnim,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: status.isSaved
                  ? AppTheme.primary.withAlpha(102)
                  : AppTheme.outline,
              width: status.isSaved ? 1.5 : 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(64),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Thumbnail
                _buildThumbnail(status),

                // Gradient overlay at bottom
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    height: 64,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [Color(0xCC000000), Colors.transparent],
                      ),
                    ),
                  ),
                ),

                // Type badge — top left
                Positioned(
                  top: 8,
                  left: 8,
                  child: StatusBadgeWidget(
                    variant: status.isVideo
                        ? BadgeVariant.video
                        : BadgeVariant.image,
                  ),
                ),

                // Saved badge — top right
                if (status.isSaved)
                  Positioned(
                    top: 8,
                    right: 8,
                    child: Container(
                      width: 26,
                      height: 26,
                      decoration: BoxDecoration(
                        color: AppTheme.primary,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.primary.withAlpha(102),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.check_rounded,
                        color: Colors.black,
                        size: 14,
                      ),
                    ),
                  ),

                // Video play icon overlay
                if (status.isVideo)
                  Center(
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: Colors.black.withAlpha(140),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.white.withAlpha(153),
                          width: 1.5,
                        ),
                      ),
                      child: const Icon(
                        Icons.play_arrow_rounded,
                        color: Colors.white,
                        size: 26,
                      ),
                    ),
                  ),

                // Date label — bottom
                Positioned(
                  bottom: 8,
                  left: 8,
                  right: 8,
                  child: Text(
                    _formatDate(status.dateModified),
                    style: const TextStyle(
                      fontSize: 10,
                      color: Colors.white70,
                      fontWeight: FontWeight.w500,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildThumbnail(StatusModel status) {
    if (status.isImage) {
      return CustomImageWidget(
        imageUrl: status.filePath,
        fit: BoxFit.cover,
        semanticLabel:
            '${status.isImage ? 'Image' : 'Video'} status from ${_formatDate(status.dateModified)}',
      );
    } else {
      // Video thumbnail — show a dark placeholder with play icon
      return Container(
        color: const Color(0xFF1A1A2E),
        child: const Center(
          child: Icon(
            Icons.video_file_rounded,
            color: Color(0xFF4A4A6A),
            size: 48,
          ),
        ),
      );
    }
  }

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}