import 'package:flutter/services.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../ads/ad_manager.dart';
import '../../core/app_export.dart';
import '../../routes/app_routes.dart';
import '../../services/file_service.dart';
import './widgets/banner_ad_widget.dart';
import './widgets/filter_tab_widget.dart';
import './widgets/home_app_bar_widget.dart';
import './widgets/permission_gate_widget.dart';
import './widgets/status_grid_widget.dart';

enum FilterTab { all, images, videos }

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  // TODO: Replace with Riverpod/Bloc for production
  bool _hasPermission = false;
  bool _isLoading = true;
  bool _isRefreshing = false;
  List<StatusModel> _allStatuses = [];
  List<StatusModel> _filteredStatuses = [];
  FilterTab _activeFilter = FilterTab.all;

  late AnimationController _fabAnimController;
  late Animation<double> _fabScaleAnim;

  final AdManager _adManager = AdManager();
  BannerAd? _bannerAd;

  @override
  void initState() {
    super.initState();
    _fabAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
    _fabScaleAnim = Tween<double>(begin: 1.0, end: 0.92).animate(
      CurvedAnimation(parent: _fabAnimController, curve: Curves.easeInOut),
    );

    _initAds();
    _checkPermissionAndLoad();
  }

  void _initAds() {
    _bannerAd = _adManager.createBannerAd()..load();
    _adManager.loadInterstitial();
  }

  Future<void> _checkPermissionAndLoad() async {
    setState(() => _isLoading = true);
    final hasPerms = await FileService.hasPermissions();
    if (hasPerms) {
      setState(() => _hasPermission = true);
      await _loadStatuses();
    } else {
      setState(() {
        _hasPermission = false;
        _isLoading = false;
      });
    }
  }

  Future<void> _requestPermission() async {
    final granted = await FileService.requestPermissions();
    if (granted) {
      setState(() => _hasPermission = true);
      await _loadStatuses();
    } else {
      // Check if permanently denied → open settings
      final sdkInt = 33;
      final isPermanentlyDenied = sdkInt >= 33
          ? (await Permission.photos.isPermanentlyDenied) ||
                (await Permission.videos.isPermanentlyDenied)
          : (await Permission.storage.isPermanentlyDenied);

      if (isPermanentlyDenied && mounted) {
        _showPermissionSettingsDialog();
      } else if (mounted) {
        _showSnackBar(
          'Storage permission is required to view statuses',
          isError: true,
        );
      }
    }
  }

  void _showPermissionSettingsDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surfaceVariant,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text(
          'Permission Required',
          style: TextStyle(
            color: AppTheme.onBackground,
            fontWeight: FontWeight.w700,
          ),
        ),
        content: const Text(
          'Storage permission was permanently denied. Please enable it in App Settings to view and save statuses.',
          style: TextStyle(color: AppTheme.mutedLight),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text(
              'Cancel',
              style: TextStyle(color: AppTheme.mutedLight),
            ),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(ctx);
              openAppSettings();
            },
            style: FilledButton.styleFrom(
              backgroundColor: AppTheme.primary,
              foregroundColor: Colors.black,
            ),
            child: const Text('Open Settings'),
          ),
        ],
      ),
    );
  }

  Future<void> _loadStatuses() async {
    setState(() => _isLoading = true);
    try {
      final statuses = await FileService.scanStatuses();

      // Check saved states
      for (final s in statuses) {
        final saved = await FileService.isAlreadySaved(s);
        if (saved) s.saveState = SaveState.saved;
      }

      if (mounted) {
        setState(() {
          _allStatuses = statuses;
          _applyFilter(_activeFilter);
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        _showSnackBar(
          'Failed to load statuses. Pull down to retry.',
          isError: true,
        );
      }
    }
  }

  Future<void> _onRefresh() async {
    if (_isRefreshing) return;
    setState(() => _isRefreshing = true);
    HapticFeedback.lightImpact();
    await _loadStatuses();
    setState(() => _isRefreshing = false);
  }

  void _applyFilter(FilterTab tab) {
    setState(() {
      _activeFilter = tab;
      switch (tab) {
        case FilterTab.all:
          _filteredStatuses = List.from(_allStatuses);
          break;
        case FilterTab.images:
          _filteredStatuses = _allStatuses.where((s) => s.isImage).toList();
          break;
        case FilterTab.videos:
          _filteredStatuses = _allStatuses.where((s) => s.isVideo).toList();
          break;
      }
    });
  }

  void _onStatusTap(StatusModel status) {
    HapticFeedback.selectionClick();
    Navigator.pushNamed(
      context,
      AppRoutes.previewScreen,
      arguments: {
        'status': status,
        'onSaved': (StatusModel updated) {
          setState(() {
            final idx = _allStatuses.indexWhere((s) => s.id == updated.id);
            if (idx != -1) {
              _allStatuses[idx] = updated;
              _applyFilter(_activeFilter);
            }
          });
          _adManager.trackAction();
        },
      },
    );
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? AppTheme.error : AppTheme.surface,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 80),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  int get _imageCount => _allStatuses.where((s) => s.isImage).length;
  int get _videoCount => _allStatuses.where((s) => s.isVideo).length;

  @override
  void dispose() {
    _fabAnimController.dispose();
    _bannerAd?.dispose();
    _adManager.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Scaffold(
      backgroundColor: AppTheme.background,
      extendBodyBehindAppBar: true,
      body: SafeArea(
        top: false,
        child: Stack(
          children: [
            Column(
              children: [
                // Gradient AppBar
                HomeAppBarWidget(
                  totalCount: _allStatuses.length,
                  onRefresh: _onRefresh,
                  isLoading: _isRefreshing,
                ),

                // Filter Tabs
                if (_hasPermission && !_isLoading)
                  FilterTabWidget(
                    activeTab: _activeFilter,
                    allCount: _allStatuses.length,
                    imageCount: _imageCount,
                    videoCount: _videoCount,
                    onTabChanged: _applyFilter,
                  ),

                // Main content
                Expanded(child: _buildBody(isTablet)),

                // Banner Ad
                BannerAdWidget(bannerAd: _bannerAd),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBody(bool isTablet) {
    if (!_hasPermission) {
      return PermissionGateWidget(onGrantPermission: _requestPermission);
    }

    if (_isLoading) {
      return StatusGridSkeletonWidget();
    }

    if (_filteredStatuses.isEmpty) {
      return EmptyStateWidget(
        icon: _activeFilter == FilterTab.videos
            ? Icons.videocam_off_rounded
            : Icons.photo_library_outlined,
        title: _activeFilter == FilterTab.all
            ? 'No Statuses Found'
            : _activeFilter == FilterTab.images
            ? 'No Image Statuses'
            : 'No Video Statuses',
        description: _activeFilter == FilterTab.all
            ? 'Make sure the status folder is accessible.\nView statuses in the source app first, then refresh.'
            : 'Switch to "All" to see all statuses, or check if there are any ${_activeFilter == FilterTab.images ? 'image' : 'video'} statuses.',
        actionLabel: 'Refresh',
        onAction: _onRefresh,
      );
    }

    return RefreshIndicator(
      onRefresh: _onRefresh,
      color: AppTheme.primary,
      backgroundColor: AppTheme.surfaceVariant,
      displacement: 16,
      child: StatusGridWidget(
        statuses: _filteredStatuses,
        onStatusTap: _onStatusTap,
        isTablet: isTablet,
      ),
    );
  }
}
