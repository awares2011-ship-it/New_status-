import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../../ads/ad_manager.dart';
import '../../core/app_export.dart';
import '../../services/file_service.dart';
import './widgets/image_preview_widget.dart';
import './widgets/preview_action_bar_widget.dart';
import './widgets/preview_app_bar_widget.dart';
import './widgets/video_preview_widget.dart';

class PreviewScreen extends StatefulWidget {
  const PreviewScreen({super.key});

  @override
  State<PreviewScreen> createState() => _PreviewScreenState();
}

class _PreviewScreenState extends State<PreviewScreen>
    with SingleTickerProviderStateMixin {
  StatusModel? _status;
  Function(StatusModel)? _onSaved;
  bool _isInitialized = false;

  bool _isSaving = false;
  bool _showControls = true;

  late AnimationController _controlsController;
  late Animation<double> _controlsFade;

  final AdManager _adManager = AdManager();

  @override
  void initState() {
    super.initState();
    _controlsController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
      value: 1.0,
    );
    _controlsFade = CurvedAnimation(
      parent: _controlsController,
      curve: Curves.easeOutCubic,
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_isInitialized) {
      try {
        final args = ModalRoute.of(context)?.settings.arguments;
        if (args is Map<String, dynamic>) {
          final status = args['status'];
          final onSaved = args['onSaved'];
          if (status is StatusModel) {
            _status = status;
          }
          if (onSaved is Function(StatusModel)) {
            _onSaved = onSaved;
          }
        }
      } catch (e) {
        debugPrint('PreviewScreen: Failed to parse arguments — $e');
      }
      _isInitialized = true;
    }
  }

  void _toggleControls() {
    setState(() => _showControls = !_showControls);
    if (_showControls) {
      _controlsController.forward();
    } else {
      _controlsController.reverse();
    }
  }

  Future<void> _saveToGallery() async {
    final status = _status;
    if (status == null || _isSaving || status.isSaved) return;
    HapticFeedback.mediumImpact();

    setState(() => _isSaving = true);

    try {
      final success = await FileService.saveToGallery(status);

      if (!mounted) return;

      if (success) {
        final updated = status.copyWith(saveState: SaveState.saved);
        setState(() {
          _status = updated;
          _isSaving = false;
        });
        _onSaved?.call(updated);
        _adManager.trackAction();
        _showSnackBar('Saved to Pictures/StatusSaver ✓', isSuccess: true);
      } else {
        setState(() => _isSaving = false);
        _showSnackBar('Save failed. Check storage permissions.', isError: true);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isSaving = false);
        _showSnackBar('Save failed. Try again.', isError: true);
      }
    }
  }

  Future<void> _shareStatus() async {
    final status = _status;
    if (status == null) return;
    HapticFeedback.lightImpact();
    try {
      String? sharePath = await FileService.getSavedPath(status);
      sharePath ??= await FileService.getTempCopyForShare(status);

      if (!mounted) return;

      if (sharePath == null) {
        _showSnackBar('Could not prepare file for sharing.', isError: true);
        return;
      }

      final xFile = XFile(sharePath);
      await Share.shareXFiles([
        xFile,
      ], text: status.isVideo ? 'Check out this video status!' : '');
      _adManager.trackAction();
    } catch (e) {
      if (mounted) {
        _showSnackBar('Share failed. Try again.', isError: true);
      }
    }
  }

  void _showSnackBar(
    String message, {
    bool isSuccess = false,
    bool isError = false,
  }) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isSuccess
                  ? Icons.check_circle_rounded
                  : isError
                  ? Icons.error_outline_rounded
                  : Icons.info_outline_rounded,
              size: 18,
              color: isSuccess
                  ? AppTheme.primary
                  : isError
                  ? AppTheme.error
                  : AppTheme.mutedLight,
            ),
            const SizedBox(width: 10),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: AppTheme.surfaceVariant,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 96),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  void dispose() {
    _controlsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Guard: if arguments were not properly passed, show error screen
    if (_status == null) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.error_outline_rounded,
                color: AppTheme.error,
                size: 48,
              ),
              const SizedBox(height: 16),
              const Text(
                'Could not load media',
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),
              const SizedBox(height: 16),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text(
                  'Go Back',
                  style: TextStyle(color: AppTheme.primary),
                ),
              ),
            ],
          ),
        ),
      );
    }

    final status = _status!;
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      body: GestureDetector(
        onTap: status.isImage ? _toggleControls : null,
        behavior: HitTestBehavior.opaque,
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Media content
            _buildMediaContent(status, isTablet),

            // Top AppBar
            FadeTransition(
              opacity: _controlsFade,
              child: PreviewAppBarWidget(
                status: status,
                onBack: () => Navigator.pop(context),
              ),
            ),

            // Bottom Action Bar
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: FadeTransition(
                opacity: _controlsFade,
                child: PreviewActionBarWidget(
                  status: status,
                  isSaving: _isSaving,
                  onSave: _saveToGallery,
                  onShare: _shareStatus,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMediaContent(StatusModel status, bool isTablet) {
    if (status.isImage) {
      return ImagePreviewWidget(filePath: status.filePath, isTablet: isTablet);
    } else {
      return VideoPreviewWidget(filePath: status.filePath, isTablet: isTablet);
    }
  }
}
