import 'dart:ui';
import 'package:flutter/material.dart';
import '../../../models/status_model.dart';
import '../../../widgets/status_badge_widget.dart';

class PreviewAppBarWidget extends StatelessWidget {
  final StatusModel status;
  final VoidCallback onBack;

  const PreviewAppBarWidget({
    super.key,
    required this.status,
    required this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;

    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: EdgeInsets.fromLTRB(4, topPadding + 4, 16, 12),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.black.withAlpha(191), Colors.black.withAlpha(0)],
            ),
          ),
          child: Row(
            children: [
              // Back button
              IconButton(
                onPressed: onBack,
                icon: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: Colors.black.withAlpha(128),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white.withAlpha(38),
                      width: 1,
                    ),
                  ),
                  child: const Icon(
                    Icons.arrow_back_ios_new_rounded,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
                tooltip: 'Back',
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      status.isImage ? 'Image Status' : 'Video Status',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        shadows: [Shadow(color: Colors.black54, blurRadius: 4)],
                      ),
                    ),
                    Text(
                      _formatDate(status.dateModified),
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
              // Type badge
              StatusBadgeWidget(
                variant: status.isVideo
                    ? BadgeVariant.video
                    : BadgeVariant.image,
              ),
              if (status.isSaved) ...[
                const SizedBox(width: 8),
                StatusBadgeWidget(variant: BadgeVariant.saved),
              ],
            ],
          ),
        ),
      ),
    );
  }

  String _formatDate(DateTime dt) {
    final months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${dt.day} ${months[dt.month - 1]} ${dt.year}, ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }
}
