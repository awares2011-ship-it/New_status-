import 'dart:ui';
import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';
import '../../../models/status_model.dart';

class PreviewActionBarWidget extends StatelessWidget {
  final StatusModel status;
  final bool isSaving;
  final VoidCallback onSave;
  final VoidCallback onShare;

  const PreviewActionBarWidget({
    super.key,
    required this.status,
    required this.isSaving,
    required this.onSave,
    required this.onShare,
  });

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          padding: EdgeInsets.fromLTRB(20, 16, 20, 16 + bottomPadding),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
              colors: [Colors.black.withAlpha(217), Colors.black.withAlpha(51)],
            ),
            border: Border(
              top: BorderSide(color: Colors.white.withAlpha(20), width: 1),
            ),
          ),
          child: Row(
            children: [
              // Save button
              Expanded(
                child: _SaveButton(
                  isSaving: isSaving,
                  isSaved: status.isSaved,
                  onPressed: onSave,
                ),
              ),
              const SizedBox(width: 12),
              // Share button
              _ShareButton(onPressed: onShare),
            ],
          ),
        ),
      ),
    );
  }
}

class _SaveButton extends StatefulWidget {
  final bool isSaving;
  final bool isSaved;
  final VoidCallback onPressed;

  const _SaveButton({
    required this.isSaving,
    required this.isSaved,
    required this.onPressed,
  });

  @override
  State<_SaveButton> createState() => _SaveButtonState();
}

class _SaveButtonState extends State<_SaveButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _successController;
  late Animation<double> _checkScaleAnim;

  @override
  void initState() {
    super.initState();
    _successController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );
    _checkScaleAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _successController, curve: Curves.easeOutBack),
    );
    if (widget.isSaved) _successController.value = 1.0;
  }

  @override
  void didUpdateWidget(_SaveButton old) {
    super.didUpdateWidget(old);
    if (!old.isSaved && widget.isSaved) {
      _successController.forward();
    }
  }

  @override
  void dispose() {
    _successController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDisabled = widget.isSaved || widget.isSaving;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOutCubic,
      height: 52,
      decoration: BoxDecoration(
        color: widget.isSaved
            ? AppTheme.primary.withAlpha(51)
            : AppTheme.primary,
        borderRadius: BorderRadius.circular(100),
        border: Border.all(
          color: widget.isSaved
              ? AppTheme.primary.withAlpha(128)
              : Colors.transparent,
          width: 1.5,
        ),
        boxShadow: widget.isSaved
            ? []
            : [
                BoxShadow(
                  color: AppTheme.primary.withAlpha(89),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: isDisabled ? null : widget.onPressed,
          borderRadius: BorderRadius.circular(100),
          splashColor: Colors.black.withAlpha(26),
          child: Center(
            child: widget.isSaving
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: Colors.black,
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ScaleTransition(
                        scale: widget.isSaved
                            ? _checkScaleAnim
                            : const AlwaysStoppedAnimation(1.0),
                        child: Icon(
                          widget.isSaved
                              ? Icons.check_circle_rounded
                              : Icons.download_rounded,
                          color: widget.isSaved
                              ? AppTheme.primary
                              : Colors.black,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        widget.isSaved ? 'Saved to Gallery' : 'Save to Gallery',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: widget.isSaved
                              ? AppTheme.primary
                              : Colors.black,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

class _ShareButton extends StatefulWidget {
  final VoidCallback onPressed;

  const _ShareButton({required this.onPressed});

  @override
  State<_ShareButton> createState() => _ShareButtonState();
}

class _ShareButtonState extends State<_ShareButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _pressController;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _pressController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scaleAnim = Tween<double>(begin: 1.0, end: 0.92).animate(
      CurvedAnimation(parent: _pressController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _pressController.forward(),
      onTapUp: (_) {
        _pressController.reverse();
        widget.onPressed();
      },
      onTapCancel: () => _pressController.reverse(),
      child: ScaleTransition(
        scale: _scaleAnim,
        child: Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            color: Colors.white.withAlpha(31),
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white.withAlpha(51), width: 1.5),
          ),
          child: const Icon(Icons.share_rounded, color: Colors.white, size: 22),
        ),
      ),
    );
  }
}
