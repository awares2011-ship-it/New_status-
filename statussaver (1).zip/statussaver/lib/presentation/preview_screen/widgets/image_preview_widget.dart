import 'dart:io';
import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';
import '../../../theme/app_theme.dart';

class ImagePreviewWidget extends StatelessWidget {
  final String filePath;
  final bool isTablet;

  const ImagePreviewWidget({
    super.key,
    required this.filePath,
    required this.isTablet,
  });

  @override
  Widget build(BuildContext context) {
    final file = File(filePath);

    if (!file.existsSync()) {
      return _buildErrorState();
    }

    final imageProvider = FileImage(file);

    if (isTablet) {
      return Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: _buildPhotoView(imageProvider),
        ),
      );
    }

    return _buildPhotoView(imageProvider);
  }

  Widget _buildPhotoView(ImageProvider imageProvider) {
    return PhotoView(
      imageProvider: imageProvider,
      backgroundDecoration: const BoxDecoration(color: Colors.black),
      minScale: PhotoViewComputedScale.contained,
      maxScale: PhotoViewComputedScale.covered * 3.5,
      initialScale: PhotoViewComputedScale.contained,
      enableRotation: false,
      loadingBuilder: (_, progress) => Center(
        child: CircularProgressIndicator(
          value: progress?.expectedTotalBytes != null
              ? (progress!.cumulativeBytesLoaded / progress.expectedTotalBytes!)
              : null,
          color: AppTheme.primary,
          strokeWidth: 2.5,
        ),
      ),
      errorBuilder: (_, __, ___) => _buildErrorState(),
    );
  }

  Widget _buildErrorState() {
    return Container(
      color: Colors.black,
      child: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.broken_image_rounded, color: AppTheme.muted, size: 64),
            SizedBox(height: 16),
            Text(
              'Could not load image',
              style: TextStyle(color: AppTheme.mutedLight, fontSize: 15),
            ),
          ],
        ),
      ),
    );
  }
}
