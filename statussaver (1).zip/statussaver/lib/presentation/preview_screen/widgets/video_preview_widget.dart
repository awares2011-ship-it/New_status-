import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import '../../../theme/app_theme.dart';

class VideoPreviewWidget extends StatefulWidget {
  final String filePath;
  final bool isTablet;

  const VideoPreviewWidget({
    super.key,
    required this.filePath,
    required this.isTablet,
  });

  @override
  State<VideoPreviewWidget> createState() => _VideoPreviewWidgetState();
}

class _VideoPreviewWidgetState extends State<VideoPreviewWidget> {
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  bool _isInitialized = false;
  bool _hasError = false;
  String _errorMessage = '';
  bool _isDisposed = false;

  @override
  void initState() {
    super.initState();
    _initVideoPlayer();
  }

  Future<void> _initVideoPlayer() async {
    try {
      final file = File(widget.filePath);
      if (!await file.exists()) {
        if (!_isDisposed && mounted) {
          setState(() {
            _hasError = true;
            _errorMessage = 'Video file not found';
          });
        }
        return;
      }

      final controller = VideoPlayerController.file(file);
      _videoController = controller;
      await controller.initialize();

      if (_isDisposed || !mounted) {
        controller.dispose();
        return;
      }

      final chewieController = ChewieController(
        videoPlayerController: controller,
        autoPlay: true,
        looping: false,
        allowFullScreen: true,
        allowMuting: true,
        showControls: true,
        materialProgressColors: ChewieProgressColors(
          playedColor: AppTheme.primary,
          handleColor: AppTheme.primary,
          backgroundColor: Colors.white.withAlpha(38),
          bufferedColor: Colors.white.withAlpha(77),
        ),
        placeholder: Container(color: Colors.black),
        autoInitialize: true,
        errorBuilder: (_, errorMessage) => _buildErrorState(errorMessage),
      );
      _chewieController = chewieController;

      if (!_isDisposed && mounted) {
        setState(() => _isInitialized = true);
      }
    } catch (e) {
      if (!_isDisposed && mounted) {
        setState(() {
          _hasError = true;
          _errorMessage = 'Could not load video: ${e.toString()}';
        });
      }
    }
  }

  @override
  void dispose() {
    _isDisposed = true;
    // Dispose chewie first, then video controller
    _chewieController?.dispose();
    _chewieController = null;
    _videoController?.dispose();
    _videoController = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_hasError) {
      return _buildErrorState(_errorMessage);
    }

    if (!_isInitialized || _chewieController == null) {
      return _buildLoadingState();
    }

    final player = Chewie(controller: _chewieController!);

    if (widget.isTablet) {
      return Container(
        color: Colors.black,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 600),
            child: player,
          ),
        ),
      );
    }

    return Container(color: Colors.black, child: player);
  }

  Widget _buildLoadingState() {
    return Container(
      color: Colors.black,
      child: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              color: AppTheme.primary,
              strokeWidth: 2.5,
            ),
            SizedBox(height: 16),
            Text(
              'Loading video…',
              style: TextStyle(color: AppTheme.mutedLight, fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState(String message) {
    return Container(
      color: Colors.black,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  color: AppTheme.error.withAlpha(26),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppTheme.error.withAlpha(77),
                    width: 1.5,
                  ),
                ),
                child: const Icon(
                  Icons.videocam_off_rounded,
                  color: AppTheme.error,
                  size: 34,
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Video Unavailable',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                message.isNotEmpty
                    ? message
                    : 'This video could not be played. It may have been deleted or is in an unsupported format.',
                style: const TextStyle(
                  color: AppTheme.mutedLight,
                  fontSize: 13,
                  height: 1.6,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
