import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdManager {
  // TODO: Replace test IDs with production AdMob IDs before Play Store submission
  static const String _bannerAdUnitIdAndroid =
      'ca-app-pub-3940256099942544/6300978111'; // Test banner
  static const String _interstitialAdUnitIdAndroid =
      'ca-app-pub-3940256099942544/1033173712'; // Test interstitial

  static String get bannerAdUnitId => _bannerAdUnitIdAndroid;
  static String get interstitialAdUnitId => _interstitialAdUnitIdAndroid;

  // Interstitial ad instance
  InterstitialAd? _interstitialAd;
  bool _isInterstitialReady = false;
  int _actionCount = 0;
  static const int _interstitialThreshold = 3; // Show after every 3 actions

  static final AdManager _instance = AdManager._internal();
  factory AdManager() => _instance;
  AdManager._internal();

  /// Initialize AdMob SDK
  static Future<void> initialize() async {
    if (kIsWeb) return;
    await MobileAds.instance.initialize();
  }

  /// Load interstitial ad
  void loadInterstitial() {
    if (kIsWeb) return;
    InterstitialAd.load(
      adUnitId: interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          _isInterstitialReady = true;
          _interstitialAd!.setImmersiveMode(true);
        },
        onAdFailedToLoad: (error) {
          debugPrint('AdManager: Interstitial failed — ${error.message}');
          _isInterstitialReady = false;
        },
      ),
    );
  }

  /// Track action and show interstitial if threshold reached
  void trackAction() {
    _actionCount++;
    if (_actionCount >= _interstitialThreshold) {
      _actionCount = 0;
      showInterstitial();
    }
  }

  /// Show interstitial ad if ready
  void showInterstitial() {
    if (kIsWeb || !_isInterstitialReady || _interstitialAd == null) return;
    _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _interstitialAd = null;
        _isInterstitialReady = false;
        loadInterstitial(); // Pre-load next one
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _interstitialAd = null;
        _isInterstitialReady = false;
      },
    );
    _interstitialAd!.show();
  }

  /// Create a banner ad widget
  BannerAd createBannerAd() {
    return BannerAd(
      adUnitId: bannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => debugPrint('AdManager: Banner loaded'),
        onAdFailedToLoad: (ad, error) {
          debugPrint('AdManager: Banner failed — ${error.message}');
          ad.dispose();
        },
      ),
    );
  }

  void dispose() {
    _interstitialAd?.dispose();
  }
}
