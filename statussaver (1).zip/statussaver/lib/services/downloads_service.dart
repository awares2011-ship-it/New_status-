import 'dart:io';
import 'package:flutter/foundation.dart';
import '../models/status_model.dart';

class DownloadsService {
  static const String _savedDir = '/storage/emulated/0/Pictures/StatusSaver';

  /// Scan the saved StatusSaver directory and return all saved files
  static Future<List<StatusModel>> getSavedStatuses() async {
    if (kIsWeb) return [];

    final dir = Directory(_savedDir);
    if (!await dir.exists()) return [];

    final List<StatusModel> results = [];
    try {
      final entities = await dir.list().toList();
      for (final entity in entities) {
        if (entity is! File) continue;
        final name = entity.path.toLowerCase();
        StatusType? type;

        if (_isImage(name)) {
          type = StatusType.image;
        } else if (_isVideo(name)) {
          type = StatusType.video;
        }

        if (type == null) continue;

        final stat = await entity.stat();
        results.add(
          StatusModel(
            id: entity.path.hashCode.toString(),
            filePath: entity.path,
            type: type,
            dateModified: stat.modified,
            saveState: SaveState.saved,
          ),
        );
      }
    } catch (e) {
      debugPrint('DownloadsService: Error scanning — $e');
    }

    results.sort((a, b) => b.dateModified.compareTo(a.dateModified));
    return results;
  }

  /// Delete a saved status file
  static Future<bool> deleteStatus(StatusModel status) async {
    if (kIsWeb) return false;
    try {
      final file = File(status.filePath);
      if (await file.exists()) {
        await file.delete();
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('DownloadsService: Delete error — $e');
      return false;
    }
  }

  static bool _isImage(String path) {
    return path.endsWith('.jpg') ||
        path.endsWith('.jpeg') ||
        path.endsWith('.png') ||
        path.endsWith('.webp') ||
        path.endsWith('.gif');
  }

  static bool _isVideo(String path) {
    return path.endsWith('.mp4') ||
        path.endsWith('.mkv') ||
        path.endsWith('.3gp') ||
        path.endsWith('.avi');
  }
}
