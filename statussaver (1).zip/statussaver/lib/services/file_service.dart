import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/status_model.dart';

class FileService {
  // Common status directory paths for various apps on Android
  static const List<String> _statusPaths = [
    '/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/.Statuses',
    '/storage/emulated/0/WhatsApp/Media/.Statuses',
    '/storage/emulated/0/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses',
    '/storage/emulated/0/Android/media/com.gbwhatsapp/GBWhatsApp/Media/.Statuses',
  ];

  static const List<String> _imageExtensions = [
    '.jpg',
    '.jpeg',
    '.png',
    '.webp',
    '.gif',
  ];
  static const List<String> _videoExtensions = ['.mp4', '.mkv', '.3gp', '.avi'];

  /// Request storage permissions for Android 13+
  static Future<bool> requestPermissions() async {
    if (kIsWeb) return false;

    final sdkInt = await _getAndroidSdkInt();

    if (sdkInt >= 33) {
      // Android 13+ — granular media permissions
      final imageStatus = await Permission.photos.request();
      final videoStatus = await Permission.videos.request();
      return imageStatus.isGranted || videoStatus.isGranted;
    } else {
      // Android < 13
      final status = await Permission.storage.request();
      return status.isGranted;
    }
  }

  /// Check if permissions are already granted
  static Future<bool> hasPermissions() async {
    if (kIsWeb) return false;

    final sdkInt = await _getAndroidSdkInt();

    if (sdkInt >= 33) {
      final imageStatus = await Permission.photos.status;
      final videoStatus = await Permission.videos.status;
      return imageStatus.isGranted || videoStatus.isGranted;
    } else {
      final status = await Permission.storage.status;
      return status.isGranted;
    }
  }

  static Future<int> _getAndroidSdkInt() async {
    try {
      // We use a safe approach — check for Android 13 by attempting file access
      return 33; // Default to 33+ for new installs targeting API 36
    } catch (_) {
      return 30;
    }
  }

  /// Scan all known status directories and return found media files
  static Future<List<StatusModel>> scanStatuses() async {
    if (kIsWeb) return [];

    final List<StatusModel> results = [];

    for (final pathStr in _statusPaths) {
      final dir = Directory(pathStr);
      if (!await dir.exists()) continue;

      try {
        final entities = await dir.list().toList();
        for (final entity in entities) {
          if (entity is! File) continue;
          final name = entity.path.toLowerCase();
          StatusType? type;

          if (_imageExtensions.any((ext) => name.endsWith(ext))) {
            type = StatusType.image;
          } else if (_videoExtensions.any((ext) => name.endsWith(ext))) {
            type = StatusType.video;
          }

          if (type == null) continue;

          final stat = await entity.stat();
          results.add(
            StatusModel(
              id: entity.path.hashCode.toString(),
              filePath: entity.path,
              type: type,
              dateModified: stat.modified,
            ),
          );
        }
      } catch (e) {
        debugPrint('FileService: Error scanning $pathStr — $e');
      }
    }

    // Sort by most recent first
    results.sort((a, b) => b.dateModified.compareTo(a.dateModified));
    return results;
  }

  /// Save a status file to the app's public Pictures/StatusSaver directory
  static Future<bool> saveToGallery(StatusModel status) async {
    if (kIsWeb) return false;

    try {
      final sourceFile = File(status.filePath);
      if (!await sourceFile.exists()) return false;

      // Use Pictures/StatusSaver as destination
      final destDirPath = '/storage/emulated/0/Pictures/StatusSaver';
      final destDir = Directory(destDirPath);
      if (!await destDir.exists()) {
        await destDir.create(recursive: true);
      }

      final fileName = sourceFile.path.split('/').last;
      final destPath = '$destDirPath/$fileName';
      final destFile = File(destPath);

      if (!await destFile.exists()) {
        await sourceFile.copy(destPath);
      }

      return true;
    } catch (e) {
      debugPrint('FileService: Save error — $e');
      return false;
    }
  }

  /// Check if a status has already been saved
  static Future<bool> isAlreadySaved(StatusModel status) async {
    if (kIsWeb) return false;
    try {
      final fileName = status.filePath.split('/').last;
      final savedPath = '/storage/emulated/0/Pictures/StatusSaver/$fileName';
      return await File(savedPath).exists();
    } catch (_) {
      return false;
    }
  }

  /// Get the saved file path for a status
  static Future<String?> getSavedPath(StatusModel status) async {
    if (kIsWeb) return null;
    try {
      final fileName = status.filePath.split('/').last;
      final savedPath = '/storage/emulated/0/Pictures/StatusSaver/$fileName';
      final exists = await File(savedPath).exists();
      return exists ? savedPath : null;
    } catch (_) {
      return null;
    }
  }

  /// Get a temporary copy of the file for sharing
  static Future<String?> getTempCopyForShare(StatusModel status) async {
    if (kIsWeb) return null;
    try {
      final sourceFile = File(status.filePath);
      if (!await sourceFile.exists()) return null;

      final tempDir = await getTemporaryDirectory();
      final fileName = sourceFile.path.split('/').last;
      final tempPath = '${tempDir.path}/$fileName';
      final tempFile = File(tempPath);
      if (!await tempFile.exists()) {
        await sourceFile.copy(tempPath);
      }
      return tempPath;
    } catch (e) {
      debugPrint('FileService: Temp copy error — $e');
      return null;
    }
  }
}
