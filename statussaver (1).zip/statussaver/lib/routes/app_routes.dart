import 'package:flutter/material.dart';
import '../presentation/home_screen/home_screen.dart';
import '../presentation/preview_screen/preview_screen.dart';
import '../presentation/about_screen/about_screen.dart';
import '../presentation/downloads_screen/downloads_screen.dart';
import '../presentation/settings_screen/settings_screen.dart';
import '../services/theme_service.dart';

class AppRoutes {
  static const String initial = '/';
  static const String homeScreen = '/home-screen';
  static const String previewScreen = '/preview-screen';
  static const String aboutScreen = '/about-screen';
  static const String downloadsScreen = '/downloads-screen';
  static const String settingsScreen = '/settings-screen';

  static Map<String, WidgetBuilder> routes(ThemeService themeService) => {
    initial: (context) => const HomeScreen(),
    homeScreen: (context) => const HomeScreen(),
    previewScreen: (context) => const PreviewScreen(),
    aboutScreen: (context) => const AboutScreen(),
    downloadsScreen: (context) => const DownloadsScreen(),
    settingsScreen: (context) => SettingsScreen(themeService: themeService),
  };
}
