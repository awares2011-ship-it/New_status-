import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

enum BadgeVariant { image, video, saved, unsaved, count }

class StatusBadgeWidget extends StatelessWidget {
  final BadgeVariant variant;
  final String? label;
  final int? count;

  const StatusBadgeWidget({
    super.key,
    required this.variant,
    this.label,
    this.count,
  });

  @override
  Widget build(BuildContext context) {
    return _buildBadge(context);
  }

  Widget _buildBadge(BuildContext context) {
    switch (variant) {
      case BadgeVariant.image:
        return _pill(
          icon: Icons.image_rounded,
          text: label ?? 'IMAGE',
          bg: AppTheme.imageBadge.withAlpha(217),
          fg: Colors.white,
        );
      case BadgeVariant.video:
        return _pill(
          icon: Icons.play_circle_fill_rounded,
          text: label ?? 'VIDEO',
          bg: AppTheme.videoBadge.withAlpha(217),
          fg: Colors.white,
        );
      case BadgeVariant.saved:
        return _pill(
          icon: Icons.check_circle_rounded,
          text: label ?? 'SAVED',
          bg: AppTheme.success.withAlpha(217),
          fg: Colors.black,
        );
      case BadgeVariant.unsaved:
        return _pill(
          icon: Icons.download_rounded,
          text: label ?? 'SAVE',
          bg: Colors.black.withAlpha(153),
          fg: Colors.white,
        );
      case BadgeVariant.count:
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: AppTheme.primary,
            borderRadius: BorderRadius.circular(100),
          ),
          child: Text(
            '${count ?? 0}',
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: Colors.black,
            ),
          ),
        );
    }
  }

  Widget _pill({
    required IconData icon,
    required String text,
    required Color bg,
    required Color fg,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 10, color: fg),
          const SizedBox(width: 3),
          Text(
            text,
            style: TextStyle(
              fontSize: 9,
              fontWeight: FontWeight.w700,
              color: fg,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }
}
