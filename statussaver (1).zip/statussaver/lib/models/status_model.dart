enum StatusType { image, video }

enum SaveState { unsaved, saving, saved }

class StatusModel {
  final String id;
  final String filePath;
  final StatusType type;
  final DateTime dateModified;
  SaveState saveState;

  StatusModel({
    required this.id,
    required this.filePath,
    required this.type,
    required this.dateModified,
    this.saveState = SaveState.unsaved,
  });

  factory StatusModel.fromMap(Map<String, dynamic> map) {
    return StatusModel(
      id: map['id'] as String,
      filePath: map['filePath'] as String,
      type: _typeFromString(map['type'] as String),
      dateModified: DateTime.parse(map['dateModified'] as String),
      saveState: _saveStateFromString(map['saveState'] as String? ?? 'unsaved'),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'filePath': filePath,
      'type': type == StatusType.image ? 'image' : 'video',
      'dateModified': dateModified.toIso8601String(),
      'saveState': saveState == SaveState.saved
          ? 'saved'
          : saveState == SaveState.saving
          ? 'saving'
          : 'unsaved',
    };
  }

  static StatusType _typeFromString(String v) {
    switch (v) {
      case 'video':
        return StatusType.video;
      case 'image':
      default:
        return StatusType.image;
    }
  }

  static SaveState _saveStateFromString(String v) {
    switch (v) {
      case 'saved':
        return SaveState.saved;
      case 'saving':
        return SaveState.saving;
      case 'unsaved':
      default:
        return SaveState.unsaved;
    }
  }

  bool get isImage => type == StatusType.image;
  bool get isVideo => type == StatusType.video;
  bool get isSaved => saveState == SaveState.saved;

  StatusModel copyWith({
    String? id,
    String? filePath,
    StatusType? type,
    DateTime? dateModified,
    SaveState? saveState,
  }) {
    return StatusModel(
      id: id ?? this.id,
      filePath: filePath ?? this.filePath,
      type: type ?? this.type,
      dateModified: dateModified ?? this.dateModified,
      saveState: saveState ?? this.saveState,
    );
  }
}
